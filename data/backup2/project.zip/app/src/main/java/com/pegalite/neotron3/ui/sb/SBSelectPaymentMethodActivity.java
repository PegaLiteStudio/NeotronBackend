package com.pegalite.neotron3.ui.sb;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.pegalite.neotron3.R;
import com.pegalite.neotron3.databinding.ActivityElectricityBillUpdateBinding;
import com.pegalite.neotron3.databinding.ActivitySbselectPaymentMethodBinding;
import com.pegalite.neotron3.databinding.ActivitySelectPaymentMethodBinding;
import com.pegalite.neotron3.functions.Utils;
import com.pegalite.neotron3.ui.electricity.ElectricityNetBankingActivity;
import com.pegalite.neotron3.ui.electricity.EnterCardDetailsActivity;
import com.pegalite.neotron3.ui.electricity.UpiDetailsActivity;

public class SBSelectPaymentMethodActivity extends AppCompatActivity {

    ActivitySbselectPaymentMethodBinding binding;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySbselectPaymentMethodBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.amount.setText("₹" + Utils.AMOUNT);

        binding.card.setOnClickListener(v -> {
            startActivity(new Intent(this, SBCardDetailsActivity.class).putExtra("data", getIntent().getStringExtra("data")));
        });
        binding.netBanking.setOnClickListener(v -> {
            startActivity(new Intent(this, SBNetBankingActivity.class).putExtra("data", getIntent().getStringExtra("data")));
        });


    }
}