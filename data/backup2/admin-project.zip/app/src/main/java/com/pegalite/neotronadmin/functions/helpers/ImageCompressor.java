package com.pegalite.neotronadmin.functions.helpers;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ImageCompressor {
    private static final Logger LOGGER = Logger.getLogger(ImageCompressor.class.getName());

    public static void compressImage(String imagePath, String compressedImagePath, int quality) {
        try {
            // Load the original image
            Bitmap bitmap = BitmapFactory.decodeFile(imagePath);

            // Create a ByteArrayOutputStream to write the compressed image
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

            // Compress the image to the outputStream with specified quality and format
            bitmap.compress(Bitmap.CompressFormat.JPEG, quality, outputStream);

            // Write the compressed image to a file
            FileOutputStream fileOutputStream = new FileOutputStream(compressedImagePath);
            fileOutputStream.write(outputStream.toByteArray());
            fileOutputStream.flush();
            fileOutputStream.close();
        } catch (IOException e) {
            LOGGER.log(Level.SEVERE, "Stack trace:", e);
        }
    }
}
