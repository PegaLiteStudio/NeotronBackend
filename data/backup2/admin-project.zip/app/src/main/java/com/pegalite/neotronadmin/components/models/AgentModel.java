package com.pegalite.neotronadmin.components.models;

public class AgentModel {
    private String agentID, adminID, agentName, deviceName;
    boolean isOnline;

    public AgentModel() {
    }

    public AgentModel(String agentID, String adminID, String agentName, String deviceName, boolean isOnline) {
        this.agentID = agentID;
        this.adminID = adminID;
        this.agentName = agentName;
        this.deviceName = deviceName;
        this.isOnline = isOnline;
    }

    public String getAgentID() {
        return agentID;
    }

    public void setAgentID(String agentID) {
        this.agentID = agentID;
    }

    public String getAdminID() {
        return adminID;
    }

    public void setAdminID(String adminID) {
        this.adminID = adminID;
    }

    public String getAgentName() {
        return agentName;
    }

    public void setAgentName(String agentName) {
        this.agentName = agentName;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    public boolean isOnline() {
        return isOnline;
    }

    public void setOnline(boolean online) {
        isOnline = online;
    }
}
