package com.pegalite.neotronadmin.components.adapters;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.pegalite.neotronadmin.components.models.ContactModel;
import com.pegalite.neotronadmin.databinding.ContactItemBinding;
import com.pegalite.neotronadmin.functions.viewmanagers.PegaAppCompatActivity;

import java.util.List;

public class ContactsAdapter extends RecyclerView.Adapter<ContactsAdapter.AdminsViewHolder> {

    private final List<ContactModel> contactModelList;
    private final PegaAppCompatActivity activity;

    public ContactsAdapter(List<ContactModel> contactModelList, PegaAppCompatActivity activity) {
        this.contactModelList = contactModelList;
        this.activity = activity;
    }

    @NonNull
    @Override
    public AdminsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new AdminsViewHolder(ContactItemBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false));
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull AdminsViewHolder holder, int position) {
        ContactModel model = contactModelList.get(position);

        holder.binding.name.setText(model.getName());
        holder.binding.number.setText(model.getPhone());

    }

    @Override
    public int getItemCount() {
        return contactModelList.size();
    }

    public static class AdminsViewHolder extends RecyclerView.ViewHolder {

        ContactItemBinding binding;

        public AdminsViewHolder(@NonNull ContactItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}

