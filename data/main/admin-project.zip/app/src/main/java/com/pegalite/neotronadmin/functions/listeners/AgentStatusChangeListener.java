package com.pegalite.neotronadmin.functions.listeners;

public interface AgentStatusChangeListener {
    void onChange(String agentID, boolean isOnline);
}
