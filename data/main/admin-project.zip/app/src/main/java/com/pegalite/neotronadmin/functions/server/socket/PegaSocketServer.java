package com.pegalite.neotronadmin.functions.server.socket;

import android.app.Activity;

import com.pegalite.neotronadmin.functions.server.req.RetrofitClient;
import com.pegalite.neotronadmin.functions.utils.Utils;

import java.net.URISyntaxException;

import io.socket.client.IO;
import io.socket.client.Socket;

public class PegaSocketServer {

    private static Socket socket;

    public static void init(Activity activity, String number) {
        IO.Options options = new IO.Options();
        options.reconnection = true;
        options.reconnectionAttempts = Integer.MAX_VALUE;
        options.reconnectionDelay = 1000;
        options.timeout = 60000; // 60 seconds

        options.query = "number=" + number;
        try {
            socket = IO.socket(RetrofitClient.BASE_URL, options);
            socket.connect();
//            socket.on(Socket.EVENT_CONNECT, args -> {
//                activity.runOnUiThread(() -> Toast.makeText(activity, "Connected", Toast.LENGTH_SHORT).show());
//                System.out.println("Connected");
//            });
//            socket.on(Socket.EVENT_DISCONNECT, args -> {
//                activity.runOnUiThread(() -> Toast.makeText(activity, "Disconnected", Toast.LENGTH_SHORT).show());
//                System.out.println("Disconnected");
//            });

            socket.on("onDeviceStatusChange", args -> {
                if (Utils.agentStatusChangeListeners != null) {
                    String agentID = args[0].toString();

                    boolean isOnline = Boolean.parseBoolean(args[1].toString());

                    for (int i = 0; i < Utils.agentStatusChangeListeners.size(); i++) {
                        Utils.agentStatusChangeListeners.get(i).onChange(agentID, isOnline);
                    }
                }
            });
            socket.on("onNewAgentAdded", args -> {
                if (Utils.agentAddedListener != null) {
                    String agentID = args[0].toString();
                    String adminID = args[1].toString();
                    String agentName = args[2].toString();
                    String deviceName = args[3].toString();
                    Utils.agentAddedListener.onAdd(agentID, adminID, agentName, deviceName);
                }
            });
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        }

    }

    public static Socket getSocket() {
        return socket;
    }
}
