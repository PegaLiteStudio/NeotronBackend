package com.pegalite.neotronadmin.ui;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDelegate;

import com.pegalite.neotronadmin.databinding.ActivitySplashBinding;
import com.pegalite.neotronadmin.functions.helpers.Prefs;
import com.pegalite.neotronadmin.functions.server.req.RetrofitClient;
import com.pegalite.neotronadmin.functions.server.res.PegaCallback;
import com.pegalite.neotronadmin.functions.server.res.PegaResponseManager;
import com.pegalite.neotronadmin.functions.utils.Utils;
import com.pegalite.neotronadmin.functions.viewmanagers.PegaAppCompatActivity;

import org.json.JSONObject;

@SuppressLint("CustomSplashScreen")
public class SplashActivity extends PegaAppCompatActivity {

    ActivitySplashBinding binding;
    Prefs prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySplashBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        prefs = new Prefs(this);

        sessionLogin();

        setWindowThemeMain();

        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

    }

    private void sessionLogin() {

        if (!prefs.checkLogin()) {
            openActivityWithRightAnim(LoginActivity.class);
            finish();
            return;
        }

        RetrofitClient.getInstance(SplashActivity.this).getApiInterfaces().sessionLogin().enqueue(new PegaResponseManager(new PegaCallback(SplashActivity.this, true) {
            @Override
            public void onResponse() {
                super.onResponse();
            }

            @Override
            public void onSuccess(@Nullable JSONObject data) {
                if (data == null) {
                    onUnexpectedResponse();
                    return;
                }
                Utils.exp = data.optString("exp");
                openActivityWithRightAnim(MainActivity.class);
                finish();
            }

            @Override
            public void onInvalidPassword(View view) {
                onSessionExpired();
            }

            @Override
            public void onAccountNotExists() {
                onSessionExpired();
            }


        }));

    }
}