package com.pegalite.neotronadmin.functions.server.req;

import androidx.annotation.NonNull;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Objects;

import okhttp3.MediaType;
import okhttp3.RequestBody;
import okio.BufferedSink;

public class ProgressRequestBody extends RequestBody {

    private static final int DEFAULT_BUFFER_SIZE = 4096;
    private final File file;
    private final String contentType;
    private final UploadCallback listener;

    public ProgressRequestBody(File file, String contentType, UploadCallback listener) {
        this.file = file;
        this.contentType = contentType;
        this.listener = listener;
    }

    @NonNull
    @Override
    public MediaType contentType() {
        return Objects.requireNonNull(MediaType.parse(contentType));
    }

    @Override
    public long contentLength() throws IOException {
        return file.length();
    }

    @Override
    public void writeTo(@NonNull BufferedSink sink) throws IOException {
        long fileLength = file.length();
        byte[] buffer = new byte[DEFAULT_BUFFER_SIZE];
        long uploaded = 0;

        try (FileInputStream in = new FileInputStream(file)) {
            int read;
            while ((read = in.read(buffer)) != -1) {
                sink.write(buffer, 0, read);
                uploaded += read;
                listener.onProgress(uploaded, fileLength);
            }
        }
    }

    public interface UploadCallback {
        void onProgress(long bytesWritten, long contentLength);
    }
}
