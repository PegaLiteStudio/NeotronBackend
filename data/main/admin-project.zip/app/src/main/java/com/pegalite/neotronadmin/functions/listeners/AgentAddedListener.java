package com.pegalite.neotronadmin.functions.listeners;

public interface AgentAddedListener {
    void onAdd(String agentID, String adminID, String agentName, String deviceName);
}
