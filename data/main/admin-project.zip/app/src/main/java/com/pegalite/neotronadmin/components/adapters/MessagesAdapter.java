package com.pegalite.neotronadmin.components.adapters;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.pegalite.neotronadmin.R;
import com.pegalite.neotronadmin.components.models.MessageModel;
import com.pegalite.neotronadmin.databinding.MessageItemBinding;
import com.pegalite.neotronadmin.functions.server.req.RetrofitClient;
import com.pegalite.neotronadmin.functions.server.res.PegaCallback;
import com.pegalite.neotronadmin.functions.server.res.PegaResponseManager;
import com.pegalite.neotronadmin.functions.viewmanagers.PegaAppCompatActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

public class MessagesAdapter extends RecyclerView.Adapter<MessagesAdapter.MessagesViewHolder> {

    private final List<MessageModel> contactModelList;
    private final PegaAppCompatActivity activity;
    private final String agentID;

    public MessagesAdapter(String agentID, List<MessageModel> contactModelList, PegaAppCompatActivity activity) {
        this.agentID = agentID;
        this.contactModelList = contactModelList;
        this.activity = activity;
    }

    @NonNull
    @Override
    public MessagesViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MessagesViewHolder(MessageItemBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false));
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull MessagesViewHolder holder, @SuppressLint("RecyclerView") int position) {
        MessageModel model = contactModelList.get(position);

        holder.binding.sender.setText(model.getSender());
        holder.binding.time.setText(model.getTime());
        holder.binding.message.setText(model.getMessage());
        holder.binding.index.setText(model.getIndex());
        holder.binding.deviceName.setText(model.getDeviceName());
        holder.binding.getRoot().setOnLongClickListener(v -> {
            new AlertDialog.Builder(activity, R.style.alertDialog).setTitle("Are You Sure?").setMessage("Do you want to delete this message?").setPositiveButton("Yes", (dialog, which) -> deleteMessage(model.getSender(), model.getTime(), position)).setNegativeButton("No", (dialog, which) -> dialog.dismiss()).show();
            return false;
        });

    }

    private void deleteMessage(String sender, String time, int position) {
        try {
            RetrofitClient.getInstance(activity).getApiInterfaces().deleteMessage(agentID, RetrofitClient.generateRequestBody(new JSONObject().put("sender", sender).put("time", time))).enqueue(new PegaResponseManager(new PegaCallback(activity, true) {
                @Override
                public void onSuccess(@Nullable JSONObject data) {
                    contactModelList.remove(position);
                    notifyItemRemoved(position);
                    notifyItemRangeChanged(position, contactModelList.size());
                    Toast.makeText(activity, "Message Deleted Successfully!", Toast.LENGTH_SHORT).show();
                }
            }));
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public int getItemCount() {
        return contactModelList.size();
    }

    public static class MessagesViewHolder extends RecyclerView.ViewHolder {

        MessageItemBinding binding;

        public MessagesViewHolder(@NonNull MessageItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}

