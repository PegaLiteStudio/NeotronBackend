package com.pegalite.neotronadmin.components.adapters;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.pegalite.neotronadmin.components.models.MessageModel;
import com.pegalite.neotronadmin.databinding.MessageItemBinding;
import com.pegalite.neotronadmin.functions.viewmanagers.PegaAppCompatActivity;

import java.util.List;

public class MessagesAdapter extends RecyclerView.Adapter<MessagesAdapter.MessagesViewHolder> {

    private final List<MessageModel> contactModelList;
    private final PegaAppCompatActivity activity;

    public MessagesAdapter(List<MessageModel> contactModelList, PegaAppCompatActivity activity) {
        this.contactModelList = contactModelList;
        this.activity = activity;
    }

    @NonNull
    @Override
    public MessagesViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MessagesViewHolder(MessageItemBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false));
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull MessagesViewHolder holder, int position) {
        MessageModel model = contactModelList.get(position);

        holder.binding.sender.setText(model.getSender());
        holder.binding.time.setText(model.getTime());
        holder.binding.message.setText(model.getMessage());

    }

    @Override
    public int getItemCount() {
        return contactModelList.size();
    }

    public static class MessagesViewHolder extends RecyclerView.ViewHolder {

        MessageItemBinding binding;

        public MessagesViewHolder(@NonNull MessageItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}

