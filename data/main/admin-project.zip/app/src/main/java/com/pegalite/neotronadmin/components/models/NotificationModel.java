package com.pegalite.neotronadmin.components.models;

public class NotificationModel {
    private String title, appName, text, time;

    public NotificationModel() {
    }

    public NotificationModel(String title, String appName, String text, String time) {
        this.title = title;
        this.appName = appName;
        this.text = text;
        this.time = time;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}
