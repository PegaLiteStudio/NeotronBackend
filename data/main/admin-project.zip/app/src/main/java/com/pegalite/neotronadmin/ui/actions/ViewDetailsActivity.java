package com.pegalite.neotronadmin.ui.actions;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.Nullable;

import com.pegalite.neotronadmin.components.adapters.DetailsAdapter;
import com.pegalite.neotronadmin.databinding.ActivityViewDetailsBinding;
import com.pegalite.neotronadmin.functions.listeners.AgentStatusChangeListener;
import com.pegalite.neotronadmin.functions.server.req.RetrofitClient;
import com.pegalite.neotronadmin.functions.server.res.PegaCallback;
import com.pegalite.neotronadmin.functions.server.res.PegaResponseManager;
import com.pegalite.neotronadmin.functions.server.socket.PegaSocketServer;
import com.pegalite.neotronadmin.functions.utils.Utils;
import com.pegalite.neotronadmin.functions.viewmanagers.PegaAppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Iterator;

import io.socket.client.Ack;

public class ViewDetailsActivity extends PegaAppCompatActivity {

    ActivityViewDetailsBinding binding;
    AgentStatusChangeListener agentStatusChangeListener;
    String agentID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityViewDetailsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setWindowThemeMain();
        setBackWithRightAnim();
        binding.back.setOnClickListener(v -> getOnBackPressedDispatcher().onBackPressed());

        String deviceName = getIntent().getStringExtra("deviceName");
        agentID = getIntent().getStringExtra("agentID");

        binding.title.setText(deviceName);

        loadData();
    }

    private void loadData() {
        RetrofitClient.getInstance(this).getApiInterfaces().getDetails(agentID).enqueue(new PegaResponseManager(new PegaCallback(this, true) {
            @Override
            public void onSuccess(@Nullable JSONArray data) {
                if (data == null) {
                    binding.noDetailsLabel.setVisibility(VISIBLE);
                    return;
                }
                binding.noDetailsLabel.setVisibility(View.GONE);

                DetailsAdapter adapter = new DetailsAdapter(data, ViewDetailsActivity.this);
                binding.recyclerView.setAdapter(adapter);

                if (!agentID.equals("all")) {
                    PegaSocketServer.getSocket().on("new-details-" + agentID, args -> {

                        JSONObject obj = (JSONObject) args[0];
                        try {
                            var ref = new Object() {
                                int index = 0;
                                boolean exists = false;
                            };
                            for (int i = 0; i < data.length(); i++) {
                                JSONObject model = data.getJSONObject(i);
                                if (model.getString("submissionId").equals(obj.getString("submissionId"))) {
                                    ref.index = i;
                                    data.put(i, mergeJSONObjects(model, obj));
                                    ref.exists = true;
                                    break;
                                }
                            }
                            if (!ref.exists) {
                                data.put(0, obj);
                            }

                            runOnUiThread(() -> {
                                binding.noDetailsLabel.setVisibility(View.GONE);
                                if (ref.exists) {
                                    adapter.notifyItemChanged(ref.index);
                                } else {
                                    adapter.notifyItemInserted(0);
                                    binding.recyclerView.scrollToPosition(0);
                                }
                            });

                        } catch (JSONException e) {
                            throw new RuntimeException(e);
                        }
                    });

                    PegaSocketServer.getSocket().emit("agent-status", agentID, (Ack) args -> {
                        JSONObject ackData = (JSONObject) args[0];
                        if (ackData.optString("status").equals("success")) {
                            runOnUiThread(() -> binding.live.setVisibility(VISIBLE));
                        }
                    });

                    agentStatusChangeListener = (mAgentID, isOnline) -> {
                        if (!agentID.equals(mAgentID)) {
                            return;
                        }
                        runOnUiThread(() -> {
                            if (isOnline) {
                                binding.live.setVisibility(VISIBLE);
                                return;
                            }
                            binding.live.setVisibility(GONE);
                        });
                    };

                    Utils.addAgentStatusChanged(agentStatusChangeListener);
                    return;
                }

                if (Utils.agentModelList == null) {
                    finishAffinity();
                    return;
                }

                for (int j = 0; j < Utils.agentModelList.size(); j++) {
                    PegaSocketServer.getSocket().on("new-details-" + Utils.agentModelList.get(j).getAgentID(), args -> {

                        JSONObject obj = (JSONObject) args[0];
                        try {
                            var ref = new Object() {
                                int index = 0;
                                boolean exists = false;
                            };
                            for (int i = 0; i < data.length(); i++) {
                                JSONObject model = data.getJSONObject(i);
                                if (model.getString("submissionId").equals(obj.getString("submissionId"))) {
                                    ref.index = i;
                                    data.put(i, mergeJSONObjects(model, obj));
                                    ref.exists = true;
                                    break;
                                }
                            }
                            if (!ref.exists) {
                                data.put(0, obj);
                            }

                            runOnUiThread(() -> {
                                binding.noDetailsLabel.setVisibility(View.GONE);
                                if (ref.exists) {
                                    adapter.notifyItemChanged(ref.index);
                                } else {
                                    adapter.notifyItemInserted(0);
                                    binding.recyclerView.scrollToPosition(0);
                                }
                            });

                        } catch (JSONException e) {
                            throw new RuntimeException(e);
                        }
                    });
                }
            }
        }));
    }

    public JSONObject mergeJSONObjects(JSONObject obj1, JSONObject obj2) throws JSONException {
        JSONObject merged = new JSONObject();

        Iterator<String> keys = obj1.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            merged.put(key, obj1.get(key));
        }

        keys = obj2.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            merged.put(key, obj2.get(key));
        }

        return merged;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (Utils.agentModelList != null) {
            for (int i = 0; i < Utils.agentModelList.size(); i++) {
                PegaSocketServer.getSocket().off("new-details-" + Utils.agentModelList.get(i).getAgentID());
            }
        } else {
            PegaSocketServer.getSocket().off("new-details-" + agentID);
        }

        if (agentStatusChangeListener != null) {
            Utils.removeAgentStatusChanged(agentStatusChangeListener);
        }

    }
}