package com.pegalite.neotronadmin.functions.helpers;

import android.content.Context;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class FileDownloader {

    public static void downloadFile(Context context, String fileUrl, String fileName, DownloadCallback callback) {
        new Thread(() -> {
            InputStream input = null;
            BufferedOutputStream output = null;
            HttpURLConnection connection = null;

            try {
                // Create URL and open connection
                URL url = new URL(fileUrl);
                connection = (HttpURLConnection) url.openConnection();
                connection.setConnectTimeout(10_000); // 10 seconds timeout
                connection.setReadTimeout(15_000); // 15 seconds read timeout
                connection.connect();

                // Check if response is OK
                if (connection.getResponseCode() != HttpURLConnection.HTTP_OK) {
                    throw new Exception("Server returned HTTP " + connection.getResponseCode()
                            + " " + connection.getResponseMessage());
                }

                // Get file length for progress update
                int fileLength = connection.getContentLength();

                // Create a file in the cache directory
                File cacheDir = context.getCacheDir();
                File outputFile = new File(cacheDir, fileName);

                // Open streams with optimized buffer size
                input = new BufferedInputStream(connection.getInputStream(), 8192); // 8KB buffer
                output = new BufferedOutputStream(new FileOutputStream(outputFile), 8192);

                byte[] data = new byte[8192]; // Larger buffer for faster reads
                long total = 0;
                int count;

                // Read data and write to file
                while ((count = input.read(data)) != -1) {
                    total += count;

                    // Write to file
                    output.write(data, 0, count);

                    // Update progress
                    if (fileLength > 0) {
                        int progress = (int) (total * 100 / fileLength);
                        callback.onProgressUpdate(progress);
                    }
                }

                // Flush output stream
                output.flush();

                // Notify completion
                callback.onDownloadComplete(outputFile);

            } catch (Exception e) {
                // Notify failure
                callback.onDownloadFailed(e);
            } finally {
                try {
                    if (input != null) input.close();
                    if (output != null) output.close();
                } catch (Exception ignored) {
                }
                if (connection != null) connection.disconnect();
            }
        }).start();
    }

    public interface DownloadCallback {
        void onProgressUpdate(int progress);

        void onDownloadComplete(File file);

        void onDownloadFailed(Exception e);
    }
}

