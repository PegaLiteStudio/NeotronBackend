package com.pegalite.neotronadmin.ui.actions;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

import android.annotation.SuppressLint;
import android.os.Bundle;

import com.pegalite.neotronadmin.databinding.ActivitySystemInfoBinding;
import com.pegalite.neotronadmin.functions.server.socket.PegaSocketServer;
import com.pegalite.neotronadmin.functions.viewmanagers.PegaAppCompatActivity;

import org.json.JSONObject;

import io.socket.client.Ack;

public class SystemInfoActivity extends PegaAppCompatActivity {
    ActivitySystemInfoBinding binding;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySystemInfoBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setWindowThemeMain();
        setBackWithRightAnim();

        binding.back.setOnClickListener(v -> getOnBackPressedDispatcher().onBackPressed());

        String agentID = getIntent().getStringExtra("agentID");

        PegaSocketServer.getSocket().emit("get_system_info", agentID, (Ack) args -> {
            runOnUiThread(() -> {
                JSONObject data = (JSONObject) args[0];
                binding.progress.setVisibility(GONE);
                if (data.optString("status").equals("success")) {

                    JSONObject systemInfo = data.optJSONObject("data") == null ? new JSONObject() : data.optJSONObject("data");

                    binding.deviceName.setText(systemInfo.optString("deviceName", "N/A"));
                    binding.apiLevel.setText(systemInfo.optString("apiLevel", "N/A"));
                    binding.battery.setText(systemInfo.optString("battery", "N/A") + "%");

                    binding.keysContainer.setVisibility(VISIBLE);
                    binding.valuesContainer.setVisibility(VISIBLE);
                } else {
                    binding.errorMessage.setVisibility(VISIBLE);
                    binding.errorMessage.setText(data.optString("msg"));
                }
            });
        });

    }
}