package com.pegalite.neotronadmin.ui.auth;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.pegalite.neotronadmin.R;
import com.pegalite.neotronadmin.databinding.ActivityLoginBinding;
import com.pegalite.neotronadmin.functions.helpers.Prefs;
import com.pegalite.neotronadmin.functions.server.req.RetrofitClient;
import com.pegalite.neotronadmin.functions.server.res.PegaCallback;
import com.pegalite.neotronadmin.functions.server.res.PegaResponseManager;
import com.pegalite.neotronadmin.functions.viewmanagers.PegaAnimationManager;
import com.pegalite.neotronadmin.functions.viewmanagers.PegaAppCompatActivity;
import com.pegalite.neotronadmin.ui.pages.SplashActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.logging.Level;
import java.util.logging.Logger;

public class LoginActivity extends PegaAppCompatActivity {

    private static final Logger LOGGER = Logger.getLogger(LoginActivity.class.getName());
    ActivityLoginBinding binding;
    Prefs prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setWindowThemeMain();

        prefs = new Prefs(this);
        binding.login.setOnClickListener(v -> {
            String key = binding.key.getText().toString();
            if (key.isEmpty()) {
                binding.key.setError("Enter Key");
                PegaAnimationManager.shake(binding.keyContainer);
                Toast.makeText(this, "Please Enter Key", Toast.LENGTH_SHORT).show();
                return;
            }

            login(key);

        });

    }

    @SuppressLint("HardwareIds")
    private void login(String key) {
        try {
            RetrofitClient.getInstance(this).getApiInterfaces().login(RetrofitClient.generateRequestBody(new JSONObject().put("key", key).put("appID", getPackageName()))).enqueue(new PegaResponseManager(new PegaCallback(this, true) {
                @Override
                public void onSuccess(@Nullable JSONObject data) {
                    if (data == null || !data.has("token")) {
                        onUnexpectedResponse();
                        return;
                    }

                    try {
                        prefs.setPref("key", key);
                        prefs.setJWT(data.getString("token"));
                        Toast.makeText(LoginActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();

                        openClear(SplashActivity.class);
                    } catch (JSONException e) {
                        LOGGER.log(Level.SEVERE, "Stack trace:", e);
                    }
                }

                @Override
                public void onAccountBanned() {
                    super.onAccountBanned();
                }

                @Override
                public void onAccountNotExists() {
                    super.onAccountNotExists();
                    PegaAnimationManager.shake(binding.keyContainer);
                }


                @Override
                public void onDeviceChanged() {
                    addDialogToDestroyList(new AlertDialog.Builder(LoginActivity.this, R.style.alertDialog).setTitle("Contact Support").setMessage("Device Changed! Please Contact With Admin for Support").setPositiveButton("Okay", (dialog, which) -> dialog.dismiss()).show());
                    Toast.makeText(LoginActivity.this, "Device Changed! Please Contact With Admin for Support", Toast.LENGTH_SHORT).show();
                }
            }));
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }
}