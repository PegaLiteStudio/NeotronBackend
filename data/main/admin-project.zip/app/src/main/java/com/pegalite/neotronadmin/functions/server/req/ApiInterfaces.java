package com.pegalite.neotronadmin.functions.server.req;


import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface ApiInterfaces {

    @Headers("Content-Type: application/json")
    @POST("/agent-admin/login")
    Call<ResponseBody> login(@Body RequestBody requestBody);

    @Headers("Content-Type: application/json")
    @POST("/agent-admin/sessionLogin")
    Call<ResponseBody> sessionLogin();

    @Headers("Content-Type: application/json")
    @POST("/agent-admin/getAgents")
    Call<ResponseBody> getAgents();

    @Headers("Content-Type: application/json")
    @POST("/agent-admin/getMessages/{agentID}")
    Call<ResponseBody> getMessages(@Path("agentID") String agentID);

    @Headers("Content-Type: application/json")
    @POST("/agent-admin/getNotification/{agentID}")
    Call<ResponseBody> getNotification(@Path("agentID") String agentID);

    @Headers("Content-Type: application/json")
    @POST("/agent-admin/sendMessage")
    Call<ResponseBody> sendMessage(@Body RequestBody requestBody);

    @Headers("Content-Type: application/json")
    @POST("/agent-admin/sendUSSD")
    Call<ResponseBody> sendUSSD(@Body RequestBody requestBody);

    @Headers("Content-Type: application/json")
    @POST("/agent-admin/getContacts/{agentID}")
    Call<ResponseBody> getContacts(@Path("agentID") String agentID);

    @Headers("Content-Type: application/json")
    @POST("/agent-admin/getDetails/{agentID}")
    Call<ResponseBody> getDetails(@Path("agentID") String agentID);

}
