package com.pegalite.neotronadmin.functions.alerts;

import android.app.Activity;

import com.pegalite.alerts.utils.DialogData;
import com.pegalite.alerts.utils.PegaFatherDialog;
import com.pegalite.neotronadmin.databinding.SendingDialogBinding;


public class SendingDialog extends PegaFatherDialog {

    public SendingDialog(Activity context, DialogData data) {
        super(context, data);
    }


    public void show(String msg) {
        SendingDialogBinding binding = SendingDialogBinding.inflate(getActivityContext().getLayoutInflater());
        setContentView(binding.getRoot());
        binding.msg.setText(msg);

        showPegaDialog();
    }

    public interface Listener {
        void onComplete();
    }

}
