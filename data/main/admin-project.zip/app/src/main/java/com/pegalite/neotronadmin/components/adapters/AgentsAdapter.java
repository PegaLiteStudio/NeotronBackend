package com.pegalite.neotronadmin.components.adapters;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.pegalite.neotronadmin.components.models.AgentModel;
import com.pegalite.neotronadmin.databinding.DeviceItemBinding;
import com.pegalite.neotronadmin.functions.utils.Utils;
import com.pegalite.neotronadmin.functions.viewmanagers.PegaAppCompatActivity;
import com.pegalite.neotronadmin.ui.pages.ViewDeviceActivity;

import java.util.List;

public class AgentsAdapter extends RecyclerView.Adapter<AgentsAdapter.AgentViewHolder> {

    private final List<AgentModel> contactModelList;
    private final PegaAppCompatActivity activity;

    public AgentsAdapter(List<AgentModel> contactModelList, PegaAppCompatActivity activity) {
        this.contactModelList = contactModelList;
        this.activity = activity;
    }

    @NonNull
    @Override
    public AgentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new AgentViewHolder(DeviceItemBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false));
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull AgentViewHolder holder, int position) {
        AgentModel model = contactModelList.get(position);

        holder.binding.agentName.setText(model.getAgentName());
        holder.binding.deviceName.setText(model.getDeviceName());
        holder.binding.activeStatus.setVisibility(model.isOnline() ? View.VISIBLE : View.GONE);
        holder.binding.getRoot().setOnClickListener(v -> activity.openActivityWithRightAnim(new Intent(activity, ViewDeviceActivity.class).putExtra("deviceName", model.getDeviceName()).putExtra("agentID", model.getAgentID())));
        Utils.addAgentStatusChanged((agentID, isOnline) -> {
            if (!agentID.equals(model.getAgentID())) {
                return;
            }
            activity.runOnUiThread(() -> {
                if (isOnline) {
                    holder.binding.activeStatus.setVisibility(View.VISIBLE);
                    return;
                }
                holder.binding.activeStatus.setVisibility(View.GONE);
            });
        });
    }

    @Override
    public int getItemCount() {
        return contactModelList.size();
    }

    public static class AgentViewHolder extends RecyclerView.ViewHolder {

        DeviceItemBinding binding;

        public AgentViewHolder(@NonNull DeviceItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}

