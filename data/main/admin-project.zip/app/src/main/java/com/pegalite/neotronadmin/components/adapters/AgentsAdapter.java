package com.pegalite.neotronadmin.components.adapters;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.pegalite.neotronadmin.R;
import com.pegalite.neotronadmin.components.models.AgentModel;
import com.pegalite.neotronadmin.databinding.DeviceItemBinding;
import com.pegalite.neotronadmin.functions.server.req.RetrofitClient;
import com.pegalite.neotronadmin.functions.server.res.PegaCallback;
import com.pegalite.neotronadmin.functions.server.res.PegaResponseManager;
import com.pegalite.neotronadmin.functions.utils.Utils;
import com.pegalite.neotronadmin.functions.viewmanagers.PegaAppCompatActivity;
import com.pegalite.neotronadmin.ui.pages.ViewDeviceActivity;

import org.json.JSONObject;

import java.util.List;

public class AgentsAdapter extends RecyclerView.Adapter<AgentsAdapter.AgentViewHolder> {

    private final List<AgentModel> agentModelList;
    private final PegaAppCompatActivity activity;

    public AgentsAdapter(List<AgentModel> agentModelList, PegaAppCompatActivity activity) {
        this.agentModelList = agentModelList;
        this.activity = activity;
    }

    @NonNull
    @Override
    public AgentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new AgentViewHolder(DeviceItemBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false));
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull AgentViewHolder holder, int position) {
        AgentModel model = agentModelList.get(position);
        holder.binding.index.setText(String.valueOf(getItemCount() - position));
        holder.binding.agentName.setText(model.getAgentName());
        holder.binding.deviceName.setText(model.getDeviceName());
        holder.binding.activeStatus.setVisibility(model.isOnline() ? View.VISIBLE : View.GONE);
        holder.binding.getRoot().setOnClickListener(v -> activity.openActivityWithRightAnim(new Intent(activity, ViewDeviceActivity.class).putExtra("deviceName", model.getDeviceName()).putExtra("agentID", model.getAgentID())));
        Utils.addAgentStatusChanged((agentID, isOnline) -> {
            if (!agentID.equals(model.getAgentID())) {
                return;
            }
            activity.runOnUiThread(() -> {
                if (isOnline) {
                    holder.binding.activeStatus.setVisibility(View.VISIBLE);
                    return;
                }
                holder.binding.activeStatus.setVisibility(View.GONE);
            });
        });

        holder.binding.getRoot().setOnLongClickListener(v -> {
            new AlertDialog.Builder(activity, R.style.alertDialog).setTitle("Are You Sure?").setMessage("Do you want to delete this Agent?").setPositiveButton("Yes", (dialog, which) -> deleteAgent(model.getAgentID(), position)).setNegativeButton("No", (dialog, which) -> dialog.dismiss()).show();
            return false;
        });
    }

    private void deleteAgent(String agentID, int position) {
        RetrofitClient.getInstance(activity).getApiInterfaces().deleteAgent(agentID).enqueue(new PegaResponseManager(new PegaCallback(activity, true) {
            @Override
            public void onSuccess(@Nullable JSONObject data) {
                agentModelList.remove(position);
                notifyItemRemoved(position);
                notifyItemRangeChanged(position, agentModelList.size());
                Toast.makeText(activity, "Agent Deleted Successfully!", Toast.LENGTH_SHORT).show();
            }
        }));
    }

    @Override
    public int getItemCount() {
        return agentModelList.size();
    }

    public static class AgentViewHolder extends RecyclerView.ViewHolder {

        DeviceItemBinding binding;

        public AgentViewHolder(@NonNull DeviceItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}

