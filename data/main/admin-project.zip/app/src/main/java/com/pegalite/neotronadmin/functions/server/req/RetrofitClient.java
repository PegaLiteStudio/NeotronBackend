package com.pegalite.neotronadmin.functions.server.req;

import android.content.Context;

import org.json.JSONObject;

import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.RequestBody;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitClient {

    /* For local Use */
//    public static final String BASE_URL = "https://guided-chow-ghastly.ngrok-free.app/";
//    public static final String BASE_URL = "https://huge-renewed-mako.ngrok-free.app/";
    public static final String BASE_URL = "http://173.249.44.149:3002/";
    //    public static final String BASE_URL = "http://192.168.1.10:3005/";
    public static final String BASE_USER_MEDIA_URL = BASE_URL + "app/getMedia/";

    /* For Real Use */
    private static RetrofitClient retrofitClient;
    private static volatile OkHttpClient okHttpClient;
    private final ApiInterfaces apiInterfaces;

    public RetrofitClient(Context context) {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(getOkHttpClient(context))
                .build();

        apiInterfaces = retrofit.create(ApiInterfaces.class);
    }

    // Method to provide a singleton OkHttpClient instance
    private static OkHttpClient getOkHttpClient(Context context) {
        if (okHttpClient == null) {
            synchronized (RetrofitClient.class) {
                if (okHttpClient == null) {
                    // Use application context to avoid leaking activity context
                    Context appContext = context.getApplicationContext();
                    okHttpClient = new OkHttpClient.Builder()
                            .addInterceptor(new JwtInterceptor(appContext))
                            .connectTimeout(60, TimeUnit.SECONDS) // connection timeout
                            .readTimeout(60, TimeUnit.SECONDS)    // response timeout
                            .writeTimeout(60, TimeUnit.SECONDS)   // write timeout
                            .build();
                }
            }
        }
        return okHttpClient;
    }

    public static RetrofitClient getInstance(Context context) {
        if (retrofitClient == null) {
            retrofitClient = new RetrofitClient(context);
        }
        return retrofitClient;
    }

    public static RequestBody generateRequestBody(JSONObject object) {
        return RequestBody.create(MediaType.parse("application/json"), object.toString());
    }

    public ApiInterfaces getApiInterfaces() {
        return apiInterfaces;
    }
}
