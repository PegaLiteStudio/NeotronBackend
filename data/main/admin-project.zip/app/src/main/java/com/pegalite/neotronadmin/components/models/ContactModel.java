package com.pegalite.neotronadmin.components.models;

public class ContactModel {
    private final String name, phone;

    public ContactModel(String name, String phone) {
        this.name = name;
        this.phone = phone;
    }

    public String getName() {
        return name;
    }

    public String getPhone() {
        return phone;
    }
}
