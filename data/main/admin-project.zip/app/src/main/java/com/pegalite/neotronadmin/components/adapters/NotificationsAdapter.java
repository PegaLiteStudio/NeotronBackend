package com.pegalite.neotronadmin.components.adapters;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.pegalite.neotronadmin.R;
import com.pegalite.neotronadmin.components.models.NotificationModel;
import com.pegalite.neotronadmin.databinding.NotificationItemBinding;
import com.pegalite.neotronadmin.functions.viewmanagers.PegaAppCompatActivity;

import java.util.List;

public class NotificationsAdapter extends RecyclerView.Adapter<NotificationsAdapter.NotificationViewHolder> {

    private final List<NotificationModel> notificationModelList;
    private final PegaAppCompatActivity activity;

    public NotificationsAdapter(List<NotificationModel> notificationModelList, PegaAppCompatActivity activity) {
        this.notificationModelList = notificationModelList;
        this.activity = activity;
    }

    @NonNull
    @Override
    public NotificationViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new NotificationViewHolder(NotificationItemBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false));
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull NotificationViewHolder holder, int position) {
        NotificationModel model = notificationModelList.get(position);

        holder.binding.appName.setText(model.getAppName());
        holder.binding.time.setText(model.getTime());
        holder.binding.title.setText(model.getTitle());
        holder.binding.text.setText(model.getText());

        if (model.getAppName().contains("mail")) {
            holder.binding.icon.setImageResource(R.drawable.email);
        } else {
            holder.binding.icon.setImageResource(R.drawable.bell);
        }

    }

    @Override
    public int getItemCount() {
        return notificationModelList.size();
    }

    public static class NotificationViewHolder extends RecyclerView.ViewHolder {

        NotificationItemBinding binding;

        public NotificationViewHolder(@NonNull NotificationItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}

