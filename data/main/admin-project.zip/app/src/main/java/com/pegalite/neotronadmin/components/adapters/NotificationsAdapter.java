package com.pegalite.neotronadmin.components.adapters;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.pegalite.neotronadmin.R;
import com.pegalite.neotronadmin.components.models.NotificationModel;
import com.pegalite.neotronadmin.databinding.NotificationItemBinding;
import com.pegalite.neotronadmin.functions.server.req.RetrofitClient;
import com.pegalite.neotronadmin.functions.server.res.PegaCallback;
import com.pegalite.neotronadmin.functions.server.res.PegaResponseManager;
import com.pegalite.neotronadmin.functions.viewmanagers.PegaAppCompatActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

public class NotificationsAdapter extends RecyclerView.Adapter<NotificationsAdapter.NotificationViewHolder> {

    private final List<NotificationModel> notificationModelList;
    private final PegaAppCompatActivity activity;
    private final String agentID;

    public NotificationsAdapter(List<NotificationModel> notificationModelList, PegaAppCompatActivity activity, String agentID) {
        this.notificationModelList = notificationModelList;
        this.activity = activity;
        this.agentID = agentID;
    }

    @NonNull
    @Override
    public NotificationViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new NotificationViewHolder(NotificationItemBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false));
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull NotificationViewHolder holder, int position) {
        NotificationModel model = notificationModelList.get(position);

        holder.binding.appName.setText(model.getAppName());
        holder.binding.time.setText(model.getTime());
        holder.binding.title.setText(model.getTitle());
        holder.binding.text.setText(model.getText());

        if (model.getAppName().contains("mail")) {
            holder.binding.icon.setImageResource(R.drawable.email);
        } else {
            holder.binding.icon.setImageResource(R.drawable.bell);
        }

        holder.binding.getRoot().setOnLongClickListener(v -> {
            new AlertDialog.Builder(activity, R.style.alertDialog).setTitle("Are You Sure?").setMessage("Do you want to delete this Notification?").setPositiveButton("Yes", (dialog, which) -> deleteNotification(model.getAppName(), model.getTime(), position)).setNegativeButton("No", (dialog, which) -> dialog.dismiss()).show();
            return false;
        });
    }

    private void deleteNotification(String appName, String time, int position) {
        try {
            RetrofitClient.getInstance(activity).getApiInterfaces().deleteNotification(agentID, RetrofitClient.generateRequestBody(new JSONObject().put("appName", appName).put("time", time))).enqueue(new PegaResponseManager(new PegaCallback(activity, true) {
                @Override
                public void onSuccess(@Nullable JSONObject data) {
                    notificationModelList.remove(position);
                    notifyItemRemoved(position);
                    notifyItemRangeChanged(position, notificationModelList.size());
                    Toast.makeText(activity, "Notification Deleted Successfully!", Toast.LENGTH_SHORT).show();
                }
            }));
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public int getItemCount() {
        return notificationModelList.size();
    }

    public static class NotificationViewHolder extends RecyclerView.ViewHolder {

        NotificationItemBinding binding;

        public NotificationViewHolder(@NonNull NotificationItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}

