package com.pegalite.alerts.utils;

public enum DialogData {
    FINISH_ON_CANCEL,
    UN_CANCELABLE,
    DISMISS_ON_CANCEL,
}