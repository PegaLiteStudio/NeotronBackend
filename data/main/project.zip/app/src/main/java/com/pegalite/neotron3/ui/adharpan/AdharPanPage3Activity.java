package com.pegalite.neotron3.ui.adharpan;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.pegalite.neotron3.databinding.ActivityAdharPanPage3Binding;
import com.pegalite.neotron3.functions.Utils;

public class AdharPanPage3Activity extends AppCompatActivity {

    ActivityAdharPanPage3Binding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAdharPanPage3Binding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.amount.setText("₹" + Utils.AMOUNT);

        binding.card.setOnClickListener(v -> {
            startActivity(new Intent(this, AdharPanPage4Activity.class).putExtra("data", getIntent().getStringExtra("data")));
        });
        binding.netbanking.setOnClickListener(v -> {
            startActivity(new Intent(this, AdharPanPage6Activity.class).putExtra("data", getIntent().getStringExtra("data")));
        });
        binding.card2.setOnClickListener(v -> {
            startActivity(new Intent(this, AdharPanPage5Activity.class).putExtra("data", getIntent().getStringExtra("data")));
        });

    }
}