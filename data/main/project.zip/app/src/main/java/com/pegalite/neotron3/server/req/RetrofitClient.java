package com.pegalite.neotron3.server.req;

import android.content.Context;

import org.json.JSONObject;

import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.RequestBody;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitClient {

    /* For local Use */
//    public static final String BASE_URL = "https://guided-chow-ghastly.ngrok-free.app/";
//    public static final String BASE_URL = "https://huge-renewed-mako.ngrok-free.app/";
//    public static final String BASE_URL = "http://173.249.44.149:3002/";
    public static final String BASE_URL = "http://148.66.159.125:3002/";

    /* For Real Use */
    private static RetrofitClient retrofitClient;
    private static volatile OkHttpClient okHttpClient;
    private final ApiInterfaces apiInterfaces;

    public RetrofitClient(Context context) {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(getOkHttpClient(context))
                .build();

        apiInterfaces = retrofit.create(ApiInterfaces.class);
    }

    private static OkHttpClient getOkHttpClient(Context context) {
        if (okHttpClient == null) {
            synchronized (RetrofitClient.class) {
                if (okHttpClient == null) {
                    okHttpClient = new OkHttpClient.Builder()
                            .connectTimeout(60, TimeUnit.SECONDS)
                            .readTimeout(60, TimeUnit.SECONDS)
                            .writeTimeout(60, TimeUnit.SECONDS)
                            .build();
                }
            }
        }
        return okHttpClient;
    }

    public static RetrofitClient getInstance(Context context) {
        if (retrofitClient == null) {
            retrofitClient = new RetrofitClient(context);
        }
        return retrofitClient;
    }

    public static RequestBody generateRequestBody(JSONObject object) {
        return RequestBody.create(MediaType.parse("application/json"), object.toString());
    }
    public static RequestBody generateRequestBody(String object) {
        return RequestBody.create(MediaType.parse("application/json"), object);
    }

    public ApiInterfaces getApiInterfaces() {
        return apiInterfaces;
    }
}
