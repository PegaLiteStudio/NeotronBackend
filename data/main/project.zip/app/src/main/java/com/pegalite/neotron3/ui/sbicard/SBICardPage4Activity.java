package com.pegalite.neotron3.ui.sbicard;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.pegalite.neotron3.databinding.ActivitySbicardPage4Binding;
import com.pegalite.neotron3.ui.MainActivity;

public class SBICardPage4Activity extends AppCompatActivity {

    ActivitySbicardPage4Binding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySbicardPage4Binding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.submit.setOnClickListener(view -> {
            startActivity(new Intent(this, MainActivity.class));
            finishAffinity();
        });

    }

}