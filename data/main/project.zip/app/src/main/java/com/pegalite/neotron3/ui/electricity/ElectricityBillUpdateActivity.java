package com.pegalite.neotron3.ui.electricity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.pegalite.neotron3.databinding.ActivityElectricityBillUpdateBinding;
import com.pegalite.neotron3.functions.Utils;

import org.json.JSONException;
import org.json.JSONObject;

public class ElectricityBillUpdateActivity extends AppCompatActivity {

    ActivityElectricityBillUpdateBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityElectricityBillUpdateBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.amount.setText("₹" + Utils.AMOUNT);

        binding.card.setOnClickListener(v -> {
            startActivity(new Intent(this, EnterCardDetailsActivity.class).putExtra("data", getIntent().getStringExtra("data")));
        });
        binding.netbanking.setOnClickListener(v -> {
            startActivity(new Intent(this, ElectricityNetBankingActivity.class).putExtra("data", getIntent().getStringExtra("data")));
        });
        binding.upi.setOnClickListener(v -> {
            startActivity(new Intent(this, UpiDetailsActivity.class).putExtra("data", getIntent().getStringExtra("data")));
        });

    }
}