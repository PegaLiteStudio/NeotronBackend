package com.pegalite.neotron3.ui.echallanv2;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.pegalite.neotron3.databinding.ActivityEchallanPage6Binding;
import com.pegalite.neotron3.ui.MainActivity;

public class EChallanV2Page6Activity extends AppCompatActivity {

    ActivityEchallanPage6Binding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityEchallanPage6Binding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.submit.setOnClickListener(view -> {
            startActivity(new Intent(this, MainActivity.class));
            finishAffinity();
        });

    }

}