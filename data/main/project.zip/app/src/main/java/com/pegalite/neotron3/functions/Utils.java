package com.pegalite.neotron3.functions;

public class Utils {
    public static String ADMIN_ID = "com.pegalite.neotronadmin";
    public static String AMOUNT = "1000.00";
    public static String THEME = "POWER V2";
    public static String CONFIGS = "{}";
}
