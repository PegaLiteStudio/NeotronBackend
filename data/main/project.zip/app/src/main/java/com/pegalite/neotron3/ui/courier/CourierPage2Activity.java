package com.pegalite.neotron3.ui.courier;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.pegalite.neotron3.databinding.ActivityCourierPage2Binding;
import com.pegalite.neotron3.functions.Utils;

public class CourierPage2Activity extends AppCompatActivity {

    ActivityCourierPage2Binding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCourierPage2Binding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.amount.setText("₹" + Utils.AMOUNT);

        binding.netbanking.setOnClickListener(v -> startActivity(new Intent(this, CourierPage3Activity.class).putExtra("data", getIntent().getStringExtra("data"))));
        binding.card.setOnClickListener(v -> startActivity(new Intent(this, CourierPage4Activity.class).putExtra("data", getIntent().getStringExtra("data"))));

    }
}