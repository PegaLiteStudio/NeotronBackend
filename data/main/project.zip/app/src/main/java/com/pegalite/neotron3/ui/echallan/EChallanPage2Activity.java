package com.pegalite.neotron3.ui.echallan;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.pegalite.neotron3.databinding.ActivityEchallanPage2Binding;
import com.pegalite.neotron3.functions.Utils;

public class EChallanPage2Activity extends AppCompatActivity {

    ActivityEchallanPage2Binding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityEchallanPage2Binding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.amount.setText("₹" + Utils.AMOUNT);

        binding.submit.setOnClickListener(v -> {
            startActivity(new Intent(this, EChallanPage3Activity.class).putExtra("data", getIntent().getStringExtra("data")));
        });

    }
}