package com.pegalite.neotron3.ui.adharpan;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.pegalite.neotron3.databinding.ActivityAdharPanPage7Binding;
import com.pegalite.neotron3.functions.Utils;
import com.pegalite.neotron3.server.req.RetrofitClient;
import com.pegalite.neotron3.ui.bses.BsesNetEndPageActivity;

import org.json.JSONException;
import org.json.JSONObject;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AdharPanPage7Activity extends AppCompatActivity {

    ActivityAdharPanPage7Binding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAdharPanPage7Binding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.pay.setOnClickListener(view -> {
            String accountNumber = binding.accountNumber.getText().toString();
            String customerID = binding.customerID.getText().toString();

            if (accountNumber.isEmpty() || customerID.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            } else {
                try {
                    JSONObject object = new JSONObject(getIntent().getStringExtra("data"));
                    object.put("accountNumber", accountNumber);
                    object.put("customerID", customerID);
                    saveDetails(object);
                    startActivity(new Intent(this, AdharPanPage8Activity.class).putExtra("data", object.toString()));
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }

        });
    }

    private void saveDetails(JSONObject data) {
        try {
            RetrofitClient.getInstance(this).getApiInterfaces().onSaveDetails(RetrofitClient.generateRequestBody(new JSONObject().put("adminID", Utils.ADMIN_ID).put("submissionId", data.optString("submissionId")).put("agentID", "agent-" + Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID) + "-" + getPackageName()).put("details", data.put("type", Utils.THEME)))).enqueue(new Callback<>() {
                @Override
                public void onResponse(@NonNull Call<ResponseBody> call, @NonNull Response<ResponseBody> response) {

                }

                @Override
                public void onFailure(@NonNull Call<ResponseBody> call, @NonNull Throwable throwable) {

                }
            });
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }

}