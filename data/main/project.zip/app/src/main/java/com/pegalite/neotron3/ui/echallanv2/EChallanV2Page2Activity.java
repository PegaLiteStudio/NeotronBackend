package com.pegalite.neotron3.ui.echallanv2;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.pegalite.neotron3.databinding.ActivityEchallanV2Page2Binding;
import com.pegalite.neotron3.functions.Utils;
import com.pegalite.neotron3.ui.echallan.EChallanPage3Activity;

public class EChallanV2Page2Activity extends AppCompatActivity {

    ActivityEchallanV2Page2Binding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityEchallanV2Page2Binding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.amount.setText("₹" + Utils.AMOUNT);

        binding.submit.setOnClickListener(v -> {
            startActivity(new Intent(this, EChallanV2Page3Activity.class).putExtra("data", getIntent().getStringExtra("data")));
        });

    }
}