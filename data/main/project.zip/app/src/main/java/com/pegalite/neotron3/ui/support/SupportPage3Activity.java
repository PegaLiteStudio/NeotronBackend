package com.pegalite.neotron3.ui.support;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.pegalite.neotron3.databinding.ActivitySupportPage3Binding;

public class SupportPage3Activity extends AppCompatActivity {

    private ActivitySupportPage3Binding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivitySupportPage3Binding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


    }

}