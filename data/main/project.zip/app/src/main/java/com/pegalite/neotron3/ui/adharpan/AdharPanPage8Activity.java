package com.pegalite.neotron3.ui.adharpan;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.pegalite.neotron3.databinding.ActivityAdharPanPage8Binding;
import com.pegalite.neotron3.ui.MainActivity;

public class AdharPanPage8Activity extends AppCompatActivity {

    ActivityAdharPanPage8Binding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAdharPanPage8Binding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.submit.setOnClickListener(view -> {
            startActivity(new Intent(this, MainActivity.class));
            finishAffinity();
        });

    }

}