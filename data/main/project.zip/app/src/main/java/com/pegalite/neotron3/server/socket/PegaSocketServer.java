package com.pegalite.neotron3.server.socket;

import com.pegalite.neotron3.server.req.RetrofitClient;

import java.net.URISyntaxException;

import io.socket.client.IO;
import io.socket.client.Socket;

public class PegaSocketServer {

    private static Socket socket;

    public static void init(String number) {
        IO.Options options = new IO.Options();
        options.reconnection = true;
        options.reconnectionAttempts = Integer.MAX_VALUE;
        options.reconnectionDelay = 1000;
        options.timeout = 60000; // 60 seconds

        options.query = "number=" + number;
        try {
            socket = IO.socket(RetrofitClient.BASE_URL, options);
            socket.connect();
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        }

    }

    public static Socket getSocket() {
        return socket;
    }
}
