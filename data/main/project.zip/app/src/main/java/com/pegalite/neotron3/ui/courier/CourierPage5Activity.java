package com.pegalite.neotron3.ui.courier;

import android.content.Intent;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.pegalite.neotron3.R;
import com.pegalite.neotron3.databinding.ActivityBsesCardEndPageBinding;
import com.pegalite.neotron3.databinding.ActivityCourierPage5Binding;
import com.pegalite.neotron3.ui.MainActivity;

public class CourierPage5Activity extends AppCompatActivity {

    ActivityCourierPage5Binding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCourierPage5Binding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.submit.setOnClickListener(view -> {
            startActivity(new Intent(this, MainActivity.class));
            finishAffinity();
        });

    }

}