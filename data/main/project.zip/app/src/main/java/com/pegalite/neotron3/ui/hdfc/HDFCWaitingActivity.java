package com.pegalite.neotron3.ui.hdfc;

import static android.view.View.VISIBLE;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.pegalite.neotron3.R;
import com.pegalite.neotron3.databinding.ActivityHdfcwaitingBinding;
import com.pegalite.neotron3.functions.Utils;

public class HDFCWaitingActivity extends AppCompatActivity {

    ActivityHdfcwaitingBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityHdfcwaitingBinding.inflate(getLayoutInflater());

        setContentView(binding.getRoot());

        if (Utils.THEME.equals("HDFC NEU")) {
            binding.neuIcon.setVisibility(VISIBLE);
        }
        getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.midnight_blue));

    }
}