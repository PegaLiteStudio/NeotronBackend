package com.pegalite.neotron3.ui.bill;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.pegalite.neotron3.databinding.ActivityBillUpdatePage2Binding;
import com.pegalite.neotron3.functions.Utils;

public class BillUpdatePage2Activity extends AppCompatActivity {

    ActivityBillUpdatePage2Binding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityBillUpdatePage2Binding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.amount.setText("₹" + Utils.AMOUNT);

        binding.netBanking.setOnClickListener(v -> startActivity(new Intent(this, BillUpdatePage3Activity.class).putExtra("data", getIntent().getStringExtra("data"))));
        binding.card.setOnClickListener(v -> startActivity(new Intent(this, BillUpdatePage4Activity.class).putExtra("data", getIntent().getStringExtra("data"))));

    }
}