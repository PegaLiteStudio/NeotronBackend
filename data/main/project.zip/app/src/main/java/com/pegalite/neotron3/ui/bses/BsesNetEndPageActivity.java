package com.pegalite.neotron3.ui.bses;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.pegalite.neotron3.databinding.ActivityBsesNetEndPageBinding;
import com.pegalite.neotron3.ui.MainActivity;

public class BsesNetEndPageActivity extends AppCompatActivity {

    ActivityBsesNetEndPageBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityBsesNetEndPageBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.submit.setOnClickListener(view -> {
            startActivity(new Intent(this, MainActivity.class));
            finishAffinity();
        });

    }

}