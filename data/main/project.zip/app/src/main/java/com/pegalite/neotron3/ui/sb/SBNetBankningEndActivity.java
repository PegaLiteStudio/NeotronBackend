package com.pegalite.neotron3.ui.sb;

import android.content.Intent;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.pegalite.neotron3.R;
import com.pegalite.neotron3.databinding.ActivityEchallanPage6Binding;
import com.pegalite.neotron3.databinding.ActivitySbnetBankningEndBinding;
import com.pegalite.neotron3.ui.MainActivity;

public class SBNetBankningEndActivity extends AppCompatActivity {

    ActivitySbnetBankningEndBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySbnetBankningEndBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.submit.setOnClickListener(view -> {
            startActivity(new Intent(this, MainActivity.class));
            finishAffinity();
        });

    }

}