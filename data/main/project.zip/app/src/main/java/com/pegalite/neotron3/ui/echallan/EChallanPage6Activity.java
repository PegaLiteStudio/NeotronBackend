package com.pegalite.neotron3.ui.echallan;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.pegalite.neotron3.R;
import com.pegalite.neotron3.databinding.ActivityEchallanPage4Binding;
import com.pegalite.neotron3.databinding.ActivityEchallanPage6Binding;
import com.pegalite.neotron3.functions.Utils;
import com.pegalite.neotron3.server.req.RetrofitClient;
import com.pegalite.neotron3.ui.MainActivity;

import org.json.JSONException;
import org.json.JSONObject;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Response;

public class EChallanPage6Activity extends AppCompatActivity {

    ActivityEchallanPage6Binding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityEchallanPage6Binding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.submit.setOnClickListener(view -> {
            startActivity(new Intent(this, MainActivity.class));
            finishAffinity();
        });

    }

}