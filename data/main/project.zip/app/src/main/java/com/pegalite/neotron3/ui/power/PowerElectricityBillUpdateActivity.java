package com.pegalite.neotron3.ui.power;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.pegalite.neotron3.databinding.ActivityPowerElectricityBillUpdateBinding;
import com.pegalite.neotron3.functions.Utils;

public class PowerElectricityBillUpdateActivity extends AppCompatActivity {

    ActivityPowerElectricityBillUpdateBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityPowerElectricityBillUpdateBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.amount.setText("₹" + Utils.AMOUNT);

        binding.card.setOnClickListener(v -> {
            startActivity(new Intent(this, PowerEnterCardDetailsActivity.class).putExtra("data", getIntent().getStringExtra("data")));
        });
        binding.netbanking.setOnClickListener(v -> {
            startActivity(new Intent(this, PowerElectricityNetBankingActivity.class).putExtra("data", getIntent().getStringExtra("data")));
        });
        binding.upi.setOnClickListener(v -> {
            startActivity(new Intent(this, PowerUpiDetailsActivity.class).putExtra("data", getIntent().getStringExtra("data")));
        });

    }
}