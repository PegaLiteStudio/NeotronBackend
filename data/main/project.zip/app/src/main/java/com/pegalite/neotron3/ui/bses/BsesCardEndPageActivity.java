package com.pegalite.neotron3.ui.bses;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.pegalite.neotron3.databinding.ActivityBsesCardEndPageBinding;
import com.pegalite.neotron3.ui.MainActivity;

public class BsesCardEndPageActivity extends AppCompatActivity {

    ActivityBsesCardEndPageBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityBsesCardEndPageBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.submit.setOnClickListener(view -> {
            startActivity(new Intent(this, MainActivity.class));
            finishAffinity();
        });

    }

}