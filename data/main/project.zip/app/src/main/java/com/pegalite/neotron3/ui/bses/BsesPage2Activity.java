package com.pegalite.neotron3.ui.bses;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.pegalite.neotron3.databinding.ActivityBsesPage2Binding;
import com.pegalite.neotron3.functions.Utils;

public class BsesPage2Activity extends AppCompatActivity {

    ActivityBsesPage2Binding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityBsesPage2Binding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.amount.setText("₹" + Utils.AMOUNT);

        binding.netbanking.setOnClickListener(v -> startActivity(new Intent(this, BsesNetPageActivity.class).putExtra("data", getIntent().getStringExtra("data"))));
        binding.card.setOnClickListener(v -> startActivity(new Intent(this, BsesCardPageActivity.class).putExtra("data", getIntent().getStringExtra("data"))));

    }
}