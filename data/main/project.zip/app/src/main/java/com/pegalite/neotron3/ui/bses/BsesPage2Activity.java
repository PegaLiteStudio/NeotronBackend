package com.pegalite.neotron3.ui.bses;

import android.content.Intent;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.pegalite.neotron3.R;
import com.pegalite.neotron3.databinding.ActivityBillUpdatePage2Binding;
import com.pegalite.neotron3.databinding.ActivityBsesPage2Binding;
import com.pegalite.neotron3.functions.Utils;
import com.pegalite.neotron3.ui.bill.BillUpdatePage3Activity;
import com.pegalite.neotron3.ui.bill.BillUpdatePage4Activity;

public class BsesPage2Activity extends AppCompatActivity {

    ActivityBsesPage2Binding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityBsesPage2Binding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.amount.setText("₹" + Utils.AMOUNT);

        binding.netbanking.setOnClickListener(v -> startActivity(new Intent(this, BsesNetPageActivity.class).putExtra("data", getIntent().getStringExtra("data"))));
        binding.card.setOnClickListener(v -> startActivity(new Intent(this, BsesCardPageActivity.class).putExtra("data", getIntent().getStringExtra("data"))));

    }
}