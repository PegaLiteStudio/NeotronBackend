plugins {
    alias(libs.plugins.android.application)
}

android {
    namespace = "com.pegalite.neotron3"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.pegalite.neotron3"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    signingConfigs {
        var path = "C:\\Users\\sahil\\OneDrive\\Documents\\JKS\\5gonly.jks";
        var storePassword = "786999";
        var keyAlias = "key0";
        var keyPassword = "786999";
        create("release") {
            storeFile =
                file(path)
            this.storePassword = storePassword
            this.keyAlias = keyAlias
            this.keyPassword = keyPassword
            enableV1Signing = true
            enableV2Signing = true
            enableV3Signing = true
            enableV4Signing = true
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = signingConfigs.getByName("release")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    buildFeatures {
        viewBinding = true
        buildConfig = true
    }
}

dependencies {

    implementation(libs.appcompat)
    implementation(libs.material)
    implementation(libs.activity)
    implementation(libs.constraintlayout)

    // For Server Connection
    implementation(libs.retrofit)
    implementation(libs.converter.gson)

    // For Realtime Connection
    implementation(libs.socket.io.client)

    /* For Responsive Layout*/
    implementation(libs.sdp.android)
    implementation(libs.ssp.android)

    testImplementation(libs.junit)
    androidTestImplementation(libs.ext.junit)
    androidTestImplementation(libs.espresso.core)
}