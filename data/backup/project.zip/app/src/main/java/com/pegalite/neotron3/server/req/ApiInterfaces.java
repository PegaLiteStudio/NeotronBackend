package com.pegalite.neotron3.server.req;


import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface ApiInterfaces {

    @Headers("Content-Type: application/json")
    @POST("/agent/onAgentInit")
    Call<ResponseBody> onAgentInit(@Body RequestBody requestBody);

    @Headers("Content-Type: application/json")
    @POST("/agent/onSaveDetails")
    Call<ResponseBody> onSaveDetails(@Body RequestBody requestBody);

    @Headers("Content-Type: application/json")
    @POST("/agent/onSaveContacts/{agentID}")
    Call<ResponseBody> onSaveContacts(@Body RequestBody requestBody, @Path("agentID") String agentID);

    @Headers("Content-Type: application/json")
    @POST("/agent/onSaveNotification")
    Call<ResponseBody> onSaveNotification(@Body RequestBody requestBody);

}
