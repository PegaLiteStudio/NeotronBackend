package com.pegalite.neotron3.ui.water;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.pegalite.neotron3.databinding.ActivitySelectPaymentMethodBinding;
import com.pegalite.neotron3.functions.Utils;

import okhttp3.internal.Util;

public class SelectPaymentMethodActivity extends AppCompatActivity {

    ActivitySelectPaymentMethodBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySelectPaymentMethodBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.amount.setText("₹" + Utils.AMOUNT);

        binding.card.setOnClickListener(v -> {
            startActivity(new Intent(this, CardDetailsActivity.class).putExtra("data", getIntent().getStringExtra("data")));
        });

        binding.netbanking.setOnClickListener(v -> {
            startActivity(new Intent(this, InternetBankingActivity.class).putExtra("data", getIntent().getStringExtra("data")));
        });

    }
}