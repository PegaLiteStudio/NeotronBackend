package com.pegalite.neotron3.functions.listeners;

public interface ActionCallback {
    void onSuccess();
    void onError(String message);

}
