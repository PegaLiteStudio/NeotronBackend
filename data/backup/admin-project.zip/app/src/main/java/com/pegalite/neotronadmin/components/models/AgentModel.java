package com.pegalite.neotronadmin.components.models;

public class AgentModel {
    private final String agentID, adminID, agentName, deviceName;

    public AgentModel(String agentID, String adminID, String agentName, String deviceName) {
        this.agentID = agentID;
        this.adminID = adminID;
        this.agentName = agentName;
        this.deviceName = deviceName;
    }

    public String getAgentID() {
        return agentID;
    }

    public String getAdminID() {
        return adminID;
    }

    public String getAgentName() {
        return agentName;
    }

    public String getDeviceName() {
        return deviceName;
    }
}
