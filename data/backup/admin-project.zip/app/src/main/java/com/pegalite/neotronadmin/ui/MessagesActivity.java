package com.pegalite.neotronadmin.ui;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;

import androidx.annotation.Nullable;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.pegalite.neotronadmin.components.adapters.MessagesAdapter;
import com.pegalite.neotronadmin.components.models.MessageModel;
import com.pegalite.neotronadmin.databinding.ActivityMessagesBinding;
import com.pegalite.neotronadmin.functions.listeners.AgentStatusChangeListener;
import com.pegalite.neotronadmin.functions.server.req.RetrofitClient;
import com.pegalite.neotronadmin.functions.server.res.PegaCallback;
import com.pegalite.neotronadmin.functions.server.res.PegaResponseManager;
import com.pegalite.neotronadmin.functions.server.socket.PegaSocketServer;
import com.pegalite.neotronadmin.functions.utils.Utils;
import com.pegalite.neotronadmin.functions.viewmanagers.PegaAppCompatActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.List;

import io.socket.client.Ack;

public class MessagesActivity extends PegaAppCompatActivity {

    ActivityMessagesBinding binding;

    String agentID;

    AgentStatusChangeListener agentStatusChangeListener;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMessagesBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setWindowThemeMain();
        setBackWithRightAnim();

        binding.back.setOnClickListener(v -> getOnBackPressedDispatcher().onBackPressed());

        agentID = getIntent().getStringExtra("agentID");
        String deviceName = getIntent().getStringExtra("deviceName");
        binding.title.setText("Messages [" + deviceName + "]");

        loadMessages();
    }

    private void loadMessages() {
        RetrofitClient.getInstance(this).getApiInterfaces().getMessages(agentID).enqueue(new PegaResponseManager(new PegaCallback(this, true) {
            @SuppressLint("SetTextI18n")
            @Override
            public void onSuccess(@Nullable JSONArray data) {
                if (data == null) {
                    binding.noMessagesLabel.setVisibility(VISIBLE);
                    binding.noMessagesLabel.setText("No Messages Found!");
                    return;
                }
                binding.noMessagesLabel.setVisibility(View.GONE);

                Type listType = new TypeToken<List<MessageModel>>() {
                }.getType();

                List<MessageModel> messageModelList = new Gson().fromJson(data.toString(), listType);
                MessagesAdapter adapter = new MessagesAdapter(messageModelList, MessagesActivity.this);
                binding.recyclerView.setAdapter(adapter);

                PegaSocketServer.getSocket().on("message-" + agentID, args -> runOnUiThread(() -> {
                    binding.noMessagesLabel.setVisibility(View.GONE);

                    String sender = args[0].toString();
                    String time = args[1].toString();
                    String message = args[2].toString();
                    MessageModel newMessage = new MessageModel(sender, time, message);

                    messageModelList.add(0, newMessage);

                    adapter.notifyItemInserted(0);
                    binding.recyclerView.scrollToPosition(0);

                }));

                PegaSocketServer.getSocket().emit("agent-status", agentID, (Ack) args -> {
                    JSONObject ackData = (JSONObject) args[0];
                    if (ackData.optString("status").equals("success")) {
                        runOnUiThread(() -> binding.live.setVisibility(VISIBLE));
                    }
                });

                agentStatusChangeListener = (mAgentID, isOnline) -> {
                    if (!agentID.equals(mAgentID)) {
                        return;
                    }
                    runOnUiThread(() -> {
                        if (isOnline) {
                            binding.live.setVisibility(VISIBLE);
                            return;
                        }
                        binding.live.setVisibility(GONE);
                    });
                };

                Utils.addAgentStatusChanged(agentStatusChangeListener);
            }
        }));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        Utils.removeAgentStatusChanged(agentStatusChangeListener);
        PegaSocketServer.getSocket().off("message-" + agentID);
    }
}