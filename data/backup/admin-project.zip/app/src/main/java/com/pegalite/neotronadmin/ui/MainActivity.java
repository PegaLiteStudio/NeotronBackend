package com.pegalite.neotronadmin.ui;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.RelativeLayout;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.pegalite.neotronadmin.R;
import com.pegalite.neotronadmin.components.models.SimModel;
import com.pegalite.neotronadmin.databinding.ActivityMainBinding;
import com.pegalite.neotronadmin.databinding.DeviceItemBinding;
import com.pegalite.neotronadmin.functions.helpers.Prefs;
import com.pegalite.neotronadmin.functions.server.req.RetrofitClient;
import com.pegalite.neotronadmin.functions.server.res.PegaCallback;
import com.pegalite.neotronadmin.functions.server.res.PegaResponseManager;
import com.pegalite.neotronadmin.functions.server.socket.PegaSocketServer;
import com.pegalite.neotronadmin.functions.utils.Utils;
import com.pegalite.neotronadmin.functions.viewmanagers.PegaAppCompatActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

public class MainActivity extends PegaAppCompatActivity {

    ActivityMainBinding binding;
    Prefs prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setWindowThemeMain();
        setAsLastActivity();

        prefs = new Prefs(this);
        PegaSocketServer.init(this, getPackageName());

        loadDevices();

        setUpCountDown();
    }


    private void loadDevices() {
        RetrofitClient.getInstance(this).getApiInterfaces().getAgents().enqueue(new PegaResponseManager(new PegaCallback(this, true) {
            @Override
            public void onSuccess(@Nullable JSONArray data) {
                if (data == null) {
                    return;
                }

                binding.agentsContainer.removeAllViews();
                for (int i = 0; i < data.length(); i++) {
                    JSONObject agent = data.optJSONObject(i);
                    addAgent(agent.optString("agentID"), agent.optString("adminID"), agent.optString("agentName"), agent.optString("deviceName"), agent.optBoolean("isOnline"), false);

                    Type listType = new TypeToken<List<SimModel>>() {
                    }.getType();

                    Utils.simModelList = new Gson().fromJson(Objects.requireNonNull(agent.optJSONArray("simInfo")).toString(), listType);

                }

                Utils.agentAddedListener = (agentID, adminID, agentName, deviceName) -> runOnUiThread(() -> addAgent(agentID, adminID, agentName, deviceName, true, true));

            }

            private void addAgent(String mAgentID, String mAdminID, String agentName, String deviceName, boolean mIsOnline, boolean isLive) {
                DeviceItemBinding deviceItemBinding = DeviceItemBinding.inflate(getLayoutInflater(), binding.agentsContainer, !isLive);
                deviceItemBinding.agentName.setText(agentName);
                deviceItemBinding.deviceName.setText(deviceName);
                if (mIsOnline) {
                    deviceItemBinding.activeStatus.setVisibility(View.VISIBLE);
                } else {
                    deviceItemBinding.activeStatus.setVisibility(View.GONE);
                }
                deviceItemBinding.getRoot().setOnClickListener(v -> openActivityWithRightAnim(new Intent(MainActivity.this, ViewDeviceActivity.class).putExtra("deviceName", deviceName).putExtra("agentID", mAgentID)));
                Utils.addAgentStatusChanged((agentID, isOnline) -> {
                    if (!agentID.equals(mAgentID)) {
                        return;
                    }
                    runOnUiThread(() -> {
                        if (isOnline) {
                            deviceItemBinding.activeStatus.setVisibility(View.VISIBLE);
                            return;
                        }
                        deviceItemBinding.activeStatus.setVisibility(View.GONE);
                    });
                });
                if (isLive) {
                    binding.agentsContainer.addView(deviceItemBinding.getRoot(), 0);
                }
                addSeparator(isLive);
            }

            private void addSeparator(boolean isLive) {
                RelativeLayout separatorLine = new RelativeLayout(MainActivity.this);

// Set width to MATCH_PARENT and height to 1dp
                RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(
                        RelativeLayout.LayoutParams.MATCH_PARENT,
                        (int) getResources().getDimension(com.intuit.sdp.R.dimen._1sdp) // or just use 1 if no dimen
                );
                layoutParams.topMargin = (int) getResources().getDimension(com.intuit.sdp.R.dimen._5sdp); // marginTop

                separatorLine.setLayoutParams(layoutParams);
                separatorLine.setBackgroundColor(ContextCompat.getColor(MainActivity.this, R.color.vivid_cerulean));
                if (isLive) {
                    binding.agentsContainer.addView(separatorLine, 1);
                    return;
                }
                binding.agentsContainer.addView(separatorLine);
            }
        }));
    }

    @SuppressLint("SetTextI18n")
    private void setUpCountDown() {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault());

        try {
            Date futureDate = sdf.parse(Utils.exp);
            long futureMillis = futureDate != null ? futureDate.getTime() : 0;
            long currentMillis = System.currentTimeMillis();
            long remainingTime = futureMillis - currentMillis;

            if (remainingTime > 0) {
                new CountDownTimer(remainingTime, 1000) {
                    public void onTick(long millisUntilFinished) {
                        long seconds = (millisUntilFinished / 1000) % 60;
                        long minutes = (millisUntilFinished / (1000 * 60)) % 60;
                        long hours = (millisUntilFinished / (1000 * 60 * 60)) % 24;
                        long days = (millisUntilFinished / (1000 * 60 * 60 * 24));

                        String time = String.format(Locale.getDefault(), "%02d days %02d:%02d:%02d", days, hours, minutes, seconds);
                        binding.exp.setText(time);
                    }

                    public void onFinish() {
                        binding.exp.setText("Time's up!");
                        binding.exp.setTextColor(Color.RED);
                        expired();
                    }
                }.start();
            } else {
                binding.exp.setText("Date is in the past.");
                binding.exp.setTextColor(Color.RED);
                expired();
            }

        } catch (Exception e) {
            binding.exp.setText("Invalid date format.");
            expired();
        }
    }

    private void expired() {
        new AlertDialog.Builder(MainActivity.this, R.style.alertDialog).setTitle("Time's up!").setMessage("Your session has expired. Please renew to continue.").setCancelable(false).setPositiveButton("Exit", (dialog, which) -> {
            dialog.dismiss();
            finishAffinity();
        }).show();
    }
}
