package com.pegalite.neotronadmin.functions.utils;

import com.pegalite.neotronadmin.components.models.AgentModel;
import com.pegalite.neotronadmin.components.models.SimModel;
import com.pegalite.neotronadmin.functions.listeners.AgentAddedListener;
import com.pegalite.neotronadmin.functions.listeners.AgentStatusChangeListener;

import java.util.ArrayList;
import java.util.List;

public class Utils {
    public static String exp;
    public static List<AgentModel> agentModelList;
    public static List<AgentStatusChangeListener> agentStatusChangeListeners = new ArrayList<>();
    public static AgentAddedListener agentAddedListener;
    public static List<SimModel> simModelList = new ArrayList<>();

    public static void addAgentStatusChanged(AgentStatusChangeListener listener) {
        agentStatusChangeListeners.add(listener);
    }

    public static void removeAgentStatusChanged(AgentStatusChangeListener listener) {
        agentStatusChangeListeners.remove(listener);
    }
}
